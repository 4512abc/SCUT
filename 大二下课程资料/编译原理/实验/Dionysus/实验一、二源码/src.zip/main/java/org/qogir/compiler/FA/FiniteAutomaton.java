package org.qogir.compiler.FA;

import org.qogir.compiler.util.graph.BreadthFirstIterator;
import org.qogir.compiler.util.graph.LabelEdge;
import org.qogir.compiler.util.graph.LabeledDirectedGraph;

import java.io.*;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * 有限自动机类，实现了 Serializable 接口，可进行序列化操作。
 * 该类作为有限自动机的基础类，包含了有限自动机的基本属性和操作，如字母表、转移表、起始状态等。
 *
 * @author xuyang
 */
public class FiniteAutomaton implements Serializable {
    // 序列化版本号，用于在反序列化时验证版本一致性
    @Serial
    private static final long serialVersionUID = -8476282864782304740L;

    // 有限自动机的字母表，存储所有可能的输入字符
    protected ArrayList<Character> alphabet = new ArrayList<>();

    // 有限自动机的转移表，使用带标签的有向图表示状态之间的转移关系
    protected LabeledDirectedGraph<State> transitTable = new LabeledDirectedGraph<>();

    // 有限自动机的起始状态
    protected State startState;

    /**
     * 默认构造函数，初始化有限自动机。
     * 创建一个编号为 0 的起始状态，并将其添加到转移表中。
     */
    public FiniteAutomaton(){
        // 创建编号为 0 的起始状态
        this.startState = new State(0);
        // 将起始状态添加到转移表的顶点集合中
        this.transitTable.addVertex(this.startState);
    }

    /**
     * 带参数的构造函数，根据传入的标志位初始化有限自动机。
     * 当标志位不等于 -1 时，创建一个编号为 0 的起始状态，并将其添加到转移表中。
     *
     * @param flag 初始化标志位
     */
    public FiniteAutomaton(int flag){
        if(flag != -1){
            // 创建编号为 0 的起始状态
            this.startState = new State(0);
            // 将起始状态添加到转移表的顶点集合中
            this.transitTable.addVertex(this.startState);
        }
    }

    /**
     * 设置有限自动机的字母表。
     *
     * @param alphabet 新的字母表
     */
    public void setAlphabet(ArrayList<Character> alphabet) {
        this.alphabet = alphabet;
    }

    /**
     * 获取有限自动机的字母表。
     *
     * @return 存储字母表字符的列表
     */
    public ArrayList<Character> getAlphabet() {
        return alphabet;
    }

    /**
     * 获取有限自动机的起始状态。
     *
     * @return 起始状态对象
     */
    public State getStartState() {
        return startState;
    }

    /**
     * 设置有限自动机的起始状态。
     *
     * @param startState 新的起始状态
     */
    public void setStartState(State startState) {
        this.startState = startState;
    }

    /**
     * 获取有限自动机的转移表。
     *
     * @return 带标签的有向图表示的转移表
     */
    public LabeledDirectedGraph<State> getTransitTable(){
        return this.transitTable;
    }

    /**
     * 将有限自动机的信息转换为字符串表示。
     * 包含字母表、总边数、起始状态编号以及转移表的详细信息。
     *
     * @return 包含有限自动机信息的字符串
     */
    @Override
    public String toString() {
        // 用于构建输出字符串
        StringBuilder faInfo = new StringBuilder();
        // 获取转移表中边的数量
        int num = transitTable.edgeSet().size();
        // 拼接字母表信息
        faInfo.append("Alphabet:").append(this.alphabet.toString()).append("\n")
                // 拼接总边数信息
                .append("Total edges:").append(num).append("\n")
                // 拼接起始状态编号信息
                .append("Start State:").append(this.startState.getId()).append("\n")
                // 拼接转移表提示信息
                .append("the transitTable is: \n");
        // 遍历转移表中的所有边
        for (LabelEdge edge : transitTable.edgeSet()){
            // 拼接每条边的信息
            faInfo.append("(").append(edge.toString()).append(")\n") ;
        }
        return faInfo.toString();
    }

    /**
     * 重新为有限自动机的状态分配编号。
     * 使用广度优先遍历的方式，从起始状态开始，依次为可达状态分配连续的编号。
     */
    public void renumberSID(){
        // 初始化编号计数器
        int i = 0;
        // 创建一个队列，虽然声明但未实际使用
        ArrayDeque<State> queue = new ArrayDeque<>();
        // 创建广度优先迭代器，从起始状态开始遍历转移表
        BreadthFirstIterator<State> bfi = new BreadthFirstIterator<>(this.transitTable, this.startState);
        // 遍历所有可达状态
        while (bfi.hasNext()) {
            // 为当前状态设置新的编号
            bfi.next().setSid(String.valueOf(i));
            // 编号计数器加 1
            i++;
        }
    }

    /**
     * 将有限自动机的信息导出为 JSON 格式的文件。
     * 目前该方法为空，需要实现具体的导出逻辑。
     * JSON 格式示例：{"start":0,"edges":[{"source":{"id":0,"type":0},"target":{"id":1,"type":1},"label":"a"},{...}]}
     *
     * @param filename 导出文件的名称
     */
    public void exportJson(String filename){}

    /*
     * 显示有限自动机的信息，包括起始状态和转移表的详细信息。
     * 该方法目前被注释掉，若需要使用可取消注释。
     */
    /*    public void showFA(){
        // 构建起始状态信息字符串
        String stateInfo = "Start State:" + this.startState.getId() ;
        // 打印起始状态信息
        System.out.println(stateInfo);
        // 打印转移表提示信息
        System.out.println("the transitTable is: \r");
        String edgeInfo;
        // 遍历转移表中的所有边
        for (LabelEdge edge : transitTable.edgeSet()){
            // 构建每条边的信息字符串
            edgeInfo = "(" + edge.toString() + ")\r" ;//this.transitTable.getEdgeSource(edge).getId() + ":" + this.transitTable.getEdgeSource(edge).getType() + "->" + this.transitTable.getEdgeTarget(edge).getId() + ":" + this.transitTable.getEdgeTarget(edge).getType() + " @ " + edge.getLabel() + ")\r";
            // 打印每条边的信息
            System.out.println(edgeInfo);
        }
    }*/

    /*
     * 将有限自动机的信息导出为 JSON 格式的文件。
     * 该方法目前被注释掉，若需要使用可取消注释。
     * JSON 格式示例：{"start":0,"edges":[{"source":{"id":0,"type":0},"target":{"id":1,"type":1},"label":"a"},{...}]}
     *
     * @param filename 导出文件的名称
     */
    /*    public void exportJson(String filename){

        // 创建一个队列，用于存储每条边的 JSON 信息
        ArrayDeque<String> edgeInfoQueue = new ArrayDeque<>();
        // 遍历转移表中的所有边
        for (RelationshipEdge e : transitTable.edgeSet()){
            // 构建每条边的 JSON 信息字符串
            String thisEdgeInfo = "{\"source\":{\"id\":" + this.transitTable.getEdgeSource(e).getId() + ",\"type\":" + this.transitTable.getEdgeSource(e).getType() + "},\"target\":{\"id\":" + this.transitTable.getEdgeTarget(e).getId() + ",\"type\":" + this.transitTable.getEdgeTarget(e).getType() + "},\"label\":\"" + e.getLabel() + "\"}";
            // 将边的 JSON 信息添加到队列中
            edgeInfoQueue.add(thisEdgeInfo);
        }

        // 从队列中取出第一条边的 JSON 信息
        String thatEdgeInfo = edgeInfoQueue.poll();
        // 构建有限自动机的 JSON 信息字符串
        String FAJson = "{\"start\":" + this.startState.getId() + ",\"edges\":[" + thatEdgeInfo;
        // 遍历队列中剩余的边的 JSON 信息
        while(!edgeInfoQueue.isEmpty()){
            // 从队列中取出下一条边的 JSON 信息
            thatEdgeInfo = edgeInfoQueue.poll();
            // 将边的 JSON 信息添加到有限自动机的 JSON 信息字符串中
            FAJson += "," + thatEdgeInfo;
        }
        // 完成有限自动机的 JSON 信息字符串
        FAJson += "]}";

        // 打印有限自动机的 JSON 信息
        System.out.println(FAJson);

        // 构建导出文件的完整名称
        String file = filename +".json";
        try {
            // 创建文件写入器，使用 UTF-8 编码
            Writer write = new OutputStreamWriter(new FileOutputStream(new File(file)), "UTF-8");
            // 将有限自动机的 JSON 信息写入文件
            write.write(FAJson);
            // 刷新缓冲区
            write.flush();
            // 关闭文件写入器
            write.close();
        } catch(Exception e) {
            // 打印异常堆栈信息
            e.printStackTrace();
        }
    }*/
}