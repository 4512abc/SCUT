#ifndef GAME_H
#define GAME_H
#include<QLabel>
#include <QWidget>
#include<QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QStackedWidget>

#include "map.h"
#include "hard.h"
#include "base.h"
#include "dialog.h"
#include "widget.h"
#include "ranking.h"
#include "storage.h"
#include "button.h"

class game : public Widget
{
    Q_OBJECT
public:
    game(QStackedWidget *,Widget *parent = nullptr);
    void relemap();
    //回到上级页面
    ~game();
    void writeLevel();
    //写入排行榜
    void midMap(int *);
    //中间地图过度
public slots:
    void Clickbase();
    //基础模式的跳转
    void ClickHard();
    //苦难的跳转
    void ClickStorage();
    //回顾的跳转
    void repage();
    //转置页面
    void setBasePage(int);
    //设置基础模式地图
    void setSysPage();
    //设置系统地图
    void setHumPage();
    //设置用户地图
    void setPastPage(int);
    //设置回顾地图
    void setlevel();
    //初始填入排行榜
    void checkLevel();
    //每次检视排行榜
    void toExit();
    //退出
    void toReOpen();
    //重开
signals:
    void Exit();
    void Reopen();
private:
    std::vector<button*> models;
    button *score;
    button *exit;
    button *reopen;
    //六个按钮
    base *Base;
    map *Map;
    hard *Hard;
    storage *Storage;
    //四个页面
    QStackedWidget *stack;
    //调度页面
    int previousPage;
    //回溯到前一个页面
    ranking *Level;
    //排行榜
    QStringList horHeaders;
    //排行榜元素
};

#endif // GAME_H
