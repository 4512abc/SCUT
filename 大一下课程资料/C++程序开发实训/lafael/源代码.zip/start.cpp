#include "start.h"

start::start(QStackedWidget* s,Widget *parent)
    :Widget(parent)
    ,stack(s)
    ,state(true)
{
    now=-1;
    readLog();

    lastLevel=false;
    out=true;
    stack=s;
    QWidget *useWidget=new QWidget();
    QWidget* user=new QWidget();
    user->setFixedSize(500,600);
    //窗口小部件

    account = new QLineEdit(useWidget);
    account->hide();
    password = new QLineEdit(useWidget);
    password->hide();
    account->setPlaceholderText("点击登录以登入");
    password->setPlaceholderText("点击注册以注册账户...");
    account->setReadOnly(true);
    password->setReadOnly(true);
    password->setEchoMode(QLineEdit::Password);
    // 创建文本框

    list=new QListWidget(user);
    //列表

    QListWidgetItem *dy1=new QListWidgetItem(list);
    dy1->setSizeHint(QSize(200,80));
    QLabel *tital1=new QLabel(user);
    tital1->setText("玩家");
    tital1->setAlignment(Qt::AlignCenter);
    tital1->setStyleSheet(
        "QLabel {"
      "    padding: 10px;"
      "    background-color: rgba(201, 224, 171, 50); /* 背景部分透明 */"
      "    border: 1px solid black; /* 边框 */"
      "    font-size: 28px; /* 增大字体 */"
      "    color: #cbca62"
      "}"
        );
    //小标题

    list->setItemWidget(dy1,tital1);
    QFont font;
    font.setPointSize(40);
    //样式

    QStringList items;
    for(int i=0;i<max;i++)
    {
        items.append(users[i][0]);
    }
    for (const QString &itemText : items) {
        QListWidgetItem *item = new QListWidgetItem(itemText);
        item->setFont(font); // 设置字体大小
        list->addItem(item);
        item->setTextAlignment(Qt::AlignCenter);
    }
    //装填

    list->setStyleSheet(
        "QListWidget::item {"
        "    padding: 10px;"
        "    background-color: rgba(224, 230, 188, 50);"
        "    border: 1px solid black;"
        "    color: #cbca62"
        "}"
        );
    list->setFixedSize(500,600);
    //样式

    //浏览用户
    logIn=new button("登录",":/image/log.png",useWidget);
    registe=new button("注册",":/image/registe.png",useWidget);
    finishRead=new button("完成",":/image/start.png",useWidget);
    finishRead->hide();
    finishCrea=new button("完成",":/image/start.png",useWidget);
    finishCrea->hide();
    look=new button("显示",":/image/eyes.png",useWidget);
    look->hide();
    toReturn=new button("返回",":/image/re.png",useWidget);
    nullLog=new button("游客模式",":/image/visitor.png",useWidget);
    //构建按钮

    logIn->setFixedSize(370,100);
    logIn->setIconSize(QSize(200, 70));
    registe->setFixedSize(370,100);
    registe->setIconSize(QSize(200, 70));
    finishRead->setFixedSize(270,100);
    finishRead->setIconSize(QSize(200, 70));
    finishCrea->setFixedSize(270,100);
    finishCrea->setIconSize(QSize(200, 70));
    look->setFixedSize(270,100);
    look->setIconSize(QSize(200, 70));
    toReturn->setFixedSize(270,100);
    toReturn->setIconSize(QSize(200, 70));
    account->setFixedSize(480,40);
    password->setFixedSize(480,40);
    nullLog->setFixedSize(370,100);
    nullLog->setIconSize(QSize(200, 70));

    //尺寸

    QGridLayout *menu=new QGridLayout(useWidget);
    menu->setHorizontalSpacing(100);
    menu->setVerticalSpacing(100);
    menu->setSizeConstraint(QLayout::SetFixedSize);


    // 创建布局并将文本框添加到布局中

    menu->addWidget(account,0,0);
    menu->addWidget(logIn,0,1);
    menu->addWidget(password,1,0);
    menu->addWidget(registe,1,1);
    menu->addWidget(finishRead,0,2);
    menu->addWidget(finishCrea,0,2);
    menu->addWidget(look,1,2);
    menu->addWidget(toReturn,2,0);
    menu->addWidget(nullLog,2,1);
    //

    QHBoxLayout *theAll=new QHBoxLayout(this);
    theAll->addWidget(user);
    theAll->addWidget(useWidget);
    Game=new game(stack,this);
    stack->addWidget(Game);
    stack->show();

    connect(logIn,&QPushButton::clicked,this,&start::signIn);
    connect(registe,&QPushButton::clicked,this,&start::subscribe);
    connect(toReturn,&QPushButton::clicked,this,&start::reIn);
    connect(finishRead,&QPushButton::clicked,this,&start::readIn);
    connect(finishCrea,&QPushButton::clicked,this,&start::creaIn);
    connect(look,&QPushButton::clicked,this,&start::hideShow);
    connect(nullLog,&QPushButton::clicked,this,&start::nullIn);
    connect(Game,&game::Exit,this,&start::endProgram);
    connect(Game,&game::Reopen,this,&start::reStart);

}

start::~start(){}

void start::signIn()
{
    lastLevel=true;
    account->setReadOnly(false);
    account->show();
    password->setReadOnly(false);
    password->show();
    nullLog->hide();
    account->setPlaceholderText("输入账号...");
    password->setPlaceholderText("输入密码...");
    logIn->hide();
    registe->hide();
    finishRead->show();
    look->show();
}

void start::subscribe()
{
    lastLevel=true;
    account->setReadOnly(false);
    account->show();
    password->setReadOnly(false);
    password->show();
    nullLog->hide();
    account->setPlaceholderText("输入账号...");
    password->setPlaceholderText("输入密码...");
    logIn->hide();
    registe->hide();
    finishCrea->show();
    look->show();
}

void start::reIn()
{
    if(lastLevel)
    {
        lastLevel=false;
        state=true;
        account->clear();
        password->clear();
        password->setEchoMode(QLineEdit::Password);
        account->setReadOnly(true);
        account->hide();
        password->setReadOnly(true);
        password->hide();
        nullLog->show();
        account->setPlaceholderText("点击登录以登入...");
        password->setPlaceholderText("点击注册以注册账户...");
        logIn->show();
        registe->show();
        finishRead->hide();
        look->hide();
        finishCrea->hide();
    }
    else
    {
        emit reInitial();
    }
}

void start::readIn()
{
    int end=0;

    nowUser[0]=account->text();
    nowUser[1]=password->text();

    nowUser[0]=account->text();
    if(nowUser[0]=="")
    {
        return;
    }
    //拒绝空名

    for(int i=0;i<max;i++)
    {
        if(users[i][0]==nowUser[0])
        {
            if(users[i][1]!=nowUser[1])
            {
                end=1;
                //结局1
            }

            else
            {
                nowUser[2]=users[i][2];
                nowUser[3]=users[i][3];
                nowUser[4]=users[i][4];
                now=i;
                end=2;
                //结局2
            }
        }
    }

    dialog *log=new dialog(this);

    switch(end)
    {
    case 0:
        log->setMessage("没有这个账号");
        log->exec();
        reIn();
        break;
    case 1:
        log->setMessage("密码错误");
        log->exec();
        reIn();
        break;
    case 2:
        log->setMessage("登录成功");
        log->exec();
        stack->setCurrentWidget(Game);
        break;
    }
    log->deleteLater();
}

void start::creaIn()
{
    int end=0;

    nowUser[0]=account->text();
    if(nowUser[0]=="")
    {
        return;
    }
    nowUser[1]=password->text();

    int post=0;

    for(int i=0;i<max;i++)
    {
        if(users[i][0]==nowUser[0])
        {
            end=1;
            //结局1
        }
    }

    dialog* regist=new dialog(this);

    switch(end)
    {
    case 0:
        regist->setMessage("注册成功,进入游戏");
        regist->exec();
        regist->deleteLater();
        //清空

        now=max;
        max++;
        stack->setCurrentWidget(Game);
        users.push_back(nowUser);
        break;
    case 1:
        regist->setMessage("已有账号");
        regist->exec();
        regist->deleteLater();

        reIn();
        break;
    }
}

void start::hideShow()
{
    if(state==true)
    {
        password->setEchoMode(QLineEdit::Normal);
        state=false;
    }
    else
    {
        password->setEchoMode(QLineEdit::Password);
        state=true;
    }

}

void start::nullIn()
{

    out=false;
    dialog *regist=new dialog();
    regist->setMessage("游客登录将无法计入数据");
    regist->exec();
    regist->deleteLater();

    stack->setCurrentWidget(Game);

}

void start::readLog()
{
    QFile file("log.bin");

    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "无法打开文件";
        return ;
    }

    QDataStream in(&file);

    in>>max;
    users=std::vector<std::vector<QString>>(max,std::vector<QString>(5));
    for(int i=0;i<max;i++)
    {
        for(int j=0;j<5;j++)
        {
            in>>users[i][j];
        }
    }

    file.close();
}

void start::writeLog()
{
    for (int i = users.size(); i >=1 ; --i) {
        QListWidgetItem* item = list->takeItem(i);
        delete item;  // 删除项目
    }

    if(nowUser[0]=="Null"&&out==false)
    {
        dialog* ddd=new dialog(this);
        ddd->readUser(users,nowUser);
        ddd->exec();
        if(nowUser[0]=="Null"||nowUser[0]=="")
        {
            now=max;
        }
        else
        {
            users.push_back(nowUser);
            max++;
            now=max-1;
        }
    }
    //考虑是否加入

    QFile file("log.bin");

    if (!file.open(QIODevice::WriteOnly))
    {
        qDebug() << "无法打开文件";
        return ;
    }

    QDataStream out(&file);

    out<<max;
    for(int i=0;i<max;i++)
    {
        if(i==now)
        {
            for(int j=0;j<5;j++)
            {
                out<<nowUser[j];
                users[i][j]=nowUser[j];
            }
        }
        else
        {
            for(int j=0;j<5;j++)
            {
                out<<users[i][j];
            }
        }
    }
    file.close();
}

void start::preStore()
{
    writeLog();
    Game->writeLevel();
}

void start::endProgram()
{
    QCoreApplication::quit();
}

void start::reStart()
{
    preStore();
    nowUser={"Null","XXX","0","NNNNNN","0"};
    now=-1;
    out=true;
    QFont font;
    font.setPointSize(40);
    QStringList items;
    for(int i=0;i<max;i++)
    {
        items.append(users[i][0]);
    }
    for (const QString &itemText : items) {
        QListWidgetItem *item = new QListWidgetItem(itemText);
        item->setFont(font); // 设置字体大小
        list->addItem(item);
        item->setTextAlignment(Qt::AlignCenter);
    }
    stack->setCurrentWidget(this);
}
