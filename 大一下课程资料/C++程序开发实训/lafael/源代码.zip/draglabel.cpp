#include "DragLabel.h"

DragLabel::DragLabel(QWidget *parent)
    : QLabel(parent)
{
    setMouseTracking(true); // 跟踪鼠标移动
    setCursor(Qt::OpenHandCursor); // 设置手型光标
}

void DragLabel::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        dragStartPos = event->pos(); // 记录鼠标按下时的位置
    }
    QLabel::mousePressEvent(event);
}
void DragLabel::put_text(QString t)
{
    text=t;
}
void DragLabel::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) { // 检查鼠标左键是否被按下
        QPoint diff = event->pos() - dragStartPos; // 计算鼠标移动的距离
        if (diff.manhattanLength() < QApplication::startDragDistance()) {
            return; // 如果移动距离小于启动拖动的距离，则不执行拖动
        }

        // 创建拖动图像，不应用虚化效果
        QPixmap originalPixmap = pixmap(Qt::ReturnByValue);

        // 实现拖动逻辑
        QDrag *drag = new QDrag(this);
        QMimeData *mimeData = new QMimeData;
        mimeData->setText(text); // 将标签的文本作为MIME数据
        drag->setMimeData(mimeData);
        drag->setPixmap(originalPixmap); // 使用原始图像
        drag->setHotSpot(QPoint(0, 0)); // 热区设置在图像的左上角，让图像跟随鼠标箭头
        drag->exec();
    }
    QLabel::mouseMoveEvent(event);
}
