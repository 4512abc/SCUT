#include "storage.h"

storage::storage(QWidget *parent)
    : Widget(parent)
{

    total=100;
    //初始化地图数

    readTotal();
    //读取地图

    QWidget *useWidget=new QWidget(this);

    QWidget *empt=new QWidget(this);
    empt->setFixedSize(340,100);
    QWidget *empt1=new QWidget(this);
    empt->setFixedSize(100,100);
    //占位窗口


    QWidget *title=new QWidget(useWidget);
    title->setFixedSize(620,90);
    title->setStyleSheet(R"(
    QLabel {
        padding: 10px;
        background-color: rgba(201, 224, 171, 50); /* 背景部分透明 */
        border: 1px solid black; /* 边框 */
        font-size: 50px; /* 增大字体 */
        color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 1,
            stop: 0 #318d3c, stop: 0.3 #7cbd70, stop: 1 #cbca62
        );
    }
    )");
    //限制文本框

    start=new button("开始",":/image/fo.png",useWidget);
    start->setFixedSize(320,120);
    start->setIconSize(QSize(240, 100));

    re=new button("返回",":/image/re.png",useWidget);
    re->setFixedSize(320,120);
    re->setIconSize(QSize(240, 100));

    help=new button("帮助",":/image/help.png",useWidget);
    help->setFixedSize(320,120);
    help->setIconSize(QSize(240, 100));

    choice=new QLineEdit(this);
    choice->setPlaceholderText("输入数字以进入关卡，请勿输入非法字符及0");
    choice->setFixedSize(620,80);

    tips=new QLabel(title);
    tips->setText(QString::number(total));
    tips->setFixedSize(100,80);

    QLabel *wordIn=new QLabel(title);
    wordIn->setText("目前存在");
    wordIn->setFixedSize(260,80);

    QLabel *wordHi=new QLabel(title);
    wordHi->setText("关");
    wordHi->setFixedSize(100,80);
    //基本组件

    QHBoxLayout* layout=new QHBoxLayout(title);
    layout->addWidget(wordIn);
    layout->addWidget(tips);
    layout->addWidget(wordHi);

    QGridLayout *menu=new QGridLayout(useWidget);
    menu->setHorizontalSpacing(-200);
    menu->setVerticalSpacing(100);
    menu->setSizeConstraint(QLayout::SetFixedSize);

    menu->addWidget(empt,0,0);
    menu->addWidget(title,1,1);
    menu->addWidget(choice,2,1);
    menu->addWidget(empt1,3,0);
    menu->addWidget(start,3,1);
    menu->addWidget(help,3,2);
    menu->addWidget(re,3,3);
    //添加

    connect(start,&QPushButton::clicked,this,&storage::startIn);
    connect(re,&QPushButton::clicked,this,&storage::clickBack);
    connect(help,&QPushButton::clicked,this,&storage::toHelp);
}

storage::~storage(){}

void storage::clickBack()
{
    emit repage();
}
void storage::reSet()
{
    readTotal();
    tips->setText(QString::number(total));
}

void storage::readTotal()
{
    QFile file("hardMap.bin");

    QDataStream in(&file);
    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "无法打开文件";
        return;
    }
    int empt=0;
    int count=0;
    while(!file.atEnd())
    {
        in>>empt;
        count++;
    }
    total=count/43;
    file.close();
}

void storage::readMap(int a)
{
    QFile file("hardMap.bin");

    QDataStream in(&file);
    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "无法打开文件";
        return;
    }
    int empt=0;
    for(int i=0;i<a-1;i++)
    {
        for(int j=0;j<43;j++)
        {
            in>>empt;
        }
    }

    for(int i=0;i<36;i++)
    {
        in>>workMap[i];
        qDebug()<<workMap[i];
    }
    for(int i=0;i<7;i++)
    {
        in>>solution[i];
        qDebug()<<solution[i];
    }
    file.close();
}

void storage::startIn()
{
    int set=choice->text().toInt();
    if(set==0||set>total||total<0)
    {
        dialog *empt=new dialog(this);
        empt->setMessage("输入错误或地图不足");
        empt->exec();
    }
    else
    {
        emit over(set);
    }
}

int* storage::reMap()
{
    return workMap;
}

int* storage::reSolution()
{
    return solution;
}

void storage::toHelp()
{
    dialog *help=new dialog(this);
    help->setMessage("这里是存档模式的帮助页面\n可访问随机模式创建的地图\n维护排行榜\n此模式可刷积分，且积分占比小");
    help->exec();
    help->deleteLater();
}
