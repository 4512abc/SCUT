#ifndef HARD_H
#define HARD_H

#include <QFile>
#include<QLabel>
#include <vector>
#include<QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>

#include "button.h"
#include "widget.h"
#include "dialog.h"

class hard :public Widget//系统和自主
{
    Q_OBJECT
public:
    hard(QWidget *parent=nullptr);
    ~hard();
    void createMap();
    //系统创建地图
    bool checkFour(int*,int);
    //判断随机的四个初始拼图是否合法
    void choiceSys(int*,int);
    //根据number存入的合法位置，得到随机地址的合法性
    int findFour(int*,int,int,int&);
    //找到基于位置4的合法最大位置
    bool endMap();
    //根据solution得到地图，检查地图后就可以开工了
    void readLevel();
    //读入地图
    void writeLevel();
    //写入地图
    int* reMap();
    //返回地图
    int* reSolution();
    //返回答案
    double& reHlevel();
    //返回难度选择
    void tryCheck(int*);
    //第一步检查
    void counter_4(int*,std::vector<int>&);
    //得到可放置4*4的位置
    void counter_3(int*,std::vector<int>&);
    //得到可放置3*3的位置
    void counter_2(int*,std::vector<int>&);
    //得到可放置2*2的位置
    bool check(int*,int*,std::vector<int>&,std::vector<int>&,std::vector<int>&);
    //初步检查
    void add_cut(std::vector<std::vector<int>> &, int kind, int post);
    //添加1
    bool end_check(std::vector<std::vector<int>>&, int* ,int *,int *,int *);
    //最后依次检测

signals:
    void repage();
    void Cretomap();
    void HumtoMap();
public slots:
    void toHelp();
    void clickback();
    //返回信号
    void humCreate();
    //用户创建
    void sysCreate();
    //系统创建地图
private:
    int workmap[36];
    int solution[7];
    //基础信息
    std::vector<std::vector<int>> number;
    //记录随机地点
    double Hlevel;
    //记录难度
};
#endif // HARD_H
