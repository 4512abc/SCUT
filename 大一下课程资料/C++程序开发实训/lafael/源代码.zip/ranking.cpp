#include "ranking.h"
#include "qdebug.h"

ranking::ranking(const int a)
{
    datas=a;
    for(int i=0;i<10;i++)
    {
        levelOnes.push_back(std::vector<QString>(a,""));
    }
}

QDataStream& operator>>(QDataStream& in, ranking& p)
{
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<p.datas;j++)
        {
            in>>p.levelOnes[i][j];
        }
    }
    return in;
}

QDataStream& operator<<(QDataStream& out,ranking& p)
{

    for(int i=0;i<10;i++)
    {
        for(int j=0;j<p.datas;j++)
        {
            out<<p.levelOnes[i][j];
        }
    }
    return out;
}

void ranking::toCheckLevel(std::vector<QString>&nowUser)
{

    ranking empt(4);
    int index=10;
    //可以放的位置
    int reput=-1;
    //同名位置
    bool end=false;
    for(int i=9;i>=0;i--)
    {
        empt.levelOnes[i][0]=this->levelOnes[i][0];
        //名称
        empt.levelOnes[i][1]=this->levelOnes[i][1];
        //关卡数目
        empt.levelOnes[i][2]=this->levelOnes[i][2];
        //六关情况
        empt.levelOnes[i][3]=this->levelOnes[i][3];
        //积分榜

        if(nowUser[0]==empt.levelOnes[i][0])
        {
            reput=i;
        }

        //记录同名位置

        if(nowUser[4].toInt()<empt.levelOnes[i][3].toInt()&&(end==false))
        {
            index=i+1;
            end=true;
        }
        else if(nowUser[4].toInt()>=empt.levelOnes[i][3].toInt())
        {
            index=i;
        }

        //找到合适位置
    }
    //获得排行
        //无同名情况
        for(int i=0,j=0;i<10&&j<10;i++,j++)
        {
            if(j==reput)
            {
                i--;
                continue;
            }
            if(i==index)
            {
                this->levelOnes[i][0]=nowUser[0];
                this->levelOnes[i][1]=nowUser[2];
                this->levelOnes[i][2]=nowUser[3];
                this->levelOnes[i][3]=nowUser[4];
                j--;
            }
            else
            {
                if(j==reput)
                {
                    i--;
                    continue;
                }
                this->levelOnes[i][0]=empt.levelOnes[j][0];
                this->levelOnes[i][1]=empt.levelOnes[j][1];
                this->levelOnes[i][2]=empt.levelOnes[j][2];
                this->levelOnes[i][3]=empt.levelOnes[j][3];
            }
        }

}

void ranking::liCheckLevel(std::vector<QString>&nowUser,QString &now_time)
{
   ranking empt(3);

    int index=-1;
   //找到合适的位置替换
    for(int i=0;i<10;i++)
   {
       if(this->levelOnes[i][0]=="")
        {

            index=i;
            break;
       }
   }

    int j=0;
    for(int i=0,k=0;i<10&&k<10;i++,k++)
    {
        if(j==1||this->levelOnes[i][1]<now_time)
        {
            empt.levelOnes[i][0]=this->levelOnes[k][0];

            empt.levelOnes[i][1]=this->levelOnes[k][1];
        }
        //存储的数据比给出的小，则向下走
        else
        {
            j=1;

            empt.levelOnes[i][0]=nowUser[0];

            empt.levelOnes[i][1]=now_time;
            k--;

        }
        //反之
    }
    if(index!=-1&&j==0)
    {
        this->levelOnes[index][0]=nowUser[0];
        this->levelOnes[index][1]=now_time;
        return;
    }
    //说明有空且j未赋值

    for(int i=0;i<10;i++)
    {
        this->levelOnes[i][0]=empt.levelOnes[i][0];
        this->levelOnes[i][1]=empt.levelOnes[i][1];
    }
}

int ranking::reData()
{
    return datas;
}

std::vector<std::vector<QString>>& ranking::reVector()
{
    return levelOnes;
}

ranking::~ranking()
{
}

void ranking::clear()
{
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<datas;j++)
        {
            levelOnes[i][j]="";
        }
    }
}
