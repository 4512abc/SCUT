#ifndef DROPLABEL_H
#define DROPLABEL_H

#include <QDrag>
#include <QLabel>
#include <QWidget>
#include <QMimeData>
#include <QMouseEvent>
#include <QGridLayout>
#include <QApplication>
#include <QGraphicsDropShadowEffect>

class DropLabel : public QLabel
{
    Q_OBJECT
public:
    explicit DropLabel(QWidget *parent = nullptr);
    void putpost(int,std::vector<DropLabel*>);
    //设置坐标，并传入网格的指针
    void findlabel(int);
    //衍生到其他label
    void checkchar();
    //1->2->3->4
    void boom(int);
    //炸弹
    void toZero(int);
    //归零
    void decrease(int);
    //-1
protected:
    void dragEnterEvent(QDragEnterEvent *event) override;
    //判断是否要接收这个拖拽
    void dropEvent(QDropEvent *event) override;
    //接收之后的操作
signals:
    void back(int,int);
    void zero(int);
private:
    int post;//位置信息
    std::vector<DropLabel*> droplabel;//指针
};
#endif // DROPLABEL_H
