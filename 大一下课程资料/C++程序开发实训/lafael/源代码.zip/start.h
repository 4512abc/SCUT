#ifndef START_H
#define START_H

#include <QFile>
#include <QWidget>
#include <QLineEdit>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QTextStream>
#include <QPushButton>
#include <QApplication>
#include <QStackedWidget>

#include "game.h"
#include "widget.h"
#include "dialog.h"
#include "button.h"

class start:public Widget
{
    Q_OBJECT
public:
    start(QStackedWidget *,Widget *parent = nullptr);
    ~start();
    void signIn();
    //登录
    void subscribe();
    //注册
    void reIn();
    //返回
    void readIn();
    //写入账号
    void creaIn();
    //创建账号
    void hideShow();
    //密码是否可见
    void nullIn();
    //虚空登入
    void readLog();
    //读取文件
    void writeLog();
    //写入文件
    void preStore();
    //接收写入信号
    void endProgram();
    //结束游戏
    void reStart();
    //重开
signals:
    void reInitial();
private:
    QStackedWidget *stack;
    //调控页面
    game *Game;
    //子页面
    QLineEdit *account;
    QLineEdit *password;
    //文本输入
    button *logIn;
    button *registe;
    button *finishRead;
    button *finishCrea;
    button *look;
    button *toReturn;
    button *nullLog;
    //七个按钮
    bool state;
    //判断是注册还是登录
    bool lastLevel;
    //回到上一级
    int max;
    //从1开始
    int now;
    //从0开始
    bool out;
    //判断是否进入了游客模式
    std::vector<std::vector<QString>> users;
    //用户数组
    QListWidget *list;
    //用户列表

};
#endif // START_H
