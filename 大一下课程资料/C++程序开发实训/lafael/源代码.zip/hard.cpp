#include "hard.h"
hard::hard(QWidget *parent)
    :   Widget(parent)
{

    Hlevel=0;

    number = {
              {0, 1, 2, 6, 7, 8, 12, 13, 14},
              {0, 1, 2, 3, 6, 7, 8, 9, 12, 13, 14, 15, 18, 19, 20, 21},
              {0, 1, 2, 3, 6, 7, 8, 9, 12, 13, 14, 15, 18, 19, 20, 21},
              {0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 24, 25, 26, 27, 28},
              {0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 24, 25, 26, 27, 28},
              {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35},
              {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35} };


    QWidget *ba=new QWidget(this);
    QWidget *empt=new QWidget(this);
    empt->setFixedSize(400,150);

    QGridLayout* all =new QGridLayout(ba);
    all->setHorizontalSpacing(200);
    all->setVerticalSpacing(50);
    all->setSizeConstraint(QLayout::SetFixedSize);

    button *autoMap=new button("随机挑战",":/image/auto.png",ba);
    button *customMap=new button("娱乐挑战",":/image/cust.png",ba);
    button *_return=new button("返回",":/image/re.png",ba);
    button *help=new button("帮助",":/image/help.png",ba);
    //设置两个子模式

    autoMap->setFixedSize(QSize(390, 160));
    customMap->setFixedSize(QSize(390, 160));
    _return->setFixedSize(QSize(390, 160));
    autoMap->setIconSize(QSize(160,160));
    customMap->setIconSize(QSize(160,160));
    _return->setIconSize(QSize(160,160));
    help->setFixedSize(390,160);
    help->setIconSize(QSize(160,160));
    //设置按钮尺寸

    all->addWidget(empt,0,0);
    all->addWidget(help,1,1);
    all->addWidget(autoMap,2,0);
    all->addWidget(customMap,2,3);
    all->addWidget(_return,3,1);
    connect(autoMap,&QPushButton::clicked,this,&hard::sysCreate);
    // connect(autoMap,&QPushButton::clicked,this);
    connect(_return,&QPushButton::clicked,this,&hard::clickback);
    connect(customMap,&QPushButton::clicked,this,&hard::humCreate);
    connect(help,&QPushButton::clicked,this,&hard::toHelp);

};
hard::~hard()
{
}

void hard::clickback()
{
    emit repage();
}

void hard::sysCreate()
{
    emit Cretomap();
}

void hard::humCreate()
{
    emit HumtoMap();
}

void hard::createMap()
{
    //number 的初始化

    int pos4 = 0;//位置4
    int autopost[5] = {}; // 随机到了哪副拼图
    int autoposi[8] = {}; // 记录哪副没有被随机,方便check
    int onerand = 0;
    for (;;)
    {
        pos4 = rand() % 36 + 1;

        for (int i = 1; i <= 4; i++)
        {
            for (;;)
            {
                onerand = rand() % 7 + 1;
                if (checkFour(autopost, onerand))
                    break;
            }
            autopost[i] = onerand; // 1~7
            autoposi[autopost[i]]++;
        }
        // 得到一个不重复的数组
        choiceSys(autopost, pos4);
        // 对以上四个解得到结果
        for (int i = 1; i <= 7; i++)
        {
            if (autoposi[i] != 1)
            {
                int erand = rand() % (number[i - 1].size());
               solution[i-1]=number[i-1][erand];
                // 得到随机数

            }
        }
        //现在得到了7副拼图的位置信息

        if(endMap())
            break;

    }
}
// 先得到随机的要合成“4”的拼图和位置，然后随机剩余的，
//最后根据随机的记录生成work。

void hard::choiceSys(int* autopost, int pos4)
{
    // 以pos4作为能覆盖区域的最大值，最小值选择

    for (int i = 1; i <= 4; i++)
    // 判断choice是否覆盖
    {
        int toEnd=0;
        int findmin = 0; // 得到最小位置
        int findmax = findFour(number[autopost[i] - 1].data(), number[autopost[i] - 1].size() - 1, pos4,toEnd);
        findmin=findmax/2;
        int erand = 0;   // 最后的随机
        int randMin=0;
        randMin=findmin+findmin*Hlevel;
        int randMax=0;
        randMax=findmax+Hlevel*toEnd;
        if(randMax==randMin)
            randMax++;
        switch (autopost[i])
        {
        case 7:
        case 6:
            erand = pos4;
            solution[autopost[i]-1]=erand; // 7，6在number中的上下限为1
            break;
        case 5:
        case 4: // 重构得到最小位置
            erand = rand() % (randMax - randMin) + randMin;
            solution[autopost[i]-1]=number[autopost[i] - 1][erand];
            break;
        case 3:
        case 2:
            erand = rand() % (randMax - randMin) + randMin;
            solution[autopost[i]-1]=number[autopost[i] - 1][erand];
            break;
        case 1: // 重构得到最小位置
            erand = rand() % (randMax - randMin) + randMin;
            solution[autopost[i]-1]=number[autopost[i] - 1][erand];
            break;
        }
    }
}

int hard::findFour(int* a, int end, int c,int& toEnd)
    // 得到位置“4”的地点
{
    int fend=end;
    // 二分查找
    int str = 0;
    int empt = 0;
    for (; str <= end;)
    {
        int min = (str + end) / 2;
        if (a[min] <= c)
        {
            str = min + 1;
            empt = min;
        }
        else
            end = min - 1;
    }
    toEnd=fend-empt;
    return empt;
}

bool hard::checkFour(int* post,int n)
{
    for (int i = 1; i <= 4; i++)
    {
        if (post[i]==n)
        {
            return false;
        }
    }
    return true;
}

bool hard::endMap()
{

    bool more4=true;
    int work_map[36]={};
    for (int i = 0; i < 7; i++)
    {
        int empt = solution[i];
        // 拿到随机到的结果
        switch (i+1)
        {
        case 7:
        case 6:
            work_map[empt]++;
            break;
        case 5:
        case 4:
            work_map[empt]++;
            work_map[empt + 1]++;
            work_map[empt + 6]++;
            work_map[empt + 7]++;
            break;
        case 3:
        case 2:
            for (int i = 0; i < 3; i++) // 9格有点多，循环吧
            {
                work_map[empt + i]++;
                work_map[empt + 6 + i]++;
                work_map[empt + 12 + i]++;
            }
            break;
        case 1:
            for (int i = 0; i < 4; i++) // 16格有点多，循环吧
            {
                work_map[empt + i]++;
                work_map[empt + 6 + i]++;
                work_map[empt + 12 + i]++;
                work_map[empt + 18 + i]++;
            }
            break;
        }
    }
    int count4 = 0;
    for (int i = 0; i < 36; i++)
    {
        if (work_map[i] > 4)
        {
            more4=false;
        }
        else if (work_map[i] == 4)
            count4++;
    }

    if (count4!= 1||more4!=true)
    {
        return false;
    }
    else
    {
        for(int i=0;i<36;i++)
        {
            int empt = work_map[i]; // 拿到随机到的结果
            switch (empt)
            {
            case 4:
                workmap[i]=4;
                break;

            case 3:
                workmap[i]=3;
                break;

            case 1:
                workmap[i]=3;
                break;

            case 2:
                workmap[i]=2;
                break;

            case 0:
                workmap[i]=2;
                break;
            }
        }
        //文本替换

        QFile file("hardMap.bin");
        if (!file.open(QIODevice::Append))
        {
            qDebug() << "无法打开文件";
            return 0;
        }
        QDataStream in(&file);

        for(int i=0;i<36;i++)
        {
            in<<workmap[i];
        }
        for(int i=0;i<7;i++)
        {
            in<<solution[i];
        }
        file.close();
        //写入地图

        return true;
    }
}

int* hard::reMap()
{
    return workmap;
}

int* hard::reSolution()
{
    return solution;
}

double& hard::reHlevel()
{
    return Hlevel;
}

void hard::toHelp()
{
    dialog *help=new dialog(this);
    help->setMessage("这里是挑战模式的帮助页面\n包含了2个子模式\n随机模式支持自选难度\n娱乐模式支持有解判断和道具，但无普通功能\n此模式可刷积分，且积分占比大");
    help->exec();
    help->deleteLater();
}

void hard::tryCheck(int* map)
{

    std::vector<int> map_4;
    std::vector<int> map_3;
    std::vector<int> map_2;
    int solution[7] = {};
    int num_all[5] = {};
    int total = 0;
    if (!check(num_all,map,map_4,map_3,map_2))
    {
        dialog* cout=new dialog(this);
        cout->setMessage("地图超出最大预设\n推荐使用道具解题");
        cout->exec();
        cout->deleteLater();
        return;
    }
    else
    {
        if (map_4.size() < 1 || map_3.size() < 1 || map_2.size() < 1)
        {
            dialog* cout=new dialog(this);
            cout->setMessage("地图无法布置区块过多\n推荐使用道具解题");
            cout->exec();
            cout->deleteLater();
            return;
            //表明前五个拼图无法全部放置
        }
        for (int i = 0; i < map_4.size(); i++)
        {
            for (int j1 = 0; j1 < map_3.size(); j1++)
            {
                for (int j2 = 0; j2 < map_3.size(); j2++)
                {
                    for (int k1 = 0; k1 < map_2.size(); k1++)
                    {
                        for (int k2 = 0; k2 < map_2.size(); k2++)
                        {
                            std::vector<std::vector<int>> defi(6, std::vector<int>(7, 0));
                            add_cut(defi, 4, map_4[i]);
                            add_cut(defi, 3, map_3[j1]);
                            add_cut(defi, 3, map_3[j2]);
                            add_cut(defi, 2, map_2[k1]);
                            add_cut(defi, 2, map_2[k2]);
                            //数组计算

                            int end[6] = {};
                            for (int i = 0; i < 6; i++)
                            {
                                int empt = 0;
                                for (int j = 0; j < 6; j++)
                                {
                                    empt += defi[i][j];
                                    switch (empt)
                                    {
                                    case 0:
                                        end[0]++;
                                        break;
                                    case 1:
                                        end[1]++;
                                        break;
                                    case 2:
                                        end[2]++;
                                        break;
                                    case 3:
                                        end[3]++;
                                        break;
                                    case 4:
                                        end[4]++;
                                        break;
                                    case 5:
                                        end[5]++;
                                    }

                                }
                            }

                            if (end[4] > num_all[4]||end[5]>0)
                            {
                                continue;
                            }

                            int EndNumber = 0;
                            EndNumber = EndNumber+abs(num_all[4] - end[4])+abs(num_all[2]-end[2])+abs(num_all[3]-end[1]-end[3]);
                            EndNumber /= 2;

                            if (EndNumber > 2)
                            {
                                continue;
                            }


                            if (abs(num_all[1]-end[0])>2)
                            {
                                continue;
                            }
                            int another[20] = { -1,-1 };
                            if (end_check(defi, map,end,num_all,another))
                            {
                                total++;
                                if (total == 1)
                                {
                                    solution[0] = map_4[i];
                                    solution[1] = map_3[j1];
                                    solution[2] = map_3[j2];
                                    solution[3] = map_2[k1];
                                    solution[4] = map_2[k2];
                                    solution[5] = another[0];
                                    solution[6] = another[1];
                                }
                            }

                        }
                    }
                }
            }
        }
        if(total>0)
        {
            QString numb=QString::number(total);
            QString solu_end=QString::number(solution[0])+" "+QString::number(solution[1])+" "
                                +QString::number(solution[2])+" "+QString::number(solution[3])+QString::number(solution[4])+" "
                                +QString::number(solution[5])+" "+QString::number(solution[6])+" ";
            dialog* cout=new dialog(this);
            cout->setMessage("此地图共有"+numb+"个解\n其中一组解为\n"+solu_end+"\n推荐自行解题");
            cout->exec();
            cout->deleteLater();
            return;
        }
        else
        {
            dialog* cout=new dialog(this);
            cout->setMessage("此地图共有0个解\n推荐使用道具解题");
            cout->exec();
            cout->deleteLater();
            return;
        }
    }
}

void hard::counter_4(int* map,std::vector<int>& map_4)
{
    for (int i = 0; i < 9; i++)
    {
        int post = number[0][i];

        bool end = true;
        for (int j = 0; j < 4; j++)
        {
            if (map[post+j*6] == 1 || map[post+j*6 + 1] == 1 || map[post+ j*6 + 2] == 1 || map[post + j*6 + 3] == 1)
            {
                end = false;
            }
        }
        if (end)
        {
            map_4.push_back(post);
        }
    }
}

void hard::counter_3(int* map,std::vector<int>& map_3)
{
    for (int i = 0; i < 16; i++)
    {
        int post = number[1][i];

        bool end = true;
        for (int j = 0; j < 3; j++)
        {
            if (map[post + j * 6] == 1 || map[post + j * 6 + 1] == 1 || map[post + j * 6 + 2] == 1)
            {
                end = false;
            }
        }
        if (end)
        {
            map_3.push_back(post);
        }
    }
}

void hard::counter_2(int* map,std::vector<int>& map_2)
{
    for (int i = 0; i < 25; i++)
    {
        int post = number[3][i];

        bool end = true;
        for (int j = 0; j < 2; j++)
        {
            if (map[post + j * 6] == 1 || map[post + j * 6 + 1] == 1)
            {
                end = false;
            }
        }
        if (end)
        {
            map_2.push_back(post);
        }
    }
}

bool hard::check(int*num_all,int* map,std::vector<int>&map_4,std::vector<int>&map_3,std::vector<int>&map_2)
{
    int total = 0;
    //第一步，记录4的个数
    for (int i = 0; i < 36; i++)
    {
        num_all[map[i]]++;
        if (map[i] == 3)
        {
            total += 1;
        }
        else if (map[i] == 2||map[i]==4)
        {
            total += map[i];
        }
    }
    if (total > 46)
    {
        return false;
    }
    counter_4(map,map_4);
    counter_3(map,map_3);
    counter_2(map,map_2);
    return true;
}

bool hard::end_check(std::vector<std::vector<int>> &Wmap, int* fmap,int *end,int *num,int *another)
{
    int dex = 0;
    //
    int map[36] = { };
    //得到地图
    int _map[36] = {};
    //得到对比地图
    for (int i = 0; i < 6; i++)
    {
        int empt = 0;
        for (int j = 0; j < 6; j++)
        {
            empt += Wmap[i][j];
            map[i * 6 + j] = empt;
        }
    }

    for (int i = 0; i < 36; i++)
    {
        if (fmap[i] == 1)
            _map[i] = 0;
        else _map[i] = fmap[i];
    }

    int counter = 0;
    for (int i = 0; i < 36; i++)
    {
        if ((map[i] == 0 || map[i] == 1) && _map[i] == 3)
        {
            _map[i] = 1;
        }

        if (map[i] > _map[i])
            return false;
        else if(map[i]<_map[i])
        {
            if (_map[i] - map[i] > 2)
                return false;
            else
            {
                counter += (_map[i] - map[i]);
                if (_map[i] - map[i] == 1)
                {
                    another[dex] = i;
                    dex++;
                }
                else
                {
                    another[dex] = i;
                    another[dex + 1] = i;
                    dex++;
                }

            }
        }
    }
    if (counter <= 2)
        return true;
    else
        return false;
}

void hard::add_cut(std::vector<std::vector<int>> &Wmap, int kind, int post)
{
    int posx = post / 6;
    int posy = post % 6;
    switch (kind)
    {
    case 4:
        for (int i = 0; i < 4; i++)
        {
            Wmap[posx + i][posy]++;
            Wmap[posx + i][posy + 3 + 1]--;
        }
        break;
    case 3:
        for (int i = 0; i < 3; i++)
        {
            Wmap[posx + i][posy]++;
            Wmap[posx + i][posy + 2 + 1]--;
        }
        break;
    case 2:
        for (int i = 0; i < 2; i++)
        {
            Wmap[posx + i][posy]++;
            Wmap[posx + i][posy + 1 + 1]--;
        }
        break;
    }
}
