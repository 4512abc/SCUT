#include "map.h"

map::map(QWidget *parent)
    : Widget(parent),
    nowIndex(110)
    ,now_back(0)
    ,now_help(0)
    ,state(false)
    ,gametool(nullptr)
    ,module(0)
{
    QWidget *amps=new QWidget(this);
    amps->setFixedSize(480,480);
    QWidget *tool=new QWidget(this);
    QWidget* panel=new QWidget(this);

    panel->setFixedSize(250,480);
    tool->setFixedSize(755,400);
    tool->setStyleSheet(R"(
    QLabel {
        padding: 10px;
        background-color: rgba(224, 230, 188, 50); /* 背景部分透明 */
        border: 1px solid black; /* 边框 */
        font-size: 50px; /* 增大字体 */
        color: #cbca62
    }
    )");

    level=new ranking(2);
    fault=0;
    horHeaders=QStringList()<< "玩家" << "本关用时";


    list=new QListWidget(panel);
    //列表

    QListWidgetItem *dy1=new QListWidgetItem(list);
    dy1->setSizeHint(QSize(250,120));
    QLabel *tital1=new QLabel(panel);
    tital1->setText("玩家动态");
    tital1->setAlignment(Qt::AlignCenter);
    tital1->setStyleSheet(
        "QLabel {"
        "    padding: 10px;"
        "    background-color: rgba(201, 224, 171, 50); /* 背景部分透明 */"
        "    border: 1px solid black; /* 边框 */"
        "    font-size: 28px; /* 增大字体 */"
        "    color: #cbca62"
        "}"
        );
    //小标题

    list->setItemWidget(dy1,tital1);
    QFont font;
    font.setPointSize(15);
    //样式

    QStringList items;

    items.append("");
    items.append("");
    items.append("");
    items.append("");
    items.append("");
    //填充

    for (const QString &itemText : items) {
        QListWidgetItem *item = new QListWidgetItem(itemText);
        item->setFont(font); // 设置字体大小
        list->addItem(item);
        item->setTextAlignment(Qt::AlignCenter);
    }
    //装填

    list->setStyleSheet(
        "QListWidget::item {"
        "    padding: 10px;"
        "    background-color: rgba(224, 230, 188, 50);"
        "    border: 1px solid black;"
        "    color: #768a45"
        "}"
        );
    list->setFixedSize(250,480);

    helpInt=std::vector<int> (7,-1);
    for (int i = 0; i < 36; ++i) {
        piclabel.push_back(new QLabel);
    }//初始化36副图片

    for (int i = 0; i < 7; ++i) {
        uselabel.push_back(new DragLabel);
    }//初始化7副拼图

    for(int i=0;i<36;i++)
    {
        droplabels.push_back(new DropLabel);
        droplabels[i]->setFixedSize(80,80);
        droplabels[i]->setText("0");
        droplabels[i]->setAlignment(Qt::AlignCenter);
    }//初始化拖拽标签

    QPixmap map1(":/image/tree1.png");
    QPixmap map2(":/image/tree23.png");
    QPixmap map3(":/image/tree45.png");
    QPixmap map4(":/image/tree67.png");

    uselabel[0]->setPixmap(map1);
    uselabel[0]->put_text("1");
    uselabel[0]->setScaledContents(true);

    uselabel[1]->setPixmap(map2);
    uselabel[1]->put_text("2");
    uselabel[1]->setScaledContents(true);

    uselabel[2]->setPixmap(map2);
    uselabel[2]->put_text("3");
    uselabel[2]->setScaledContents(true);

    uselabel[3]->setPixmap(map3);
    uselabel[3]->put_text("4");
    uselabel[3]->setScaledContents(true);

    uselabel[4]->setPixmap(map3);
    uselabel[4]->put_text("5");
    uselabel[4]->setScaledContents(true);

    uselabel[5]->setPixmap(map4);
    uselabel[5]->put_text("6");
    uselabel[5]->setScaledContents(true);

    uselabel[6]->setPixmap(map4);
    uselabel[6]->put_text("7");
    uselabel[6]->setScaledContents(true);
    //初始化7副拼图

    uselabel[0]->setFixedSize(280,280);
    uselabel[1]->setFixedSize(120,120);
    uselabel[2]->setFixedSize(120,120);
    uselabel[3]->setFixedSize(80,80);
    uselabel[4]->setFixedSize(80,80);
    uselabel[5]->setFixedSize(80,80);
    uselabel[6]->setFixedSize(80,80);
    // 创建一个网格布局
    gridLayout = new QGridLayout(amps);
    gridLayout->setSpacing(0);
    gridLayout->setHorizontalSpacing(0);  // 设置水平间距
    gridLayout->setVerticalSpacing(0);    // 设置垂直间距

    // 设置网格布局的大小策略为 Fixed，确保不会在大小不匹配时拉伸
    gridLayout->setSizeConstraint(QLayout::SetFixedSize);

    //添加图片和拼图到网格布局
    for(int i = 0; i < 6; i++)
    {
        for(int j = 0; j < 6; j++)
        {
            int index = i * 6 + j;
            DropLabel *dropLabel = droplabels[index];
            //二者对应的指针

            dropLabel->putpost(i*6+j,droplabels);
            //设置坐标信息
            gridLayout->addWidget(dropLabel, i, j);
            //加入
        }
    }
    // 设置拼图布局

    QHBoxLayout *double0=new QHBoxLayout();
    double0->addWidget(uselabel[0]);
    QHBoxLayout *double1=new QHBoxLayout();
    double1->addWidget(uselabel[1]);
    double1->addWidget(uselabel[2]);
    QHBoxLayout *double2=new QHBoxLayout();
    double2->addWidget(uselabel[3]);
    double2->addWidget(uselabel[4]);
    QHBoxLayout *double3=new QHBoxLayout();
    double3->addWidget(uselabel[5]);
    double3->addWidget(uselabel[6]);
    //分层次

    QVBoxLayout *rivlayout = new QVBoxLayout();
    rivlayout->setSpacing(20);
    rivlayout->addLayout(double0);
    rivlayout->addLayout(double1);
    rivlayout->addLayout(double2);
    rivlayout->addLayout(double3);
    //右侧垂直布局

    button *back = new button("返回",":/image/exit.png", tool);
    back->setFixedSize(250,100);
    back->setIconSize(QSize(150, 80));

    start = new button("开始",":/image/gon.png", tool);
    start->setFixedSize(250,100);
    start->setIconSize(QSize(150, 80));

    button *over = new button("检查",":/image/check.png", tool);
    over->setFixedSize(250,100);
    over->setIconSize(QSize(150, 80));

    inLevel = new button("排行",":/image/level.png", tool);
    inLevel->setFixedSize(250,100);
    inLevel->setIconSize(QSize(150, 80));

    pullBack=new button("后撤",":/image/back.png",tool);
    pullBack->setFixedSize(250,100);
    pullBack->setIconSize(QSize(150, 80));

    help=new button("提示",":/image/tip.png",tool);
    help->setFixedSize(250,100);
    help->setIconSize(QSize(150, 80));

    tools=new button("道具",":/image/tool.png",tool);
    tools->setFixedSize(250,100);
    tools->setIconSize(QSize(150, 80));
    tools->hide();
    //按钮

    time=new QLabel(tool);
    time->setFixedSize(500,200);
    time->setText("00:00:00");
    time->setAlignment(Qt::AlignCenter);
    timer=new QTimer(this);
    nowtime = QDateTime::currentDateTime();
    //计时器

    backCounter=new QLabel(tool);
    backCounter->setText("0");
    backCounter->setFixedSize(250,100);
    backCounter->setAlignment(Qt::AlignCenter);
    helpCounter=new QLabel(tool);
    helpCounter->setText("0");
    helpCounter->setFixedSize(250,100);
    helpCounter->setAlignment(Qt::AlignCenter);

    menu=new QGridLayout(tool);
    menu->setSpacing(0);
    menu->setHorizontalSpacing(0);  // 设置水平间距
    menu->addWidget(back,0,0);
    menu->addWidget(start,1,0);
    menu->addWidget(over,2,0);
    menu->addWidget(inLevel,3,0);
    menu->addWidget(pullBack,0,1);
    menu->addWidget(help,1,1);
    menu->addWidget(backCounter,0,2);
    menu->addWidget(helpCounter,1,2);
    menu->addWidget(tools,0,1);
    menu->addWidget(time,2,1);
    //创建操作菜单

    QHBoxLayout *layoutz=new QHBoxLayout();
    layoutz->addWidget(panel);
    layoutz->addWidget(amps);

    QVBoxLayout *lelayout=new QVBoxLayout();
    lelayout->addLayout(layoutz);
    lelayout->addWidget(tool);

    // 创建总的水平布局
    QHBoxLayout *tohlayout = new QHBoxLayout(this);

    // 将左侧网格布局和右侧拼图布局加入总的水平布局
    tohlayout->addLayout(lelayout);
    tohlayout->addStretch();
    tohlayout->addLayout(rivlayout);
    tohlayout->addStretch();

    connect(back, &QPushButton::clicked, this,[=]()
            {
                writeOut();
                if(gametool!=nullptr)
                    {
                        gametool->close();
                        gametool->deleteLater();
                        gametool=nullptr;
                    }
                emit map::back();
            });

    connect(start,&QPushButton::clicked,this,&map::pause_on);
    //返回按钮
    connect(timer, &QTimer::timeout, this, &map::update);

    connect(over,&QPushButton::clicked,this,&map::check);

    for (int i = 0; i < 36; ++i)
    {
        connect(droplabels[i], &DropLabel::back, this,[=](int a,int b) {
            forState(a,b);
        });
    }
    for (int i = 0; i < 36; ++i)
    {
        connect(droplabels[i], &DropLabel::zero, this,&map::reZero);
    }
    connect(pullBack,&QPushButton::clicked,this,&map::toBack);
    connect(help,&QPushButton::clicked,this,&map::helpMe);
    connect(inLevel,&QPushButton::clicked,this,&map::callLevel);
    connect(tools,&QPushButton::clicked,this,&map::callTools);

};

map::~map()
{
    if(level!=nullptr)
    {
        delete level;
    }
    level=nullptr;
    if(gametool!=nullptr)
    {
        delete gametool;
    }
    gametool=nullptr;
};

void map::readmap(int* _map,int*_solution)
{
    for(int i=0;i<36;i++)
    {
        workmap[i]=_map[i];
    }
    for(int i=0;i<7;i++)
    {
        solution[i]=_solution[i];
    }
}

void map::putmap()
{
    cleanBack();
    //清空提示，回溯
    start->setText("开始");
    start->putText("开始");
    start->setIcon(QIcon(":/image/stop.png"));

    nowtime = QDateTime::currentDateTime(); // 确保nowtime是最新的当前时间
    QTime t_time(0, 0);
    time->setText(t_time.toString("mm:ss.zzz"));
    //设置时间标签为初始时间

    for(int i=0;i<36;i++)
    {
        droplabels[i]->setAcceptDrops(false);
    }
    //禁止拖拽

    state=false;
    //当前开关状态

    QListWidgetItem *item0 = list->item(1);
    QListWidgetItem *item1 = list->item(2);
    QListWidgetItem *item2 = list->item(3);
    QListWidgetItem *item3 = list->item(4);
    QListWidgetItem *item4 = list->item(5);

    item0->setText(nowUser[0]);
    item1->setText("困难通过数\n"+nowUser[2]);
    item2->setText("关卡通过表\n"+nowUser[3]);
    item3->setText("当前积分\n"+nowUser[4]);
    switch(module)
    {
    case 0:
        item4->setText("当前为关卡模式");
        break;
    case 1:
        item4->setText("当前为困难模式");
        break;
    case 2:
        item4->setText("当前为娱乐模式");
        break;
    case 3:
        item4->setText("当前为存档模式");
        break;
    }

    backCounter->setText("0");
    helpCounter->setText("0");
    //计数器设置

    //设置图片
    QPixmap map1(":/image/xr.png");
    QPixmap map2(":/image/or.png");
    QPixmap map3(":/image/tr.png");
    QPixmap map4(":/image/sr.png");

    //添加图片和拼图到网格布局
    for(int i = 0; i < 6; i++)
    {
        for(int j = 0; j < 6; j++)
        {
            int index = i * 6 + j;
            DropLabel *dropLabel = droplabels[index];
            QLabel *picLabel = piclabel[index];
            //二者对应的指针

            dropLabel->setText("0");
            int temp=workmap[index];

            switch(temp)
            {
            case 1:
                picLabel->setPixmap(map1);
                break;
            case 2:
                picLabel->setPixmap(map2);
                break;
            case 3:
                picLabel->setPixmap(map3);
                break;
            case 4:
                picLabel->setPixmap(map4);
                break;
            }
            //给36个图片

            picLabel->setFixedSize(80,80);
            picLabel->setScaledContents(true);
            gridLayout->addWidget(picLabel, i, j);
            dropLabel->raise();
        }
    }
    if (timer->isActive()) {
        timer->stop();
    }
    //判断计时器是否在工作

    lasttime = QDateTime::currentDateTime();
    // 重置暂停相关的时间记录

    tools->hide();
    pullBack->show();

    if(module==2)
    {
        tools->show();
        pullBack->hide();
        helpCounter->setText("X");
        backCounter->setText("X");
    }
}

void map::pause_on()
{
    if(state==true)
    {

        lasttime = QDateTime::currentDateTime(); // 记录暂停时的时间
        timer->stop();
        for(int i=0;i<36;i++)
        {
            droplabels[i]->setAcceptDrops(false);
        }
        state=false;
        start->setText("开始");
        start->putText("开始");
    }
    else
    {
        // timer->start(10);
        for(int i=0;i<36;i++)
        {
            droplabels[i]->setAcceptDrops(true);
        }
        state=true;
        start->setText("暂停");
        start->putText("暂停");
        timer->start(10);
        qint64 elapsedPausedTime = lasttime.msecsTo(QDateTime::currentDateTime());
        nowtime = nowtime.addMSecs(elapsedPausedTime);
    }
}
//根据当前状态修改是否能继续游戏

void map::update()
{
    qint64 elapsedTime = nowtime.msecsTo(QDateTime::currentDateTime());

    // 将时间转换成字符串并设置给QLabel
    QTime t_time(0, 0);
    t_time = t_time.addMSecs(elapsedTime);
    time->setText(t_time.toString("mm:ss.zzz"));
}

void map::check()
{
    timer->stop();
    //暂停计时器
    qint64 elapsedTime = nowtime.msecsTo(QDateTime::currentDateTime());
    // 将时间转换成字符串并设置给QLabel
    QTime t_time(0, 0);
    t_time = t_time.addMSecs(elapsedTime);

    now_time=t_time.toString("mm:ss.zzz");
    //准备工作完成

    bool end=true;
    int empt=0;
    for(int i=0;i<36;i++)
    {
        empt=droplabels[i]->text().toInt();
        switch(workmap[i])
        {
        case 4:
            if(empt!=4)
            {
                end=false;
            }
            break;
        case 3:
            if(empt!=3&&empt!=1)
            {
                end=false;
            }
            break;
        case 2:
            if(empt!=2&&empt!=0)
            {
                end=false;
            }
            break;
        case 1:
            if(empt!=0)
            {
                end=false;
            }
            break;
        }
        droplabels[i]->setText("0");
    }
    if(end==true)
    {
        dialog *mess1=new dialog();
        mess1->setMessage("没想到让你赢了");
        mess1->exec();
        mess1->deleteLater();

        calculate();
        //计算积分

        switch(module)
        {
        case 0:
            nowUser[3][nowIndex]='Y';
            break;
        case 1:
            int empt=nowUser[2].toInt();
            empt++;
            nowUser[2]=QString::number(empt);
            //通关信息
        }
        //统计过关数和信息

        //统计分数和用户数据修改
        if(nowUser[0]!="Null")
        {
            switch(module)
            {
            case 0:
                compare();
                //修改关卡信息,积分榜
                break;
            case 1:
                empt++;
                nowUser[2]=QString::number(empt);
                compare();
                //计入排行榜
            }
        }
        //三个模式下的各自策略
    }

    else
    {
        dialog *mess2=new dialog();
        mess2->setMessage("呕吼失败辣");
        mess2->exec();
    }
    state=false;
    start->setText("开始");
    start->putText("开始");
    //开始重置
    //回溯
    cleanBack();
    // 重置当前时间显示
    lasttime = QDateTime::currentDateTime();
    // 记录暂停时的时间

    timer->stop();
    //暂停计时器

    nowtime = QDateTime::currentDateTime(); // 确保nowtime是最新的当前时间
    QTime d_time(0, 0);
    time->setText(d_time.toString("mm:ss.zzz"));
    // 设置时间标签为初始时间

    QListWidgetItem *item1 = list->item(2);
    QListWidgetItem *item2 = list->item(3);
    QListWidgetItem *item3 = list->item(4);
    item1->setText("困难通过数\n"+nowUser[2]);
    item2->setText("关卡通过表\n"+nowUser[3]);
    item3->setText("当前积分\n"+nowUser[4]);

}

void map::forState(int i,int post)
{
    if(module==2)
    {
        return;
    }
    i--;
    uselabel[i]->hide();
    dropBack.push_back(std::vector<QString>(36));
    dragBack.push_back(i);
    helpInt[i]=post;
    for(int j=0;j<36;j++)
    {
        dropBack[dropBack.size()-1][j]=droplabels[j]->text();
    }
    int empt=dropBack.size();
    QString _empt=QString::number(empt);
    backCounter->setText(_empt);

    int a=0;
    for(int i=0;i<7;i++)
    {
        if(helpInt[i]==solution[i])
            a++;
    }
    QString _empt1=QString::number(a);
    helpCounter->setText(_empt1);
}

void map::cleanBack()
{
    dropBack.clear();
    dragBack.clear();
    now_back=0;
    now_help=0;
    for(int i=0;i<7;i++)
    {
        helpInt[i]=-1;
    }
    for(int i=0;i<7;i++)
    {
        uselabel[i]->show();
    }
    helpCounter->setText("0");
    backCounter->setText("0");

    fault=0;
}

void map::toBack()
{
    if(module==2)
    {
        dialog* t=new dialog(this);
        t->setMessage("娱乐挑战模式无法撤回");
        t->exec();
        t->deleteLater();
        return;
    }
    //模式设置
    QString temp=backCounter->text();

    int _temp=temp.toInt();
    _temp--;

    if(_temp>=0)
    {
        fault++;
        now_back++;
        for(int i=0;i<36;i++)
        {
            droplabels[i]->setText(dropBack[_temp][i]);
        }
        uselabel[dragBack[_temp]]->show();
        temp=QString::number(_temp);
        backCounter->setText(temp);
        int nowBack=dragBack[_temp];
        dropBack.pop_back();
        dragBack.pop_back();
        helpInt[nowBack]=-1;
    }
    int a=0;
    for(int i=0;i<7;i++)
    {
        if(helpInt[i]==solution[i])
            a++;
    }
    QString _empt1=QString::number(a);
    helpCounter->setText(_empt1);

}

void map::helpMe()
{
    if(module==2)
    {
        dialog* t=new dialog(this);
        t->setMessage("娱乐挑战模式无法获得帮助");
        t->exec();
        t->deleteLater();
        return;
    }
    for(int i=0;i<7;i++)
    {
        if(solution[i]!=helpInt[i])
        {
            if(solution[i]==-1)
            {
                dialog* temp=new dialog(this);
                temp->setMessage("第"+QString::number(i+1)+"图片不应被放置");
                temp->exec();
                temp->deleteLater();
                return;

            }
            dialog* temp=new dialog(this);

            int x=solution[i]/6+1;
            int y=solution[i]%6+1;
            temp->setMessage("第"+QString::number(i+1)+"图片的坐标为：第"+QString::number(x)+"列，第"+QString::number(y)+"排");

            temp->exec();
            temp->deleteLater();
            now_help++;
            fault++;
            return;
        }
    }

    dialog* temp=new dialog(this);
    temp->setMessage("快去交卷");
    temp->exec();
    // temp->gameMode();
    // temp->show();
}

void map::setIn(int i)
{
    nowIndex=i;
    QString a="level"+QString::number(i)+".bin";

    QFile file(a);

    QDataStream in(&file);
    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "无法打开文件";
        return;
    }
    in>>*level;
}

void map::compare()
{
    level->liCheckLevel(nowUser,now_time);
}

void map::callLevel()
{
    if(module==2||module==3)
    {
        dialog* t=new dialog(this);
        t->setMessage("此模式无使用榜单的意义");
        t->exec();
        t->deleteLater();
        return;
    }
    //模式设置
    if(nowUser[0]=="Null")
    {
        dialog* tip=new dialog(this);
        tip->setMessage("游客不能访问排行榜");
        tip->exec();
        return;
    }
    dialog *Dialog=new dialog();
    Dialog->setLevel(*level,horHeaders);
    Dialog->exec();
}

void map::humanMap()
{
    QFile file("basemap.bin");
    if (!file.open(QIODevice::Append))
    {
        qDebug() << "Failed to open file.";
        return;
    }

    QDataStream ifs(&file);

    for(int i=0;i<36;i++)
    {
        ifs<<droplabels[i]->text().toInt();
    }

    for(int i=0;i<7;i++)
    {
        ifs<<helpInt[i];
    }

    file.close();

    qDebug()<<"完成";
}

void map::nullMap()
{
    for(int i=0;i<36;i++)
    {
        workmap[i]=0;
    }
    for(int i=0;i<7;i++)
    {
        helpInt[i]=-1;
    }
}

void map::popLevel()
{
    inLevel->hide();
}

void map::setModule(int n)
{
    module=n;
}

void map::calculate()
{
    int a = now_time.mid(0, 2).toInt();  // 提取前两个字符
    int b= now_time.mid(3, 2).toInt();  // 提取中间两个字符，从索引3开始
    int c= now_time.mid(6, 3).toInt();
    double total=a+b*0.01+c*0.001;
    int score=nowUser[4].toInt();;

    switch(module)
    {
    case 0:
        if(nowUser[3][nowIndex]!='Y')
        {
            score-=fault*20;
            score+=100;
            if(total<3)
                score+=300;
            else
            {
                score+=900/total;
            }
        }
        break;

    case 1:
        score-=fault*30;
        if(total<1)
            score+=400;
        else
        {
            score+=1000/total;
        }
        break;
    case 2:
        score+=100;
    case 3:
        score+=20;
    }

    nowUser[4]=QString::number(score);

}

void map::callTools()
{
    gametool=new dialog(this);
    gametool->gameMode();
    gametool->show();
    tools->hide();
}

void map::writeOut()
{
    if(module==1||module==0)
    {
        QString a="level"+QString::number(nowIndex)+".bin";

        QFile file(a);

        if (!file.open(QIODevice::WriteOnly))
        {
            qDebug() << "无法打开文件";
            return;
        }

        QDataStream out(&file);

        out<<*level;

        file.close();
    }
}

void map::reZero(int i)
{
    QPixmap map1(":/image/xr.png");
    workmap[i]=1;
    droplabels[i]->setPixmap(map1);

}
