#include "initial.h"

initial::initial(Widget *parent)
    :Widget(parent)
    ,stack(new QStackedWidget)
{    setWindowTitle("植此青绿");
    setWindowIcon(QIcon(":/image/1wp.png"));

    QLabel *tital=new QLabel(this);
    QPixmap _map1(":/image/plant.png");
    tital->setPixmap(_map1);
    tital->setFixedSize(600,400);
    //标题

    QWidget* startIn=new QWidget(this);
    //窗口

    QGridLayout* allIn =new QGridLayout(startIn);
    allIn->setHorizontalSpacing(300);
    allIn->setVerticalSpacing(10);
    allIn->setSizeConstraint(QLayout::SetFixedSize);
    //布局格式

    button* startL=new button("开始游戏",":/image/game.png",startIn);
    startL->setFixedSize(480,120);
    startL->setIconSize(QSize(450, 100));
    //按钮1

    button* help=new button("帮助",":/image/help.png",startIn);
    help->setFixedSize(480,120);
    help->setIconSize(QSize(450, 100));
    //按钮2

    button* out=new button("退出",":/image/exit.png",startIn);
    out->setFixedSize(480,120);
    out->setIconSize(QSize(450, 100));
    //按钮3

    QWidget *temp1=new QWidget();
    temp1->setFixedSize(300,200);
    QWidget *temp2=new QWidget();
    temp2->setFixedSize(200,200);
    //占位窗口

    allIn->addWidget(temp1,0,0);
    allIn->addWidget(temp2,0,2);
    allIn->addWidget(tital,0,1);
    //排布
    allIn->addWidget(startL,1,1);
    allIn->addWidget(out,2,1);
    allIn->addWidget(help,3,1);
    //排布

    stack->addWidget(this);
    Start=new start(stack,this);
    stack->addWidget(Start);
    stack->addWidget(this);
    stack->setCurrentWidget(this);
    stack->show();
    //页面添加

    connect(out,&QPushButton::clicked,this,&initial::turnOut);
    connect(startL,&QPushButton::clicked,this,&initial::goIn);
    connect(help,&QPushButton::clicked,this,&initial::help);
    connect(Start,&start::reInitial,this,&initial::setPage);
    //槽函数
}

initial::~initial()
{
    delete menu;
}

void initial::turnOut()
{
    QCoreApplication::quit();
}

void initial::goIn()
{
    stack->setCurrentWidget(Start);
}

void initial::store()
{
    Start->preStore();
}

void initial::help()
{
    dialog *h=new dialog(this);
    h->help();
    h->show();
}

void initial::setPage()
{
    stack->setCurrentWidget(this);
}
