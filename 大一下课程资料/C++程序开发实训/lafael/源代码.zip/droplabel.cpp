#include "DropLabel.h"
DropLabel::DropLabel(QWidget *parent)
    : QLabel(parent)
{
    setStyleSheet(R"(
    QLabel {
        font-size: 20px; /* 增大字体 */
        color: #000000
    }
    )");
    setAcceptDrops(false); // 接受拖放事件
}

void DropLabel::dragEnterEvent(QDragEnterEvent *event)
{
    QString droppedText = event->mimeData()->text();
    int empt=droppedText.toInt();
    switch(empt)
    {
    case 1:
        if (post % 6 < 3&&post/6<3)
        {
            this->setStyleSheet("color: blue;");
            event->acceptProposedAction();
        }
        else
        {
            this->setStyleSheet("color: red;");
            event->ignore();
        }
        break;
    case 2:
    case 3:
    case 9:
    case 10:
        if (post % 6 < 4&&post/6<4)
        {
            this->setStyleSheet("color: blue;");
            event->acceptProposedAction();
        }
        else
        {
            this->setStyleSheet("color: red;");
            event->ignore();
        }
        break;
    case 4:
    case 5:
    case 8:
    case 11:
        if (post % 6 < 5&&post/6<5)
        {
            this->setStyleSheet("color: blue;");
            event->acceptProposedAction();
        }
        else
        {
            this->setStyleSheet("color: red;");
            event->ignore();
        }
        break;
    case 6:
    case 7:
        this->setStyleSheet("color: blue;");
        event->acceptProposedAction();
        break;
    }
}
//能写入的一定是合法的

void DropLabel::dropEvent(QDropEvent *event)
{
    QString droppedText = event->mimeData()->text();
    int empt=droppedText.toInt();

    emit DropLabel::back(empt,post);

    for(int i=0;i<36;i++)
    {
        droplabel[i]->setStyleSheet("color: black;");
    }

    switch(empt)
    {
    case 1:
        for (int i = 0,posi=post; i < 4; i++,posi+=6)
        {
            findlabel(posi);
            findlabel(posi+1);
            findlabel(posi+2);
            findlabel(posi+3);
        }
        event->accept();
        break;
    case 2:
    case 3:
        for (int i = 0,posi=post; i < 3; i++,posi+=6)
        {
            findlabel(posi);
            findlabel(posi+1);
            findlabel(posi+2);
        }
        event->accept();
        break;
    case 4:
    case 5:
        for (int i = 0,posi=post; i < 2; i++,posi+=6) // 16格有点多，循环吧
        {
            findlabel(posi);
            findlabel(posi+1);
        }
        event->accept();
        break;
    case 6:
    case 7:
        findlabel(post);
        event->accept();
        break;
    case 8:
        for (int i = 0,posi=post; i < 2; i++,posi+=6) // 16格有点多，循环吧
        {
            boom(posi);
            boom(posi+1);
        }
        event->accept();
        break;
    case 11:
        for (int i = 0,posi=post; i < 2; i++,posi+=6) // 16格有点多，循环吧
        {
            toZero(posi);
            toZero(posi+1);
        }
        event->accept();
        break;
    case 10:
        for (int i = 0,posi=post; i < 3; i++,posi+=6)
        {
            decrease(posi);
            decrease(posi+1);
            decrease(posi+2);
        }
        event->accept();
        break;


    }
}

void DropLabel::putpost(int i,std::vector<DropLabel*> labels)
{
    post=i;
    droplabel=labels;
}

void DropLabel::findlabel(int i)
{
    DropLabel *dropLabel =droplabel[i];// 转换为DropLabel
    dropLabel->checkchar();
}

void DropLabel::checkchar()
{
    QString a=text();
    int b=a.toInt();
    b++;
    a=QString::number(b);
    setText(a);
}

void DropLabel::boom(int i)
{
    DropLabel *dropLabel =droplabel[i];// 转换为DropLabel
    QString a=dropLabel->text();
    int b=a.toInt();
    b=0;
    a=QString::number(b);
    dropLabel->setText(a);
}

void DropLabel::toZero(int i)
{
    DropLabel *dropLabel =droplabel[i];// 转换为DropLabel
    QString a=dropLabel->text();
    int b=a.toInt();
    b=5;
    a=QString::number(b);
    dropLabel->setText(a);
    emit zero(i);
}
//归零
void DropLabel::decrease(int i)
{
    DropLabel *dropLabel =droplabel[i];// 转换为DropLabel
    QString a=dropLabel->text();
    int b=a.toInt();
    b--;
    if(b<0)
        b=0;
    a=QString::number(b);
    dropLabel->setText(a);
}
//-1
