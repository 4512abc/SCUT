#include "widget.h"
// #include "base.h"
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
// , base(nullptr)
// , stack(new QStackedWidget)
{
    QWidget::setWindowTitle("植此青绿");
    QWidget::setWindowIcon(QIcon(":/image/1wp.png"));

    backgroundLabel=(new QLabel(this));
    // 设置布局
    setMaximumSize(1800,1200);
    setMinimumSize(1200,900);
    // 加载并设置背景图片
    QPixmap backgroundPixmap(":/image/tree.png");
    backgroundLabel->setPixmap(backgroundPixmap);
    backgroundLabel->setScaledContents(true);

    ui->setupUi(this);

    // 加载背景图片
    // QPixmap image();
    // // resize(1800,1200);

    // // 设置背景图片
    // QPalette palette;
    // palette.setBrush(this->backgroundRole(), QBrush(image));
    // this->setPalette(palette);
    // this->setAutoFillBackground(true);
}

Widget::~Widget()
{
    // if(stack!=nullptr)
    //     delete stack;
    // stack=nullptr;
    if(ui!=nullptr)
        delete ui;
    ui=nullptr;
}

void Widget::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    backgroundLabel->resize(size());
}

std::vector<QString> Widget::nowUser=std::vector<QString>(6)={"Null","XXX","0","NNNNNN","0"};
//名称，密码，通过挑战地图情况，六关通过情况，用时多少,积分


