#include "game.h"
game::game(QStackedWidget* s,Widget *parent)
    : Widget(parent)
    ,   stack(s)
    , previousPage(0)
{


    horHeaders=QStringList()<< "玩家" << "困难通关数" << "通过关卡数" << "总积分";
    Level=new ranking(4);

    QVBoxLayout *vlayout = new QVBoxLayout(this); // 垂直布局

    QWidget *buttonWidget = new QWidget(this); // 包含按钮的小部件

    QWidget *scores=new QWidget(this);//包含分数的小部件

    QWidget *reoperation=new QWidget(this);//返回等

    models.push_back(new button("关卡模式",":/image/base.png",buttonWidget));
    models.push_back(new button("挑战模式",":/image/hard.png", buttonWidget));
    models.push_back(new button("存储回顾",":/image/registe.png", buttonWidget)); // 创建三个按钮
    score = new button("积分榜",":/image/level.png",scores);//积分榜按钮
    exit=new button("退出",":/image/exit.png",reoperation);
    reopen=new button("注销",":/image/back.png",reoperation);
    //大小策略

    score->setFixedSize(360,160);
    score->setIconSize(QSize(160,130));

    for(QPushButton *button : models)
    {
        button->setFixedSize(QSize(320, 160));
        button->setIconSize(QSize(130, 130));
    }

    exit->setFixedSize(QSize(320, 160));
    exit->setIconSize(QSize(130, 130));
    reopen->setFixedSize(QSize(320, 160));
    reopen->setIconSize(QSize(130, 130));

    //为四个按钮设置大小

    QHBoxLayout *blayout = new QHBoxLayout(buttonWidget);
    blayout->setSpacing(100);
    // 设置组件之间的间距为100像素

    QHBoxLayout *slayout = new QHBoxLayout(scores);
    //两个水平布局（小部件）

    QHBoxLayout *dlayout=new QHBoxLayout(reoperation);

    for(QPushButton *button : models)
    {
        blayout->addWidget(button);
    }
    //为按钮设置

    slayout->addStretch();
    slayout->addWidget(score);
    slayout->addStretch();
    //为积分榜设置

    dlayout->addStretch();
    dlayout->addWidget(exit);
    dlayout->addWidget(reopen);
    dlayout->addStretch();

    //vlayout->addStretch(); // 垂直布局在顶部放置一个伸缩空间，将水平布局推到底部
    vlayout->addWidget(scores);
    //vlayout->addStretch(); // 在水平布局和窗口底部之间添加一个伸缩空间
    vlayout->addWidget(buttonWidget);
    vlayout->addWidget(reoperation);
    //为垂直布局设置

    connect(models[0], &QPushButton::clicked, this, &game::Clickbase);
    // 关卡模式槽函数
    connect(models[1], &QPushButton::clicked, this, &game::ClickHard);
    // 挑战模式槽函数
    connect(models[2],&QPushButton::clicked, this, &game::ClickStorage);

    stack->addWidget(this);
    Base = new base(this);
    stack->addWidget(Base);
    Hard=new hard(this);
    stack->addWidget(Hard);
    Map=new map(this);
    Storage=new storage(this);
    stack->addWidget(Storage);
    stack->addWidget(Map);
    stack->setCurrentWidget(this);
    stack->show();

    connect(Base,&base::repage,this,&game::repage);
    //返回到关卡模式
    connect(Hard,&hard::repage,this,&game::repage);
    //返回
    connect(Base, &base::tomap, this,&game::setBasePage);
    //关卡模式的地图返回
    connect(Hard,&hard::Cretomap,this,&game::setSysPage);
    connect(Hard,&hard::HumtoMap,this,&game::setHumPage);

    connect(Map, &map::back,this,&game::relemap);
    //检测map的返回操作，若有，则将记录的页面给上去

    connect(score,&QPushButton::clicked, this, &game::checkLevel);
    //更新排行榜
    connect(Storage,&storage::over, this,&game::setPastPage);
    //设置回顾
    connect(Storage,&storage::repage, this,&game::repage);
    //回顾的返回
    connect(exit,&QPushButton::clicked,this,&game::toExit);
    connect(reopen,&QPushButton::clicked,this,&game::toReOpen);

    setlevel();
    //填入数组


}
void game::setBasePage(int i)
{
    previousPage = stack->currentIndex();
    //初始化
    Base->readMap(i);
    //读取地图

    //读取排行榜
    Map->readmap(Base->reBaseMap(),Base->reBaseSolution());
    //填充地图

    Map->setModule(0);
    //设置模式

    Map->putmap();
    //初始化等操作

    Map->setIn(i);
    //调用对应数组

    stack->setCurrentWidget(Map);
    //添加到页面
}

void game::setSysPage()
{
    previousPage = stack->currentIndex();
    dialog *hardLevel=new dialog(this);
    hardLevel->slider(Hard->reHlevel());
    hardLevel->exec();
    Hard->createMap();

    Map->readmap(Hard->reMap(),Hard->reSolution());

    Map->setModule(1);
    //设置模式

    Map->putmap();
    //初始

    Map->setIn(6);
    //调用对应数组

    stack->setCurrentWidget(Map);
    //添加到页面
}

void game::setHumPage()
{
    previousPage = stack->currentIndex();
    //初始化
    dialog* humMap=new dialog(this);


    humMap->getMap();
    connect(humMap,&dialog::outData,this,&game::midMap);
    //调用对应,条件调出地图
    humMap->exec();
    humMap->deleteLater();
}

void game::setPastPage(int i)
{
    previousPage = stack->currentIndex();
    //初始化
    Storage->reSet();
    Storage->readMap(i);
    //读取地图

    Map->readmap(Storage->reMap(),Storage->reSolution());

    Map->setModule(3);
    //设置模式

    Map->putmap();
    //初始

    stack->setCurrentWidget(Map);
    //添加到页面

}
void game::Clickbase()
{
    stack->setCurrentWidget(Base);
}

void game::ClickHard()
{
    stack->setCurrentWidget(Hard);
}

void game::ClickStorage()
{
    Storage->reSet();
    stack->setCurrentWidget(Storage);
    //获取应用数据目录
}
void game::repage()
{
    stack->setCurrentWidget(this);
}

game::~game()
{
    if(Level!=nullptr)
    {
        delete Level;
    }
    Level=nullptr;
}

void game::relemap()
{
    stack->setCurrentIndex(previousPage);
    //设置当前页面
    // Map->dele();
    // //释放关卡
}

void game::setlevel()
{
    QFile file("totalLevel.bin");
    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "无法打开文件";
    }

    QDataStream in(&file);

    in>>*Level;

    file.close();
}

void game::checkLevel()
{
    dialog *Dialog=new dialog();
    if(nowUser[0]=="Null")
    {
        Dialog->setMessage("游客不能访问排行榜");
        Dialog->exec();
        return;
    }

    Level->toCheckLevel(nowUser);
    //对比

    Dialog->setLevel(*Level,horHeaders);
    Dialog->exec();
    //调出排行榜
    Dialog->deleteLater();
}

void game::writeLevel()
{
    if(nowUser[0]!="Null"&&nowUser[0]!="")
    {
        Level->toCheckLevel(nowUser);
    }

    QFile file("totalLevel.bin");
    if (!file.open(QIODevice::WriteOnly))
    {
        qDebug() << "无法打开文件";
    }

    QDataStream out(&file);

    out<<*Level;

    file.close();
}

void game::midMap(int* a)
{
    int solution[7]={-1};
    Hard->tryCheck(a);
    Map->readmap(a,solution);
    Map->setModule(2);
    Map->putmap();

    stack->setCurrentWidget(Map);
    //添加到页面

}

void game::toExit()
{
    emit Exit();
}

void game::toReOpen()
{
    emit Reopen();
}
