#include "dialog.h"

dialog::dialog(QWidget *parent)
    : QDialog(parent)
{
    setStyleSheet(R"(
    QPushButton {
        padding: 10px;
        background-color: rgba(130, 146, 179, 20);
        border: 1px solid black; /* 边框 */
        font-size: 40px; /* 增大字体 */
        color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 1,
            stop: 0 #318d3c, stop: 0.3 #7cbd70, stop: 1 #cbca62
        ); /* 文字渐变 */
    }
    QPushButton::icon {
        padding-right: 20px; /* 调整图标和文字的间距 */
    }
    )");
    setWindowFlags(windowFlags() & ~Qt::WindowCloseButtonHint);

    // 自定义窗口背景以隐藏标题栏
    setWindowFlags(windowFlags() | Qt::CustomizeWindowHint | Qt::WindowTitleHint);
}

void dialog::setLevel( ranking level,QStringList horHeaders)
{
    QWidget::setWindowTitle("排行榜");
    QWidget::setWindowIcon(QIcon(":/image/3wp.png"));
    this->setStyleSheet(
        "QDialog {"
        "    background-image: url(:/image/backlevel.png);"
        "    background-repeat: no-repeat;"
        "    background-position: center;"
        "}"
        );
    QStringList verHeaders;
    verHeaders << "玩家序列 1" << "玩家序列 2" << "玩家序列 3" << "玩家序列 4" << "玩家序列 5"
               << "玩家序列 6" << "玩家序列 7" << "玩家序列 8" << "玩家序列 9" << "玩家序列 10";

    setFixedSize(700,950);

    // 创建 QTableWidget
    QTableWidget *levelTable = new QTableWidget(this);
    levelTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    levelTable->setFixedSize(700,600);
    levelTable->setRowCount(10); // 设置行数
    levelTable->setColumnCount(level.reData()); // 设置列数
    levelTable->setVerticalHeaderLabels(verHeaders);
    levelTable->setHorizontalHeaderLabels(horHeaders);

    // 设置每个单元格的大小
    for (int i = 0; i < 10; i++) {
        levelTable->setRowHeight(i, 70); // 设置第 i 行的高度为 40 像素
    }
    for (int j = 0; j < level.reData(); j++) {
        levelTable->setColumnWidth(j, 130); // 设置第 j 列的宽度为 100 像素
    }

    std::vector<std::vector<QString>> temp=level.reVector();
    // 填充表格数据
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < level.reData(); j++)
        {
            QTableWidgetItem *item = new QTableWidgetItem(temp[i][j]);
            item->setTextAlignment(Qt::AlignCenter);
            levelTable->setItem(i, j, item);
        }
    }

    //创建按钮
    button *_return=new button("返回",":/image/re.png",this);
    _return->setFixedSize(340,120);
    _return->setIconSize(QSize(240, 100));
    QVBoxLayout *layout=new QVBoxLayout();

    layout->addWidget(levelTable);
    layout->addWidget(_return);


    connect(_return,&QPushButton::clicked, this, &dialog::returnout);
    // 将表格添加到主窗口布局中
    setLayout(layout);
}

void dialog::returnout()
{
    close();
}

void dialog::setMessage(QString a)
{
    QWidget::setWindowTitle("提醒");
    QWidget::setWindowIcon(QIcon(":/image/2wp.png"));

    setFixedSize(500,600);

    QGridLayout *menu=new QGridLayout(this);
    menu->setHorizontalSpacing(0);
    menu->setVerticalSpacing(0);

    setStyleSheet(
        "QDialog {"
        "    background-image: url(:/image/backMessage.png);"
        "    background-repeat: no-repeat;"
        "    background-position: center;"
        "}"
        "QLabel {"
        "    padding: 10px;"
        "    background-color: rgba(201, 224, 171, 50); /* 背景部分透明 */"
        "    border: 1px solid black; /* 边框 */"
        "    font-size: 28px; /* 增大字体 */"
        "    color: #cbca62"
        "}"
        );

    QLabel *tital=new QLabel(a,this);
    tital->setFixedSize(450,300);
    tital->setAlignment(Qt::AlignCenter);

    button *set=new button("确认",":/image/start.png",this);
    set->setFixedSize(450,100);
    set->setIconSize(QSize(300, 100));

    menu->addWidget(tital,0,0);
    menu->addWidget(set,1,0);

    connect(set,&QPushButton::clicked, this, &dialog::returnout);

    setLayout(menu);
}

void dialog::gameMode()
{

    this->setStyleSheet(
        "QDialog {"
        "    background-image: url(:/image/backlevel.png);"
        "    background-repeat: no-repeat;"
        "    background-position: center;"
        "}"
        );

    QWidget::setWindowTitle("道具大赏");
    QWidget::setWindowIcon(QIcon(":/image/4wp.png"));

    setFixedSize(340,800);

    QListWidget *list=new QListWidget(this);

    QListWidgetItem *dy1=new QListWidgetItem(list);
    dy1->setSizeHint(QSize(80,80));
    QListWidgetItem *dy2=new QListWidgetItem(list);
    dy2->setSizeHint(QSize(160,160));
    QListWidgetItem *dy4=new QListWidgetItem(list);
    dy4->setSizeHint(QSize(320,320));
    QListWidgetItem *dy5=new QListWidgetItem(list);
    dy5->setSizeHint(QSize(160,160));

    QWidget *qw1=new QWidget(list);
    qw1->setFixedSize(80,80);
    QWidget *qw2=new QWidget(list);
    qw2->setFixedSize(160,160);
    QWidget *qw4=new QWidget(list);
    qw4->setFixedSize(320,320);
    QWidget *qw5=new QWidget(list);
    qw5->setFixedSize(160,160);

    QPixmap map1(":/image/tree67.png");
    QPixmap map2(":/image/4TNT.png");
    QPixmap map4(":/image/9T-1.png");
    QPixmap map5(":/image/4T0.png");

    DragLabel *pi1=new DragLabel(qw1);
    DragLabel *pi2=new DragLabel(qw2);
    DragLabel *pi4=new DragLabel(qw4);
    DragLabel *pi5=new DragLabel(qw5);

    pi1->setFixedSize(80,80);
    pi1->setPixmap(map1);
    pi1->put_text("7");
    pi1->setScaledContents(true);

    pi2->setFixedSize(160,160);
    pi2->setPixmap(map2);
    pi2->put_text("8");
    pi2->setScaledContents(true);

    pi4->setFixedSize(240,240);
    pi4->setPixmap(map4);
    pi4->put_text("10");
    pi4->setScaledContents(true);

    pi5->setFixedSize(160,160);
    pi5->setPixmap(map5);
    pi5->put_text("11");
    pi5->setScaledContents(true);

    list->setItemWidget(dy1,qw1);
    list->setItemWidget(dy2,qw2);
    list->setItemWidget(dy4,qw4);
    list->setItemWidget(dy5,qw5);
    button *set=new button("结束",":/image/re.png",this);

    QVBoxLayout *layout=new QVBoxLayout();
    layout->addWidget(list);
    layout->addWidget(set);

    connect(set,&QPushButton::clicked, this, &dialog::returnout);

    setLayout(layout);

}

void dialog::getMap()
{
    setFixedSize(600,400);

    setStyleSheet(
        "QDialog {"
        "    background-image: url(:/image/backMessage.png);"
        "    background-repeat: no-repeat;"
        "    background-position: center;"
        "}"
        "QLabel {"
        "    padding: 10px;"
        "    background-color: rgba(201, 224, 171, 50); /* 背景部分透明 */"
        "    border: 1px solid black; /* 边框 */"
        "    font-size: 40px; /* 增大字体 */"
        "    color: #cbca62"
        "}"
        );

    QGridLayout *menu=new QGridLayout(this);
    menu->setHorizontalSpacing(0);
    menu->setVerticalSpacing(0);

    workMap=new QLineEdit(this);
    workMap->setPlaceholderText("只允许输入1，2，3，4，用来表示×，圆，三角，矩形四种地块");
    workMap->setFixedSize(550,60);

    QLabel *number1=new QLabel(this);
    number1->setFixedSize(580,150);
    number1->setText("已输入字符数：0");
    number1->setAlignment(Qt::AlignCenter);

    button *start=new button("完成",":/image/start.png",this);
    start->setFixedSize(280,150);
    start->setIconSize(QSize(150,150));
    start->hide();
    button *_return=new button("返回",":/image/re.png",this);
    _return->setFixedSize(280,150);
    _return->setIconSize(QSize(150,150));

    QHBoxLayout *layout1=new QHBoxLayout();
    layout1->addWidget(start);
    layout1->addWidget(_return);

    menu->addWidget(number1,0,0);
    menu->addWidget(workMap,1,0);
    menu->addWidget(_return,2,0);
    menu->addWidget(start,2,1);

    connect(_return,&QPushButton::clicked, this, &dialog::returnout);
    connect(workMap,&QLineEdit::textEdited,this,[number1](const QString &text)
            {
        number1->setText("已输入字符数："+QString::number(text.length()));
    });
    connect(workMap,&QLineEdit::textEdited,this,[start](const QString &text)
        {
            if(text.length()==36)
            {
                start->show();
            }
            else
                {
                start->hide();
            }
    });
    connect(start,&QPushButton::clicked, this,&dialog::check);

    setLayout(menu);
}


void dialog::check()
{
    QString number=workMap->text();
    for(int i=0;i<36;i++)
    {
        if(number[i]!='1'&&number[i]!='2'&&number[i]!='3'&&number[i]!='4')
        {
            workMap->clear();
            workMap->setPlaceholderText("输入无效");
            return;
        }
    }
    int workmap[36];

    for(int i=0;i<36;i++)
    {
        workmap[i]=number[i].digitValue();
    }

    emit outData(workmap);
    close();

}

void dialog::readUser(std::vector<std::vector<QString>>&users,std::vector<QString>& user)
{
    setStyleSheet(
        "QDialog {"
        "    background-image: url(:/image/backMessage.png);"
        "    background-repeat: no-repeat;"
        "    background-position: center;"
        "}"
        );

    setFixedSize(600,600);

    account=new QLineEdit(this);
    password=new QLineEdit(this);

    account->setPlaceholderText("在此输入账号");
    password->setPlaceholderText("在此输入密码");

    button *start=new button("完成",":/image/start.png",this);
    start->setFixedSize(250,150);
    start->setIconSize(QSize(170,150));
    button *_return=new button("结束",":/image/over.png",this);
    _return->setFixedSize(250,150);
    _return->setIconSize(QSize(170,150));

    QHBoxLayout *layout1=new QHBoxLayout();
    layout1->addWidget(start);
    layout1->addWidget(_return);

    QVBoxLayout *layout2=new QVBoxLayout(this);
    layout2->addWidget(account);
    layout2->addWidget(password);
    layout2->addLayout(layout1);

    connect(_return,&QPushButton::clicked, this, &dialog::returnout);
    connect(start, &QPushButton::clicked, this, [this, &users, &user]() {
        QString enteredAccount = account->text();
        QString enteredPassword = password->text();

        if(enteredAccount==""||enteredAccount=="Null"||enteredAccount=="无效账号"||enteredAccount=="账号重复")
        {
            account->setText("无效账号");
            password->setText("以最后一次合法输入为主");
            return ;
        }
        for (int i=0;i<users.size();i++)
        {
            if (users[i][0]== enteredAccount)
            {
                account->setText("账号重复");
                password->setText("以最后一次合法输入为主");
                return;

            }
        }
        user[0]=enteredAccount;
        user[1]=enteredPassword;
        close();
    });
    setLayout(layout2);
}

void dialog::help()
{
    setStyleSheet(
        "QDialog {"
        "    background-image: url(:/image/backempt.png);"
        "    background-repeat: no-repeat;"
        "    background-position: center;"
        "}"
        "QLabel {"
        "    padding: 10px;"
        "    background-color: rgba(201, 224, 171, 50); /* 背景部分透明 */"
        "    border: 1px solid black; /* 边框 */"
        "    font-size: 25px; /* 增大字体 */"
        "    color: #cbca62"
        "}"
        );

    setFixedSize(900,910);

    QWidget* widget=new QWidget(this);
    widget->setFixedSize(730,910);
    QGridLayout*gridLayout = new QGridLayout(widget);  // 设置垂直间距

    QLabel* label_t0=new QLabel(widget);
    QLabel* label_t1=new QLabel(widget);
    QLabel* label_t2=new QLabel(widget);
    QLabel* label_t3=new QLabel(widget);
    QLabel* label_t4=new QLabel(widget);
    QLabel* label_t5=new QLabel(widget);
    QLabel* label0=new QLabel(widget);
    QLabel* label1=new QLabel(widget);
    QLabel* label2=new QLabel(widget);
    QLabel* label3=new QLabel(widget);
    QLabel* label4=new QLabel(widget);

    label_t0->setFixedSize(720,100);
    label_t0->setText("玩法规则：\n关卡模式，随机挑战，存档回顾通关以获得积分");

    label0->setFixedSize(200,100);
    label0->setPixmap(QPixmap(":/image/xr.png"));
    label_t1->setFixedSize(520,100);
    label_t1->setText("该图标所示地块的最终状态:\n不包含任何树木");

    label1->setFixedSize(200,100);
    label1->setPixmap(QPixmap((":/image/tr.png")));
    label_t2->setFixedSize(520,100);
    label_t2->setText("该图标所示地块的最终状态:\n包含一颗或三颗树木");

    label2->setFixedSize(200,100);
    label2->setPixmap(QPixmap((":/image/or.png")));
    label_t3->setFixedSize(520,100);
    label_t3->setText("该图标所示地块的最终状态:\n不包含或两颗树木");

    label3->setFixedSize(200,100);
    label3->setPixmap(QPixmap((":/image/sr.png")));
    label_t4->setFixedSize(520,100);
    label_t4->setText("该图标所示地块的最终状态:\n包含四颗树木");

    label4->setFixedSize(200,180);
    label4->setPixmap(QPixmap((":/image/4T0.png")));

    label_t5->setFixedSize(520,180);
    label_t5->setText("如左侧图片为娱乐模式专属\n具体功效还请自行探索");

    button *set=new button("结束",":/image/re.png",widget);
    set->setFixedSize(200,100);
    set->setIconSize(QSize(100,100));;

    gridLayout->addWidget(label_t0,0,0);
    gridLayout->addWidget(label0,1,0);
    gridLayout->addWidget(label_t1,1,1);
    gridLayout->addWidget(label1,2,0);
    gridLayout->addWidget(label_t2,2,1);
    gridLayout->addWidget(label2,3,0);
    gridLayout->addWidget(label_t3,3,1);
    gridLayout->addWidget(label3,4,0);
    gridLayout->addWidget(label_t4,4,1);
    gridLayout->addWidget(label4,5,0);
    gridLayout->addWidget(label_t5,5,1);
    gridLayout->addWidget(set,7,0);

    connect(set,&QPushButton::clicked, this, &dialog::returnout);

    setLayout(gridLayout);
}

void dialog::slider(double& Hlevel)
{
    setStyleSheet(
        "QDialog {"
        "    background-image: url(:/image/Sback.png);"
        "    background-repeat: no-repeat;"
        "    background-position: center;"
        "}"
        "QLabel {"
        "    padding: 10px;"
        "    background-color: rgba(201, 224, 171, 50); /* 背景部分透明 */"
        "    border: 1px solid black; /* 边框 */"
        "    font-size: 25px; /* 增大字体 */"
        "    color: #cbca62"
        "}"
        );

    setFixedSize(600,500);

    QGridLayout *menu=new QGridLayout(this);
    menu->setHorizontalSpacing(0);
    menu->setVerticalSpacing(0);

    QLabel *number1=new QLabel(this);
    number1->setFixedSize(300,200);
    number1->setText("滑动滑块以调节难度");
    number1->setAlignment(Qt::AlignCenter);

    button *start=new button("完成",":/image/start.png",this);
    start->setFixedSize(250,150);
    start->setIconSize(QSize(150,150));



    QSlider *slider = new QSlider(Qt::Horizontal, this);
    slider->setRange(-100, 100); // 设置范围为-100到100
    slider->setValue(0); // 默认值为0
    slider->setFixedSize(220,150);

    menu->addWidget(slider,0,0);
    menu->addWidget(number1,0,1);
    menu->addWidget(start,1,0);

    connect(slider, &QSlider::valueChanged, [=, &Hlevel](int value) {
        Hlevel = value / 100.0;
        number1->setText(QString("当前难度系数：%1").arg(Hlevel));
    });
     connect(start,&QPushButton::clicked, this, &dialog::returnout);

}
