#ifndef RANKING_H
#define RANKING_H

#include <vector>
#include <QString>
#include <QDataStream>
class ranking
{
   friend QDataStream& operator>>(QDataStream& in, ranking& p);
    friend QDataStream& operator<<(QDataStream& out, ranking& p);
public:
    ranking( int);
    ~ranking();
    void toCheckLevel(std::vector<QString>&);
    //总榜对比
    void liCheckLevel(std::vector<QString>&,QString&);
    //子榜对比
    int reData();
    //返回规模
    std::vector<std::vector<QString>>& reVector();
    //返回数组
    void clear();
    //清空
private:
    int datas;
    //元素数
    std::vector<std::vector<QString>> levelOnes;
    //信息
};

#endif // RANKING_H
