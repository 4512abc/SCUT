#include "base.h"
base::base(QWidget *parent)
    : Widget(parent)
{

    QWidget *ba=new QWidget(this);
    QWidget *empt=new QWidget(this);
    empt->setFixedSize(230,50);

    QGridLayout* all =new QGridLayout(ba);
    all->setHorizontalSpacing(50);
    all->setVerticalSpacing(10);
    all->setSizeConstraint(QLayout::SetFixedSize);
    //大小策略

    for(int i = 0; i < 6; ++i)
    {
        QString path=":/image/t"+QString::number(i+1)+".png";
        QString name = "第" + QString::number(i + 1) + "关"; // 构造按钮名称，例如 "第1关", "第2关", 等等
        bases.push_back(new button(name,path, ba)); // 将按钮添加到 bases 数组中
        bases[i]->setFixedSize(QSize(310, 160));
        bases[i]->setIconSize(QSize(160,160));
    }
    // 设置组件之间的间距为100像素

    back=new button("返回",":/image/re.png",ba);
    back->setFixedSize(310,160);
    back->setIconSize(QSize(160,160));

    help=new button("帮助",":/image/help.png",ba);
    help->setFixedSize(310,160);
    help->setIconSize(QSize(160,160));
    // 初始化按钮任务

    all->addWidget(empt,0,0);
    all->addWidget(help,1,2);
    all->addWidget(bases[0],2,1);
    all->addWidget(bases[1],2,2);
    all->addWidget(bases[2],2,3);
    all->addWidget(bases[3],3,1);
    all->addWidget(bases[4],3,2);
    all->addWidget(bases[5],3,3);
    all->addWidget(back,4,2);

    connect(back,&QPushButton::clicked,this,&base::clickback);
    connect(help,&QPushButton::clicked,this,&base::toHelp);
    // 关卡模式返回

    for(int i=0;i<6;i++)
    {
        connect(bases[i],&QPushButton::clicked,[this, i]() { clicklevel(i); });
    }
    //6个按钮的地图进入
}
base::~base()
{
    for (QPushButton* button : bases)
    {
        delete button;
    }
    if(back!=nullptr)
        delete back;
    back=nullptr;
}

void base::clickback()
{
    emit repage();
}

void base::clicklevel(int i)
{
    emit tomap(i);

}

void base::readMap(int a)
{
    QFile file("basemap.bin");
    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "basemap not open";
        return;
    }

    QDataStream ifs(&file);
    int temp=0;

    for(int i=0;i<43*a;i++)
    {
        ifs>>temp;
    }
    for (int j = 0; j < 36; j++) {
        ifs >>baseMap[j];
    }
    for(int i=0;i<7;i++)
    {
        ifs>>baseSolution[i];
    }
    file.close();
}

int* base::reBaseMap()
{

    return baseMap;
}

int* base::reBaseSolution()
{

    return baseSolution;
}

void base::toHelp()
{
    dialog *help=new dialog(this);
    help->setMessage("这里是关卡模式的帮助页面\n包含了6个关卡，难度逐渐升高\n为每个关卡提供用时排行榜\n本模式会记录用时以便生成积分\n此模式不可刷积分，且积分占比小");
    help->exec();
    help->deleteLater();
}
