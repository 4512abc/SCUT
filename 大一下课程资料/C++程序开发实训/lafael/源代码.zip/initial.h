#ifndef INITIAL_H
#define INITIAL_H

#include <QFile>
#include <QIcon>
#include <QWidget>
#include <QLineEdit>
#include <QApplication>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QTextStream>
#include <QMessageBox>
#include <QStackedWidget>

#include "start.h"
#include "widget.h"
#include "button.h"
#include "dialog.h"
class initial:public Widget
{
    Q_OBJECT
public:
    initial(Widget *parent = nullptr);
    ~initial();
    void turnOut();
    //退出
    void goIn();
    //进入登录
    void store();
    //存储的开始
    void help();
    //帮助
    void setPage();
    //设置页面
private:
    start* Start;
    //子页面
    QStackedWidget *stack;
    //调度页面
    QVBoxLayout* menu;
    //布局
};

#endif // INITIAL_H
