#ifndef DRAGLABEL_H
#define DRAGLABEL_H

#include <QWidget>
#include <QLabel>
#include <QMouseEvent>
#include <QDrag>
#include <QMimeData>
#include <QApplication>
#include <QGraphicsDropShadowEffect>
#include <QString>
#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QPainter>

class DragLabel : public QLabel
{
    Q_OBJECT
public:
    explicit DragLabel(QWidget *parent = nullptr);
    void put_text(QString);
protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
private:
    QString text;
    QPoint dragStartPos;
};

#endif // DRAGLABEL_H
