#ifndef STORAGE_H
#define STORAGE_H

#include <QLabel>
#include <QFile>
#include <QLineEdit>
#include <QPushButton>
#include <QPushButton>
#include<QHBoxLayout>

#include "widget.h"
#include "dialog.h"
#include "button.h"
class storage : public Widget
{
    Q_OBJECT
public:
    storage(QWidget *parent=nullptr);
    ~storage();
    void readTotal();
    //读取地图个数
    void readMap(int);
    //读取地图文件
    void reSet();
    //重置
    int* reMap();
    //返回地图
    int* reSolution();
    //返回解决方案
public slots:
    void clickBack();
    //返回
    void startIn();
    //进入作答
    void toHelp();
    //帮助页面
signals:
    void over(int);
    void repage();
private:
    int total;
    int workMap[36];
    int solution[7];
    QLineEdit *choice;
    button *start;
    button *re;
    QLabel *tips;
    button* help;
};

#endif // STORAGE_H
