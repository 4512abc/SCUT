#include "initial.h"
#include <QWidget>
#include <QApplication>
#include <QDebug>
#include<QFile>
#include <QTextStream>
#include <QVBoxLayout>
#include <QStackedWidget>
int main(int argc, char *argv[])
{

    srand(time(0));
    QApplication app(argc, argv);
    QString globalStylesheet = R"(
    QWidget {
        background-color: transparent;
    }
    QPushButton {
        padding: 10px;
        background-color: rgba(224, 230, 188, 50); /* 背景部分透明 */
        border: 1px solid black; /* 边框 */
        font-size: 40px; /* 增大字体 */
        color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 1,
            stop: 0 #318d3c, stop: 0.3 #7cbd70, stop: 1 #cbca62
        );
    }
    QLineEdit {
        padding: 10px;
        border: 2px solid #318d3c;
        border-radius: 5px;
        background-color: rgba(255, 255, 255, 200);
        font-size: 16px;
        color: #2e4e24;
    }
    QLineEdit:focus {
        border: 2px solid #7cbd70;
        background-color: rgba(255, 255, 255, 255);
    }
    QTableWidget {
        font-size: 20px;
        border: 1px solid #ccc;
        gridline-color: #ddd;
        background-color: rgba(130, 146, 179, 20);
        alternate-background-color: rgba(130, 146, 179, 20);
    }
    QTableWidget::item {
        font-size: 20px;
        padding: 10px;
        border: none;
        background-color: rgba(130, 146, 179, 90);
        color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 1,
            stop: 0 #318d3c, stop: 0.3 #7cbd70, stop: 1 #cbca62
        );
    }
    QHeaderView::section {
        background-color: rgba(130, 146, 179, 20);
        color: white;
        padding: 5px;
        border: none;
        font-weight: bold;
    }
    QHeaderView::section:horizontal {
        border-top: 1px solid #ddd;
        border-bottom: 1px solid #ddd;
    }
    QHeaderView::section:vertical {
        border-left: 1px solid #ddd;
        border-right: 1px solid #ddd;
    }
    )";
    app.setStyleSheet(globalStylesheet);
    app.setWindowIcon(QIcon(":/image/1wp.png"));
    initial Start;
    QDialogButtonBox::connect(&app, &QApplication::aboutToQuit, &Start,&initial::store);
    Start.show();
    return app.exec();

}
