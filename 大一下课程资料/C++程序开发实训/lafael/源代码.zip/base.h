#ifndef BASE_H
#define BASE_H

#include <QFile>
#include<QHBoxLayout>
#include <QPushButton>

#include "widget.h"
#include "button.h"
#include "dialog.h"

class base : public Widget
{
    Q_OBJECT
public:
    base(QWidget *parent=nullptr);
    ~base();
    void readMap(int);
    //读取全部
    int* reBaseMap();
    //返回地图
    int* reBaseSolution();
    //返回答案

signals:
    void repage();
    void tomap(int);
public slots:
    void clickback();
    //返回信号
    void clicklevel(int);
    //进入的关卡
    void toHelp();
    //帮助页面
private:
    button* back;
    std::vector<button*> bases;
    button* help;
    //8个按钮
    int baseMap[36];
    int baseSolution[7];
    //基础信息
};

#endif // BASE_H
