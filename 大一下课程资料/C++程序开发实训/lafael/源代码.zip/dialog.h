#ifndef DIALOG_H
#define DIALOG_H

#include <QLabel>
#include <QPixmap>
#include <QWidget>
#include <QSlider>
#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QTableWidget>
#include <QListWidget>
#include <QTableWidgetItem>
#include <QLineEdit>

#include "ranking.h"
#include "draglabel.h"
#include "button.h"

class dialog : public QDialog
{
    Q_OBJECT
public:
    explicit dialog(QWidget *parent = nullptr);
    //初始构造
    void setLevel(const ranking,QStringList);
    //排行榜
    void setMessage(QString);
    //显示消息
    void returnout();
    //返回
    void gameMode();
    //游戏模式
    void getMap();
    //获得玩家地图
    void check();
    //检查地图
    void readUser(std::vector<std::vector<QString>>&,std::vector<QString>&);
    //读取游客模式的账号和密码
    void checkLog();
    //检查末尾密码
    void help();
    //帮助
    void slider(double&);
    //滑动取值
signals:
    void outData(int*);
private:
    QLineEdit* workMap;
    QLineEdit* account;
    QLineEdit* password;
};

#endif // DIALOG_H
