#ifndef BUTTON_H
#define BUTTON_H

#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QPainter>
#include <QGraphicsBlurEffect>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QGraphicsView>

class button : public QPushButton
{
    Q_OBJECT

public:
    button(const QString &text,QString pic, QWidget *parent = nullptr);
    void putText(QString);
protected:
    void enterEvent(QEnterEvent *event) override;
    void leaveEvent(QEvent *event) override;
private:
    QString start;
};
#endif // BUTTON_H
