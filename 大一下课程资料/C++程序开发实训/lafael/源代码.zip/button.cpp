#include "button.h"

button::button(const QString &text,QString pic, QWidget *parent)
 : QPushButton(text, parent)
    ,start(text)
{
    QIcon icon(pic);
    setIcon(icon);
    setStyleSheet(R"(
    QPushButton {
        padding: 10px;
        background-color: rgba(224, 230, 188, 50);
        border: 1px solid black; /* 边框 */
        font-size: 40px; /* 增大字体 */
        color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 1,
            stop: 0 #318d3c, stop: 0.3 #7cbd70, stop: 1 #cbca62
        ); /* 文字渐变 */
    }
    QPushButton::icon {
        padding-right: 20px; /* 调整图标和文字的间距 */
    }
    )");
    setText(text);
}

void button::enterEvent(QEnterEvent *event)
{
    setText("");
    setStyleSheet(R"(
    QPushButton {
        border: 5px solid #318d3c;
    }
    )");
    QPushButton::enterEvent(event);
}

void button::leaveEvent(QEvent *event)
{
    setText(start);
    setStyleSheet(R"(
    QPushButton {
        border: 1px solid black; /* 边框 */
    }
    )");
    QPushButton::leaveEvent(event);
}

void button::putText(QString a)
{
    start=a;
}
