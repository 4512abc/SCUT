#ifndef MAP_H
#define MAP_H
#include<QFile>
#include<QLabel>
#include <QTimer>
#include <QWidget>
#include <vector>
#include <QDateTime>
#include <QMessageBox>
#include<QHBoxLayout>
#include<QVBoxLayout>
#include <QTextStream>
#include <QGridLayout>

#include "widget.h"
#include "draglabel.h"
#include "droplabel.h"
#include "ranking.h"
#include "button.h"
#include "dialog.h"

class map:public Widget
{
    Q_OBJECT
public:
    map(QWidget *parent = nullptr);
    ~map();
    void readmap(int*,int*);
    //读取地图
    void putmap();
    //设置地图
    void pause_on();
    //暂停或继续
    void update();
    //更新时间
    void check();
    //检查是否做对
    void nullMap();
    //创建空地图
    void humanMap();
    //输入地图
    void forState(int,int);
    //记录回溯信息
    void cleanBack();
    //清空回溯数组
    void toBack();
    //回溯
    void helpMe();
    //帮帮我
    void setIn(int);
    //传入排行榜
    void writeOut();
    //写入排行榜
    void compare();
    //对比排行榜
    void callLevel();
    //唤出排行榜
    void popLevel();
    //隐藏排行榜
    void setModule(int);
    //切换模式
    void calculate();
    //计算积分
    void callTools();
    //呼唤工具
    void reZero(int);
    //相应归零
signals:
    void back();
private:
    int nowIndex;
    //反应当前关卡数
    int now_back;
    int now_help;
    //记录板数字
    QGridLayout *gridLayout;
    QGridLayout *menu;
    //布局
    int workmap[36];
    int solution[7];
    //基础信息
    std::vector<QLabel*> piclabel;
    //地图底色
    std::vector<DragLabel*> uselabel;
    //推拽元件
    std::vector<DropLabel*> droplabels;
    //接收拖拽
    bool state;
    //暂停还是其他
    button* start;
    button* pullBack;
    button* help;
    button* inLevel;
    button* tools;
    //五个按钮
    QLabel* time;
    //时间板
    QTimer *timer;
    //计时
    QDateTime nowtime;
    QDateTime lasttime;
    //计算时间
    QLabel *helpCounter;
    QLabel *backCounter;
    //信息板
    std::vector<std::vector<QString>> dropBack;
    //地图数组回溯
    std::vector<int> dragBack;
    //推拽数组回溯
    std::vector<int> helpInt;
    //记录总体情况
    ranking *level;
    //排行榜
    QStringList horHeaders;
    //排行榜元素
    int module;
    //反映模式，0为关卡，1为挑战，2为自定义，3为回顾
    int fault;
    //捷径数
    QString now_time;
    //打印时间
    dialog* gametool;
    //对话框
    QListWidget *list;
    //列表
};
#endif // MAP_H
