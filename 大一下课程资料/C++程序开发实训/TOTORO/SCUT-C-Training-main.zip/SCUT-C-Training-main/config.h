#ifndef CONFIG_H
#define CONFIG_H
#include<QString>

#endif
