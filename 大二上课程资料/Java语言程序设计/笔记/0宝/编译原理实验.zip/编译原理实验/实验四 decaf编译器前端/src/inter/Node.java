package inter;

import lexer.Lexer;

public class Node extends Label {
	int lexline = 0;
	Node() {lexline=Lexer.line;}
	
	void error(String s) { throw new Error("near line "+lexline+": "+s); }
	
	static int labels = 0;

	public int newlabel() {//新建标签位置

		return ++labels;}
	
	public void emitlabel(int i) { System.out.print("L"+i); }//输出标签
	
	public void emit(String s) {//输出语句
		System.out.println("\t"+s); }
}
