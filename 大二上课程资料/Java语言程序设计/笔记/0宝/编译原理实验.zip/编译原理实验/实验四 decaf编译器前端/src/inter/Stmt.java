package inter;
import parser.Parser;

public class Stmt extends Node{

   public Stmt() { }
  public int tmp;
   public static Stmt Null = new Stmt();

   @Override
   public int newlabel() {
       if(!Label.keys.isEmpty()) {
           tmp = Label.keys.peek();
           if (labels  >= tmp) {
               System.out.println("stmt\t" + Label.endlabels.get(Label.keys.pop()) + " end");
           }
       }
      return labels++;
   }

     public void gen(int b, int a) {

   } // called with labels begin and after

   int after = 0;                   // saves label after
   public static Stmt Enclosing = Stmt.Null;  // used for break stmts
}
