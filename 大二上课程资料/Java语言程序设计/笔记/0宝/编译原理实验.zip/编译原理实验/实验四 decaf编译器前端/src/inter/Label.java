package inter;

import symbols.Array;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

public class Label {
   public static HashMap<Integer,String> endlabels;
   public static Stack<Integer> keys=new Stack<>();
    public Label() {
        endlabels = new HashMap<>();
    }
}
