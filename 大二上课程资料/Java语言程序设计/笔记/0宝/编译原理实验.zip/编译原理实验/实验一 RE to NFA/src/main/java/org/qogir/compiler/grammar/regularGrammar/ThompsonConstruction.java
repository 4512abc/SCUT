package org.qogir.compiler.grammar.regularGrammar;

import org.qogir.compiler.FA.State;
import org.qogir.compiler.util.tree.DefaultTree;
import org.qogir.compiler.util.tree.DefaultTreeNode;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class ThompsonConstruction {

    public TNFA translate(RegexTreeNode node){

        if (node == null)
            return null;

        TNFA tnfa = new TNFA();

        //第一种情况：字符
        if(node.getType()==0)
        {
            //判断是否非法输入
            if(node.getFirstChild()!=null)
            {
                System.out.println("正则表达式非法");
                System.exit(1);
            }
            //加边
            tnfa.getTransitTable().addEdge(tnfa.getStartState(),tnfa.getAcceptingState(),node.getValue());
        }
        //第二种情况：-
        else if(node.getType()==1)
        {
            //判断是否非法输入
            int count=0;
            DefaultTreeNode temp_node=node.getFirstChild();
            while(temp_node!=null)
            {
                count++;
                temp_node=temp_node.getNextSibling();
            }
            if(count<2)
            {
                System.out.println("正则表达式非法");
                System.exit(1);
            }
            //构造NFA
            DefaultTreeNode left_node=node.getFirstChild();
            DefaultTreeNode right_node=node.getFirstChild().getNextSibling();
            TNFA left_NFA = translate((RegexTreeNode) left_node);
            TNFA right_NFA = translate((RegexTreeNode) right_node);
            while(right_node!=null)
            {
                //加边连接，左边的接受状态连接到右边的开始状态
                tnfa.getTransitTable().addEdge(left_NFA.getAcceptingState(), right_NFA.getStartState(), 'ε');
                //添加左右节点的转换表
                tnfa.getTransitTable().merge(left_NFA.getTransitTable());
                tnfa.getTransitTable().merge(right_NFA.getTransitTable());
                //更改状态
                left_NFA.getStartState().setType(State.START);
                left_NFA.getAcceptingState().setType(State.MIDDLE);
                right_NFA.getStartState().setType(State.MIDDLE);
                right_NFA.getAcceptingState().setType(State.ACCEPT);
                tnfa.setStartState(left_NFA.getStartState());
                tnfa.setAcceptingState(right_NFA.getAcceptingState());


                right_node = right_node.getNextSibling();
                left_NFA=right_NFA;
                right_NFA = translate((RegexTreeNode) right_node);
            }
        }
        //第三种情况：|
        else if(node.getType()==2)
        {
            //判断是否正确输入
            int count=0;
            DefaultTreeNode temp_node=node.getFirstChild();
            while(temp_node!=null)
            {
                count++;
                temp_node=temp_node.getNextSibling();
            }
            if(count<2)
            {
                System.out.println("字符串非法");
                System.exit(1);
            }
            //构造新的NFA
            DefaultTreeNode left_node=node.getFirstChild();
            DefaultTreeNode right_node=node.getFirstChild().getNextSibling();
            TNFA left_NFA=translate((RegexTreeNode) left_node);
            TNFA right_NFA=translate((RegexTreeNode) right_node);
            while(right_node!=null)
            {
                //连接NFA
                tnfa.getTransitTable().addEdge(tnfa.getStartState(), left_NFA.getStartState(), 'ε');
                tnfa.getTransitTable().addEdge(tnfa.getStartState(), right_NFA.getStartState(), 'ε');
                tnfa.getTransitTable().addEdge(left_NFA.getAcceptingState(), tnfa.getAcceptingState(), 'ε');
                tnfa.getTransitTable().addEdge(right_NFA.getAcceptingState(), tnfa.getAcceptingState(), 'ε');
                //改变状态
                left_NFA.getStartState().setType(State.MIDDLE);
                left_NFA.getAcceptingState().setType(State.MIDDLE);
                right_NFA.getStartState().setType(State.MIDDLE);
                right_NFA.getAcceptingState().setType(State.MIDDLE);
                //更新转换表
                tnfa.getTransitTable().merge(left_NFA.getTransitTable());
                tnfa.getTransitTable().merge(right_NFA.getTransitTable());

                left_NFA=right_NFA;
                right_node=right_node.getNextSibling();
                right_NFA=translate((RegexTreeNode) right_node);
            }
        }
        //第四种情况：*
        else if(node.getType()==3)
        {
            //判断正则表达式是否正确
            int count=0;
            DefaultTreeNode temp_node=node.getFirstChild();
            while(temp_node!=null)
            {
                count++;
                temp_node=temp_node.getNextSibling();
            }
            if(count!=1)
            {
                System.out.println("正则表达式非法");
                System.exit(1);
            }

            //创建NFA
            TNFA closure_NFA=translate((RegexTreeNode) node.getFirstChild());
            closure_NFA.getTransitTable().addEdge(closure_NFA.getAcceptingState(),closure_NFA.getStartState(),'ε');
            //连接
            tnfa.getTransitTable().addEdge(tnfa.getStartState(),closure_NFA.getStartState(),'ε');
            tnfa.getTransitTable().addEdge(closure_NFA.getAcceptingState(),tnfa.getAcceptingState(),'ε');
            tnfa.getTransitTable().addEdge(tnfa.getStartState(),tnfa.getAcceptingState(),'ε');
            //合并
            tnfa.getTransitTable().merge(closure_NFA.getTransitTable());
            //修改状态
            closure_NFA.getStartState().setType(State.MIDDLE);
            closure_NFA.getAcceptingState().setType(State.MIDDLE);
        }
        return tnfa;
    }
}
