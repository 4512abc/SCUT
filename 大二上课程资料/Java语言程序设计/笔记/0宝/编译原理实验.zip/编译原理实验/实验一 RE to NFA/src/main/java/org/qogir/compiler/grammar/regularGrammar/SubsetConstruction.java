package org.qogir.compiler.grammar.regularGrammar;

import org.qogir.compiler.FA.State;
import org.qogir.compiler.util.graph.LabelEdge;
import org.qogir.compiler.util.graph.LabeledDirectedGraph;

import java.util.*;

public class SubsetConstruction {

    //ε-closure(s) 从NFA的状态s开始只通过ε转换到达的NFA状态集合
    private HashMap<Integer, State> epsilonClosures(State s, LabeledDirectedGraph<State> tb)
    {
        if (!tb.vertexSet().contains(s))
            return null;

        //新建NFA状态集合
        HashMap<Integer,State> nfaStates = new HashMap<>();

        //新建一个栈来记录已变迁到达的状态
        Stack<State> stateStack=new Stack<>();
        //压入当前状态
        stateStack.push(s);

        //向nfaStates中加入新的状态
        while(!stateStack.isEmpty())
        {
            State current_state= stateStack.pop();
            nfaStates.put(current_state.getId(),current_state);
            //遍历变迁表
            for(LabelEdge edge:tb.edgeSet())
            {
                //当满足这三个条件时：①变迁表中的边的source状态与当前分析状态一致 ②当前边的转换符是'ε' ③nfaStates中还没有此边的Target状态
                //就将此条边的Target状态加入stackStack中，下次while循环对此Target状态继续向前求ε变迁集合
                if(tb.getEdgeSource(edge).equals(current_state)&&edge.getLabel()=='ε'&&!nfaStates.containsKey(tb.getEdgeTarget(edge).getId()))
                    stateStack.push(tb.getEdgeTarget(edge));
            }
        }
        return nfaStates;
    }

    //ε-closure(ss) 从T中的某个NFA状态s开始只通过ε转换到达的NFA状态集合
    public HashMap<Integer, State> epsilonClosure(HashMap<Integer, State> ss, LabeledDirectedGraph<State> tb)
    {
        HashMap<Integer,State> nfaStates = new HashMap<>();
        for(State s : ss.values()){
            nfaStates.putAll(epsilonClosures(s,tb));
        }
        return nfaStates;
    }

    //move(s,ch) 从状态s开始通过标号ch的转换到达NFA的状态集合
    private HashMap<Integer,State> moves(State s, Character ch, LabeledDirectedGraph<State> tb)
    {
        //新建一个nfaStates存放状态s通过ch转换能到达的状态集
        HashMap<Integer,State> nfaStates = new HashMap<>();

        //遍历转换表 寻找对应的边的Target状态
        for(LabelEdge edge: tb.edgeSet())
        {
            if(tb.getEdgeSource(edge).equals(s)&&edge.getLabel()==ch)
                nfaStates.put(tb.getEdgeTarget(edge).getId(),tb.getEdgeTarget(edge));
        }
        return nfaStates;
    }

    //move(ss,ch) 从ss中的某个状态s开始通过标号ch的转换到达NFA的状态集合
    public HashMap<Integer,State> move(HashMap<Integer, State> ss, Character ch, LabeledDirectedGraph<State> tb)
    {
        HashMap<Integer,State> nfaStates = new HashMap<>();
        for(State s : ss.values()){
            nfaStates.putAll(moves(s,ch,tb));
        }
        return nfaStates;
    }

    //既move(ss,ch)，还对其结果做ε变迁
    public HashMap<Integer,State> epsilonClosureWithMove(HashMap<Integer, State> sSet, Character ch, LabeledDirectedGraph<State> tb)
    {
        HashMap<Integer,State> states = new HashMap<>();
        states.putAll(epsilonClosure(move(sSet, ch, tb),tb));
        return states;
    }

    //子集构造法
    public RDFA subSetConstruct(TNFA tnfa){
        RDFA dfa = new RDFA();
        LabeledDirectedGraph<State> tb=tnfa.getTransitTable();
        HashMap<State, HashMap<Integer,State>> dfa_map = dfa.getStateMappingBetweenDFAAndNFA();
        ArrayList<Character> alphabet = tnfa.getAlphabet();

        //nfa的初始态对应的ε变迁集合
        HashMap<Integer,State> start_states_epsilon_closure = epsilonClosures(tnfa.getStartState(),tb);

        //如果映射左部包含了结束状态，映射的结果状态也是结束状态
        if(start_states_epsilon_closure.containsKey(tnfa.getAcceptingState().getId()))
            dfa.getStartState().setType(2);

        //将此闭包放入dfa的状态映射表
        dfa.setStateMappingBetweenDFAAndNFA(dfa.getStartState(),start_states_epsilon_closure);

        //创建一个队列用于存储未处理的dfa状态
        Queue<State> need_process_states = new LinkedList<>();
        need_process_states.add(dfa.getStartState());

        while(!need_process_states.isEmpty()){
            //取出队列中未处理的一个状态
            State current_state = need_process_states.poll();

            //根据状态映射表 得到nfa状态集
            HashMap<Integer, State> current_nfa_set = dfa_map.get(current_state);

            //该状态集接受字母表的各个输入后
            for (Character ch:alphabet) {
                //接受输入ch，move加ε转化后得到的状态集
                HashMap<Integer,State> result_states_epsilon_closure = epsilonClosureWithMove(current_nfa_set,ch,tb);

                //若状态集为空则直接进入下一轮循环
                if(result_states_epsilon_closure.isEmpty())
                    continue;

                //新建新的dfa状态
                State newState=new State();

                //判断状态集result_states_epsilon_closure是否在状态映射表中
                boolean is_in=false;
                for ( Map.Entry<State, HashMap<Integer, State>> entry : dfa_map.entrySet())
                {
                    //找到状态集result_states_epsilon_closure，退出循环
                    if(entry.getValue().equals(result_states_epsilon_closure)){
                        newState=entry.getKey();
                        is_in=true;
                        break;
                    }
                }


                //状态集result_states_epsilon_closure不在状态映射表中
                if(is_in==false)
                {
                    //将状态加入状态集和变迁表中
                    boolean isAcc = result_states_epsilon_closure.containsKey(tnfa.getAcceptingState().getId());
                    newState.setType(isAcc?2:1);
                    dfa.getTransitTable().addVertex(newState);
                    dfa.getTransitTable().addEdge(current_state,newState,ch);


                    dfa_map.put(newState,result_states_epsilon_closure);
                    need_process_states.add(newState);
                }
                //状态集result_states_epsilon_closure在状态映射表中
                else
                    dfa.getTransitTable().addEdge(current_state,newState,ch);
            }
        }

        return dfa;
    }
}
