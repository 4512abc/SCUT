package org.qogir.compiler.grammar.regularGrammar;


import org.qogir.compiler.FA.State;
import org.qogir.compiler.util.graph.LabelEdge;
import org.qogir.compiler.util.graph.LabeledDirectedGraph;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class StateMinimization {
    private HashMap<Integer,HashMap<Integer, State>> distinguishEquivalentState(RDFA dfa){
        HashMap<Integer,HashMap<Integer, State>> groupSet = new HashMap<>(); // group set
        //先分成非接受态和接受态两组
        HashMap<Integer,State> non_accept_group = new HashMap<>();
        HashMap<Integer,State> accept_group= new HashMap<>();

        for (State s:dfa.getTransitTable().vertexSet())
        {
            if(s.getType()==2)
                accept_group.put(s.getId(),s);
            else
                non_accept_group.put(s.getId(),s);
        }

        //将这两组放入groupSet中
        if(!non_accept_group.isEmpty())
            groupSet.put(groupSet.size(), non_accept_group);
        if(!accept_group.isEmpty())
            groupSet.put(groupSet.size(), accept_group);

        ArrayList<Character> alphabet = dfa.getAlphabet();
        LabeledDirectedGraph<State> tb = dfa.getTransitTable();

        boolean change = true; //groupSet是否发生改变
        while(change){
            //groupSet经过划分后的newGroupSet
            HashMap<Integer,HashMap<Integer, State>> newGroupSet = new HashMap<>();
            change = false;
            //<-------------遍历groupSet成员
            for (Map.Entry<Integer,HashMap<Integer, State>> item: groupSet.entrySet())
            {
                HashMap<Integer,State> group = item.getValue();
                //若该小组group只有一个状态则不可再分，直接遍历下一个groupSet成员
                if(group.size()==1) {
                    newGroupSet.put(newGroupSet.size(), group);
                    continue;
                }
                //小组group划分成的新子组集合newSubgroupSet
                HashMap<Integer, HashMap<Integer,State>> newSubgroupSet = new HashMap<>();
                //遍历字母表，若字母a可以将group划分开，则将分出来的子组集合groupSpiltOnA_Set赋值给newSubgroupSet并跳出遍历，
                for (Character a:alphabet) {
                    //小组group在字母a上的分割成果groupSpiltOnA_Set
                    HashMap<Integer, HashMap<Integer,State>> groupSpiltOnA_Set = new HashMap<>();
                    //遍历小组group的每一个状态
                    for (Map.Entry<Integer,State> stateEntry:group.entrySet()){
                        //遍历dfa的边集，找出源点为该状态且标签为字母a的边，若找得到则flag为false
                        //找出该边后，在遍历目前的小组集合groupSet，找出目标状态所在的小组（组号key），并放入分组集合groupSpiltOnA_Set：（ key，{该状态，状态1，状态2，。。。。}} ）
                        boolean flag=true;
                        for (LabelEdge e:tb.edgeSet()) {
                            if(((State)e.getSource()).getId()==stateEntry.getKey()&&e.getLabel()==a){
                                int tid = ((State)e.getTarget()).getId();
                                //查找出目标状态在groupSet的哪个小组中
                                for (Map.Entry<Integer,HashMap<Integer,State>> sg:groupSet.entrySet()
                                ) {
                                    if(sg.getValue().containsKey(tid)){
                                        groupSpiltOnA_Set.computeIfAbsent(sg.getKey(),x->new HashMap<>()).put(stateEntry.getKey(),stateEntry.getValue());
                                        break;
                                    }
                                }
                                flag=false;
                                break;
                            }
                        }
                        //该状态stateEntry没有含字母a跳转出的边
                        if(flag){
                            groupSpiltOnA_Set.computeIfAbsent(-1,x->new HashMap<>()).put(stateEntry.getKey(),stateEntry.getValue());
                        }
                    }
                    //遍历完小组group的每一个状态，得到group经过字母a划分后的分组集合groupSpiltOnA_Set--------------->

                    //若该小组被分割成多于一个的子小组则需要再次遍历groupSet
                    if(groupSpiltOnA_Set.size()>1) {
                        newSubgroupSet=groupSpiltOnA_Set;
                        change = true;
                        break;//只要出现字母将小组进行分割则退出字母表遍历
                    }else{
                        newSubgroupSet = groupSpiltOnA_Set;
                    }
                }

                //小组group进行分割后的结果newSubgroupSet放入newGroupSet
                for (Map.Entry<Integer,HashMap<Integer,State>> subgroup:newSubgroupSet.entrySet()
                ) {
                    newGroupSet.put(newGroupSet.size(), subgroup.getValue());
                }
            }
            //groupSet遍历完成
            groupSet = newGroupSet;
        }
        return groupSet;
    }

    public RDFA minimize(RDFA dfa){
        if(dfa==null)return null;
        //Add your implementation
        //等价类组
        HashMap<Integer,HashMap<Integer, State>> groupSet = distinguishEquivalentState(dfa);
        //最小DFA
        RDFA minimize_dfa = new RDFA();
        //组号->代表状态
        HashMap<Integer,State> group_id_to_state = new HashMap<>();
        //代表状态->minimize_dfa状态（新状态）
        HashMap<State,State> dfa_state_to_dfa_minimize_state = new HashMap<>();
        //遍历等价类组，建立 group_id_to_state 和 dfa_state_to_dfa_minimize_state
        //判断是否对等价类组的成员---等价状态集合进行遍历，找出初始状态后就不进行遍历
        boolean loop = true;
        for (Map.Entry<Integer, HashMap<Integer, State>> group:groupSet.entrySet()) {
            //是否为minimize_dfa创建新状态
            boolean create = true;

            if(loop){
                for (State s: group.getValue().values()) {
                    if(s.getType()==0){
                        loop=false;
                        create = false;
                        dfa_state_to_dfa_minimize_state.put(group.getValue().values().iterator().next(),minimize_dfa.getStartState());
                    }
                }
            }

            group_id_to_state.put(group.getKey(),group.getValue().values().iterator().next());
            if(create){
                State new_state= new State();
                new_state.setType(group_id_to_state.get(group.getKey()).getType());
                minimize_dfa.getTransitTable().addVertex(new_state);
                dfa_state_to_dfa_minimize_state.put(group_id_to_state.get(group.getKey()),new_state);
            }

        }

        //遍历group_id_to_state
        for (Map.Entry<Integer, State> entry:group_id_to_state.entrySet())
        {
            //遍历原dfa的状态变迁表，找出源状态为当前遍历元素的边
            for (LabelEdge e:dfa.getTransitTable().edgeSet()) {
                if(((State)e.getSource()).getId()==entry.getValue().getId()){
                    State target  = (State) e.getTarget();
                    //遍历等价类组，找出目标状态所在的等价类
                    for (Map.Entry<Integer, HashMap<Integer, State>> g:groupSet.entrySet()) {
                        if(g.getValue().containsKey(target.getId())){
                            State s = dfa_state_to_dfa_minimize_state.get(entry.getValue());
                            State t = dfa_state_to_dfa_minimize_state.get(group_id_to_state.get(g.getKey()));
                            LabelEdge edge = new LabelEdge(s,t,e.getLabel());
                            minimize_dfa.getTransitTable().addEdge(edge);
                        }
                    }
                }
            }
        }
        return minimize_dfa;
    }


















//    /**
//     * Used for showing the distinguishing process of state miminization algorithm
//     * @param stepQueue holds all distinguishing steps
//     * @param GroupSet is the set of equivalent state groups
//     * @param memo  remarks
//     */
//    private void recordDistinguishSteps(ArrayDeque<String> stepQueue, HashMap<Integer,HashMap<Integer, State>> GroupSet, String memo){
//        String str = "";
//        str = GroupSetToString(GroupSet);
//        str += ":" + memo;
//        stepQueue.add(str);
//    }
//
//    /**
//     * Display the equivalent state groups
//     * @param stepQueue
//     */
//    private void showDistinguishSteps(ArrayDeque<String> stepQueue){
//        int step = 0;
//        String str = "";
//        while(!stepQueue.isEmpty()){
//            str = stepQueue.poll();
//            System.out.println("Step" + step++ + ":\t" + str +"\r");
//        }
//    }

    private String GroupSetToString(HashMap<Integer,HashMap<Integer, State>> GroupSet){
        String str = "";
        for( Integer g: GroupSet.keySet()){
            String tmp = GroupToString(GroupSet.get(g));
            str += g +  ":" + tmp + "\t" ;
        }
        return str;
    }

    private String GroupToString(HashMap<Integer, State> group){
        String str = "";
        for(Integer k : group.keySet()){
            str += group.get(k).getId() + ":" + group.get(k).getType() + ",";
        }
        if(str.length()!=0) str = str.substring(0,str.length()-1);
        str = "{" + str + "}";
        return str;
    }
}
