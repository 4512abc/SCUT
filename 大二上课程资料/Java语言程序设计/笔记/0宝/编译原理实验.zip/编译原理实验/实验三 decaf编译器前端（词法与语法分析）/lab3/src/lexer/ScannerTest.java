package lexer;

import java.io.*;

public class ScannerTest {
        public static void main(String[] args) throws IOException {
            // TODO Auto-generated method stub
            // 获取文件
            File file = new File("./test.txt");
            Reader reader = null;
            reader = new InputStreamReader(new FileInputStream(file));
            // 新建一个词法解析器，将文件传给lexer，由它读取文件内容
            Lexer lex = new Lexer(reader);
            boolean isReadEnd =false;
            char c;
            do {
                Token token=lex.scan();
                switch (token.tag) {
                    case 270:
                    case 272:
                        System.out.println("(NUM , "+token.toString()+")");
                        break;
                    case 264:
                        System.out.println("(ID , "+token.toString()+")");
                        break;
                    case 256:
                    case 257:
                    case 258:
                    case 259:
                    case 260:
                    case 265:
                    case 274:
                    case 275:
                    case 276:
                            System.out.println("(KEY , "+token.toString()+")");
                        break;
                    case 13:
                        break;
                    case Tag.EOF://读到文件尾
                        isReadEnd =true;
                        break;
                    default:
                        System.out.println("(SYM , "+token.toString()+")");
                        break;
                }

            } while (!isReadEnd);//lex.getPeek()!='\n'
        }
}


