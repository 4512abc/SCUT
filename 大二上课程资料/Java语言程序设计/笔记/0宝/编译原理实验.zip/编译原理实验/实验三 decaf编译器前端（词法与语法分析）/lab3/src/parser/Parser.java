package parser;

import inter.*;

import java.io.IOException;

import symbols.Array;
import symbols.Env;
import symbols.Type;
import lexer.Lexer;
import lexer.Tag;
import lexer.Token;
import lexer.Word;
import lexer.Num;

public class
Parser {

	   private Lexer lex;    // lexical analyzer for this parser
	   private Token look;   // lookahead taken
	   Env top = null;       // current or top symbol table
	   int used = 0;         // storage used for declarations

	   public Parser(Lexer l) throws IOException { lex = l; move(); }

	   void move() throws IOException { look = lex.scan(); }

	   void error(String s) { throw new Error("near line "+lex.line+": "+s); }

	   void match(int t) throws IOException {
	      if( look.tag == t ) move();
	      else error("syntax error");
	   }

	   public void program() throws IOException {  // program -> block
		   //决定的源代码必须以 { 开头
	      Stmt s = block();//parser 结束

	      int begin = s.newlabel();
//	      int after = s.newlabel();
//	      s.emitlabel(begin);
//	      s.gen(begin, after);
//	      s.emitlabel(after);
	   }

	   //{}的内容   决定了{}内声明语句只能在其他语句之前
	   Stmt block() throws IOException {  // block -> { decls stmts }
	      match('{');
		  Env savedEnv = top;//这个不是new 是对top的引用
		  top = new Env(top);//会在下面decls()被使用
	      decls();//声明
  		  Stmt s = stmts();
	      match('}');  top = savedEnv;
	      return s;
	   }

	   void decls() throws IOException {

		   //基本类型 int  int[10] 之类的 声明
	      while( look.tag == Tag.BASIC ) {   // D -> type ID ;
	         Type p = type();//获取基本数据类型 eg: int 、 int[10]
			 Token tok = look;//int 后面的表示符号 如int p look=p
			 match(Tag.ID);//当前look为标识符
			 match(';');//int i;
	         Id id = new Id((Word)tok, p, used);
	         top.put( tok, id );
	         used = used + p.width;//p.width 数据占的空间长度
	      }
	   }

	   Type type() throws IOException {

	      Type p = (Type)look;            // expect look.tag == Tag.BASIC 
	      match(Tag.BASIC);//基本数据类型
	      if( look.tag != '[' ) return p; // T -> basic
	      else return dims(p);            // return array type
	   }

	   Type dims(Type p) throws IOException {
	      match('[');  Token tok = look;  match(Tag.NUM);  match(']');
	      if( look.tag == '[' )
	      p = dims(p);
	      return new Array(((Num)tok).value, p);
	   }

	   Stmt stmts() throws IOException {
		   //和前面{ 是否配对
	      if ( look.tag == '}' ) return Stmt.Null;
	      else return new Seq(stmt(), stmts());
		  //else return new Seq(stmt());
	   }

	   Stmt stmt() throws IOException {
	      Expr x;  Stmt s, s1, s2;
	      Stmt savedStmt;         // save enclosing loop for breaks

	      switch( look.tag ) {

	      case ';':
	         move();
	         return Stmt.Null;

	      case Tag.IF:
	         match(Tag.IF);
			 match('('); x = bool(); match(')');
			 System.out.println("stmt: if begin");
	         s1 = stmt();
			  System.out.println("stmt: if end");
	         if( look.tag != Tag.ELSE ) return new If(x, s1);
	         match(Tag.ELSE);
	         s2 = stmt();
	         return new Else(x, s1, s2);

	      case Tag.WHILE:
	         While whilenode = new While();
	         savedStmt = Stmt.Enclosing; Stmt.Enclosing = whilenode;
	         match(Tag.WHILE); match('('); x = bool(); match(')');
			 System.out.println("stmt: while begin");
	         s1 = stmt();
			 System.out.println("stmt: while end");
	         whilenode.init(x, s1);
	         Stmt.Enclosing = savedStmt;  // reset Stmt.Enclosing
	         return whilenode;

	      case Tag.DO:
	         Do donode = new Do();
	         savedStmt = Stmt.Enclosing; Stmt.Enclosing = donode;
	         match(Tag.DO);
			  System.out.println("stmt: do begin");
	         s1 = stmt();
			  System.out.println("stmt: do end");
	         match(Tag.WHILE); match('('); x = bool(); match(')'); match(';');
	         donode.init(s1, x);
	         Stmt.Enclosing = savedStmt;  // reset Stmt.Enclosing
	         return donode;

	      case Tag.BREAK:
	         match(Tag.BREAK); match(';');
			  System.out.println(" break");
	         return new Break();

	      case '{':
	         return block();

			 //--------------------------------------------------------------------------------
		  case Tag.FOR:
			  For fornode = new For();
			  savedStmt = Stmt.Enclosing; Stmt.Enclosing = fornode;
			  match(Tag.FOR);match('(');

			  s1=forassign();
			  match(';');

			  x=bool();match(';');

			  s2=forassign();
			  match(')');

			  System.out.println("stmt: for begin");
			  s=stmt();
			  System.out.println("stmt: for end");

			  fornode.init(s1,x,s2,s);
			  Stmt.Enclosing = savedStmt;  // reset Stmt.Enclosing
			  return fornode;
			  //--------------------------------------------------------------------------------
	      default:
			  System.out.println(" assignment");
	         return assign();//Tag.ID 赋值
	      }
	   }
	   
	   Stmt forassign() throws IOException {
		      Stmt stmt;  Token t = look;
		      match(Tag.ID);
		      Id id = top.get(t);
		      if( id == null ) error(t.toString() + " undeclared");

		      if( look.tag == '=' ) {       // S -> id = E ;
		         move();  stmt = new Set(id, bool());
		      }
		      else {                        // S -> L = E ;
		         Access x = offset(id);
		         match('=');  stmt = new SetElem(x, bool());
		      }
		      return stmt;
	   }

	   Stmt assign() throws IOException {
	      Stmt stmt;  Token t = look;
	      match(Tag.ID);
	      Id id = top.get(t);
	      if( id == null ) error(t.toString() + " undeclared");

	      if( look.tag == '=' ) {       // S -> id = E ;
	         move();  stmt = new Set(id, bool());
	      }
	      else {                        // S -> L = E ;
			  //数组
	         Access x = offset(id);
	         match('=');  stmt = new SetElem(x, bool());
	      }
	      match(';');
	      return stmt;
	   }

	   Expr bool() throws IOException {
	      Expr x = join();
	      while( look.tag == Tag.OR ) {
	         Token tok = look;  move();  x = new Or(tok, x, join());
	      }
	      return x;
	   }

	   Expr join() throws IOException {
	      Expr x = equality();
	      while( look.tag == Tag.AND ) {
	         Token tok = look;  move();  x = new And(tok, x, equality());
	      }
	      return x;
	   }

	   Expr equality() throws IOException {
	      Expr x = rel();
	      while( look.tag == Tag.EQ || look.tag == Tag.NE ) {
	         Token tok = look;  move();  x = new Rel(tok, x, rel());
	      }
	      return x;
	   }

	   Expr rel() throws IOException {
	      Expr x = expr();
	      switch( look.tag ) {
	      case '<': case Tag.LE: case Tag.GE: case '>':
	         Token tok = look;  move();  return new Rel(tok, x, expr());
	      default:
	         return x;
	      }
	   }

	   Expr expr() throws IOException {
	      Expr x = term();
	      while( look.tag == '+' || look.tag == '-' ) {
	         Token tok = look;  move();  x = new Arith(tok, x, term());
	      }
	      return x;
	   }

	   Expr term() throws IOException {
	      Expr x = unary();
	      while(look.tag == '*' || look.tag == '/' ) {
	         Token tok = look;  move();   x = new Arith(tok, x, unary());
	      }
	      return x;
	   }

	   Expr unary() throws IOException {
	      if( look.tag == '-' ) {
	         move();  return new Unary(Word.minus, unary());
	      }
	      else if( look.tag == '!' ) {
	         Token tok = look;  move();  return new Not(tok, unary());
	      }
	      else return factor();
	   }

	   Expr factor() throws IOException {
	      Expr x = null;
	      switch( look.tag ) {
	      case '(':
	         move(); x = bool(); match(')');
	         return x;
	      case Tag.NUM:
	         x = new Constant(look, Type.Int);    move(); return x;
	      case Tag.REAL:
	         x = new Constant(look, Type.Float);  move(); return x;
	      case Tag.TRUE:
	         x = Constant.True;                   move(); return x;
	      case Tag.FALSE:
	         x = Constant.False;                  move(); return x;
	      default:
	         error("syntax error");
	         return x;
	      case Tag.ID:
	         String s = look.toString();
	         Id id = top.get(look);
	         if( id == null ) error(look.toString() + " undeclared");
	         move();
	         if( look.tag != '[' ) return id;
	         else return offset(id);
	      }
	   }

	   Access offset(Id a) throws IOException {   // I -> [E] | [E] I
	      Expr i; Expr w; Expr t1, t2; Expr loc;  // inherit id

	      Type type = a.type;
	      match('['); i = bool(); match(']');     // first index, I -> [ E ]
	      type = ((Array)type).of;
	      w = new Constant(type.width);
	      t1 = new Arith(new Token('*'), i, w);
	      loc = t1;
	      while( look.tag == '[' ) {      // multi-dimensional I -> [ E ] I
	         match('['); i = bool(); match(']');
	         type = ((Array)type).of;
	         w = new Constant(type.width);
	         t1 = new Arith(new Token('*'), i, w);
	         t2 = new Arith(new Token('+'), loc, t1);
	         loc = t2;
	      }

	      return new Access(a, loc, type);
	   }
	}
