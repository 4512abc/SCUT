package main;

import inter.Stmt;

public class MySyntaxTreeGenerator {
    public void generator(Stmt stmt){


    }
}
