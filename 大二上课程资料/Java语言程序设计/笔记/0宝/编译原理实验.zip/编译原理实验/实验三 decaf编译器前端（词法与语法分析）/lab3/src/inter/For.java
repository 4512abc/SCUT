package inter;

import symbols.Type;

public class For extends Stmt{
    Expr expr; Stmt assign1,assign2,stmt;//对应 for(assign1;expr;assign2) stmt

    public void init(Stmt assign1,Expr expr, Stmt assign2 ,Stmt stmt) {
        this.expr = expr;  this.assign1 = assign1;this.assign2 = assign2;this.stmt = stmt;
        if( expr.type != Type.Bool ) expr.error("boolean required in For");
    }
}
