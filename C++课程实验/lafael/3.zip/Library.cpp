#include <iostream>
#include <string>
#include <fstream>
#include "Library.h"
using namespace std;
BookRecord::BookRecord()
{
    book_total_num=0;
    book_avail=0;

};
BookRecord::BookRecord(string i, string t, string a, string y, int n, int l) : book_id(i), book_title(t),
book_auther(a), book_year(y), book_total_num(n), book_avail(l)
{
    if (book_id[0] < 65 || book_id[0] > 90)
    {
        cout << "书籍ID错误" << endl;
        exit(0);
    }
    if (book_year[0] < 49 || book_id[0] > 50)
    {
        cout << "出版时间错误" << endl;
        exit(0);
    }
    if (book_id.length() != 4)
    {
        cout << "书籍ID错误" << endl;
        exit(0);
    }
};// 检查ID首字母大写，year首字是否为1，2，是否有4位。65-90

BookRecord::~BookRecord(){};

void BookRecord::write(ifstream &ifs) // 写入数据
{
    getline(ifs,book_id,';');
    if (book_id[1] < 65 || book_id[1] > 90)
    {
        cout << "书籍FID错误" << endl;
        exit(0);
    }
    if (book_id.length() != 5)
    {
        cout << "书籍LID错误" << endl;
        exit(0);
    }
    getline(ifs, book_title,';');
    getline(ifs, book_auther,';');
    getline(ifs,book_year,';');
    if (book_year[0] < 49 || book_id[0] > 50)
    {
        cout << "出版日期错错误" << endl;
        exit(0);
    }
    ifs >> book_total_num;
    ifs >> book_avail;
}
string BookRecord::id()
{
    return book_id;
}
string BookRecord::return_ID()
{
    return book_id;
}
void BookRecord::write_booknum()
{
    book_avail--;
    if (book_avail < 0)
    {
        cout << "书库殆尽,无法借阅" << endl;
        book_avail = 0;
    }
}
void BookRecord::write_bookloan()
{
    book_avail--;
}
void BookRecord::check(ofstream& ofs) // 返回各项数据
{
    ofs << "Book ID :" << book_id << endl;
    ofs << "Title :" << book_title << endl;
    ofs << "Author :" << book_auther << endl;
    ofs << "Year published :" << book_year << endl;
    ofs << "Total number of copies :" << book_total_num << endl;
    ofs << "Number available for loan :" << book_avail << endl;
} // 记书类的各项数据，加入目录
void BookRecord::check() // 返回各项数据
{
    cout << "Book ID :" << book_id << endl;
    cout << "Title :" << book_title << endl;
    cout << "Author :" << book_auther << endl;
    cout << "Year published :" << book_year << endl;
    cout << "Total number of copies :" << book_total_num << endl;
    cout << "Number available for loan :" << book_avail << endl;
} // 记书类的各项数据，加入目录
Borrower::Borrower()
{
    loan=0;
    loan_books=nullptr;
};
Borrower::Borrower(string i, string b, int l) : borrower_id(i), borrower(b), loan(l)
{
    if (borrower_id.length() != 5)
    {
        cout << "借阅人ID错误" << endl;
        exit(0);
    }
};
void Borrower::readbook(ifstream& ifs)
{
    for (int i = 0; i < loan; i++)
    {
        getline(ifs,loan_books[i],';');
        if (loan_books[i][1] < 65 || loan_books[i][1] > 90)
        {
            cout << "书籍ID错误" << endl;
            exit(0);
        }
    }
}
void Borrower::write(ifstream& ifs)
{
    getline(ifs, borrower_id,';');
    if (borrower_id.length() != 6)
    {
        cout << "用户ID错误" << endl;
        exit(0);
    }
    getline(ifs, borrower,';');
    ifs >> loan;
    createbook(loan);
    readbook(ifs);
} // 写入数据
void Borrower::createbook(int a)//开动态数组
{
    loan=a;
    this->loan_books=new string[loan];
}
string Borrower::bookid(int i)
{
    if(i>loan-1)
    {
        cout<<i;
        exit(0);
    }
    else
    return loan_books[i];
}
int Borrower::loan_bor()
{
    return loan;
}
void Borrower::return_id()
{
    for (int i = 0; i < loan; i++)
    {
        cout << loan_books[i] << " ";
    }
    cout << endl;
}
void Borrower::check()
{
    cout << "借阅人ID :" << borrower_id << endl;
    cout << "姓名 :" << borrower << endl;
    for (int i = 0; i < loan; i++)
    {
        cout << "第 " << i << " 个 :";
        cout << "借出书的数目 :" << loan_books[i] << endl;
    }
}
Borrower::~Borrower()
{
    if(loan_books!=nullptr)
    {
    delete [] loan_books;
    }
};
Catalogue::Catalogue()
{
    book_total = 0;
    book_borrow=0;
    bookres=nullptr;
    bor=nullptr;
}
void Catalogue::writebook(int& a)
{
    book_total = a;
}
void Catalogue::writeloan(int& a)
{
    book_borrow = a;
}
void Catalogue::create_record(ifstream &ifs)
{
    bookres = new BookRecord[book_total];
    for (int i = 0; i < book_total; i++)
    {
        bookres[i].write(ifs);
    }
}
void Catalogue::create_borrow(ifstream &ifs)
{
    bor = new Borrower[book_borrow];
    for (int i=0; i<book_borrow; i++)
    {
        bor[i].write(ifs);
        find_record(bookres, bor[i]); // 传入bookres，用于和bor中的借书名单比对修改
    }
}
void Catalogue::find_record(BookRecord *a, Borrower &b)
{
    int borrow_num = b.loan_bor();         // 借书数目，用于循环
    for (int i = 0; i < book_total; i++) // 一层循环，借书名单
    {
        for (int j = 0; j < borrow_num; j++) // 二层循环，记书名单
        {
            string q1=a[i].id();
            string q2=b.bookid(j);
            q2.erase(0,1);
            q1.erase(0,1);
            if (q1==q2)
            {
                a[i].write_booknum(); // 修改记书名单中每个书的留存
            }
        }
    }
}
void Catalogue::find_ID(BookRecord a[], string id)
{
    for (int i = 0; i < book_total; i++)
    {
        if (a[i].return_ID() == id)
            a[i].check(); // cheack输出所有信息
    }
}
BookRecord* Catalogue::re_bookres()
{
    return bookres;
}
Borrower* Catalogue::re_borrow()
{
    return bor;
}
Catalogue::~Catalogue()
{
    if(bookres!=nullptr)
    delete []bookres;
    if(bor!=nullptr)
    delete []bor;
}
Library::Library(int a, int b) : books(a), loan(b){}
Library::Library()
{
    loan=0;
    books=0;
};
void Library::write_book(ifstream &ifs,ofstream& ofs)
{
    ifs >> books;
    ofs<<"记载了"<<books<<"本书"<<endl;
};
void Library::write_loan(ifstream &ifs,ofstream& ofs)
{
    ifs >> loan;
    ofs<<"记载了"<<loan<<"个借阅人"<<endl;
};
int& Library::getbooks()
{
    return books;
}
int& Library::getloan()
{
    return loan;
}
void Library::lookbook(int a)
{
    cata.re_bookres()[a].check();
} // 打出记载的图书信息
void Library::lookborrow(int a)
{
    cata.re_borrow()[a].check();
} // 打出借阅人信息
Catalogue& Library::re_cltalogu()
{
    return cata;
}
Library::~Library(){};// 该类目前只包含数据的返回和读写