#include<iostream>
#include<string>
#include <fstream>
using namespace std;
#ifndef LIBRARY_H
#define LIBRARY_H
class BookRecord
{
    public:
    BookRecord();//默认构造函数
    BookRecord(string,string,string,string,int,int);//检查ID首字母大写，year首字是否为1，2，是否有4位。65-90
    void write(ifstream&);//写入数据
    string id();
    string return_ID();
    void write_booknum();
    void write_bookloan();
    void check(ofstream&);
    void check();//返回各项数据
    ~BookRecord();
    private:
    string book_id;
    string book_title;
    string book_auther;
    string book_year;
    int book_total_num;
    int book_avail;
};//记书类的各项数据，加入目录
class Borrower
{
    public:
    Borrower();
    Borrower(string,string,int);
    void readbook(ifstream&);//逐个写入书
    void write(ifstream&);//写入数据
    string bookid(int);
    int loan_bor();//返回借书数
    void return_id();//逐次输出借的书
    void check();//判断合法
    void createbook(int);
    ~Borrower();
    private:
    string borrower_id;
    string borrower;
    int loan;//借书目
    string *loan_books=nullptr;//借书数组
};//借书类的各项数据，加入目录
class Catalogue
{
    public:
    Catalogue();
    void writebook(int& );//写入存书量
    void writeloan(int& );//写入借阅人
     void create_record(ifstream&);
    void create_borrow(ifstream&);
    void find_record(BookRecord [],Borrower& );
    void find_ID(BookRecord [],string);
    BookRecord* re_bookres();
    Borrower* re_borrow();
    ~Catalogue();
    private:
    BookRecord *bookres=nullptr;//存书目
    Borrower *bor=nullptr;//借阅人
    int book_total;
    int book_borrow;
};//目录类中可访问总记书量和借书人的数目。
class Library
{
    public:
    Library(int,int);
    Library();
    void write_book(ifstream&,ofstream&);
    void write_loan(ifstream&,ofstream&);
    int& getbooks();
    int& getloan();
    void lookbook(int);//打出记载的图书信息
    void lookborrow(int);//打出借阅人信息
    Catalogue& re_cltalogu();
    ~Library();
    private:
    Catalogue cata;//目录维护
    int loan;
    int books;
};//该类目前只包含数据的返回和读写
#endif