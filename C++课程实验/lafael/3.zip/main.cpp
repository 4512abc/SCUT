#include <iostream>
#include <string>
#include <fstream>
#include "Library.h"
#include "Library.cpp"
using namespace std;
int main()
{
    Library library;
    ifstream ifs;
    ofstream ofs("out.txt");
    ifs.open("date.txt", ios::in);
    if(!ofs.is_open())
    {
        cout<<"文件打开失败"<<endl;
        return 0;
    }
    if (ifs.is_open())
    {
        library.write_book(ifs,ofs);// 写入图书总数
        library.write_loan(ifs,ofs); // 写入借阅总数        
        library.re_cltalogu().writebook(library.getbooks()); // 为cata内的图书总数赋值
        library.re_cltalogu().writeloan(library.getloan());  // 为cata内的借阅人数赋值
        library.re_cltalogu().create_record(ifs);// 写入具体存入数据
        library.re_cltalogu().create_borrow(ifs);
        for(int i=0;i<library.getbooks();i++)
        library.re_cltalogu().re_bookres()[i].check(ofs);
    }
    ifs.close();
    ofs.close();
    return 0;
}
// 可以开书籍序号数组，这样可以直接访问和读取，但也就意味着要拆解BookRecorder类
