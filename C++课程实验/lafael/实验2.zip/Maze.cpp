#include <iostream>
#include <fstream>
#include "Maze.h"
using namespace std;
bool LoadMaze(const char fname[])
{
	ifstream ifs(fname);
	
	if (ifs.good())
	{
		ifs >> mazeWidth >> mazeHeight;
		 maze=new char[mazeWidth*mazeHeight];
		 posi=new int[mazeWidth*mazeHeight];
		 post=new int[mazeWidth*mazeHeight];
		for (int i=0;i<mazeHeight;i++)
		{
			for (int j=0;j<mazeWidth;j++)
			{
				ifs >> maze[i*mazeWidth+j];
				post[i*mazeWidth+j]=0;
			}
		}
		ifs.close();
		return true;
	}
	else
	{
		cerr << "File not found." << endl;
		return false;
	}
}

void SolveMaze()
{	
	int pos, other;
	Direction heading;
	
	FindEntrance(pos);
	heading = DOWN;
	while (!AtExit(pos))
	{
		posi[i]=pos;
		post[pos]++;
		i++;
		if(i>=mazeHeight*mazeWidth)
		{
			cout<<"array too small\n";
			abort();//return0；
		}//越界判断
		WheresRight(pos,heading,other);//将面向方向右侧位置传给other
		if (!Wall(other))//右侧无墙，转向右
		{
			TurnRight(heading);//转向
			MoveForward(pos,heading);//在转向后迈步
		}  
		else//是墙，直走
		{
			WheresAhead(pos,heading,other);//生成直走方向
			if (!Wall(other))//前方有路
				MoveForward(pos,heading);//走一步
			else//右边是墙，面前是墙，使当前左转
				TurnLeft(heading);
		}
	}
	posi[i]=pos;
	i++;
	if(i>=mazeHeight*mazeWidth)
	{
		cout<<"array too small\n";
		abort();
	}
	int counter=0;
	int counter_dir=0;
	for(int j=0;j<i;j++)
	{
		if(posi[j]<0)
			continue;
		if(post[posi[j]]>=2)
		{
			int empt=posi[j];
			int cut_num=post[empt]-1;
			int now_num=0;
			for(int h=j+1;h<i;h++,counter_dir++,counter++)
			{
				if(posi[h]==empt)
				{
					now_num++;
					if(now_num==cut_num)
					{
						j=h;
						counter++;
						counter_dir++;
						break;
					}
				}
			}
		}
		cout << "Current position: (" << posi[j]/mazeWidth << ',' << posi[j]%mazeWidth << ')' << endl;
		counter++;
	}
	cout<<"total steps:"<<counter<<endl;
	cout<<"directory steps:"<<counter-counter_dir<<endl;
	cout << "Maze solved" << endl;
	delete maze;
	delete posi;
	delete post;
}
	
void FindEntrance(int& pos)
{
	pos= 0;	
	while (Wall(pos)) pos++;
}

bool AtExit(int pos)
{
	return (pos >= (mazeHeight-1)*mazeWidth);
}


void WheresRight(int pos, Direction heading, int& right)
{
	right=pos;//预处理
	switch (heading) 
	{
	case DOWN://左
		{
			right--;
			break;
		}
	case LEFT://上
		{
			right-=mazeWidth;
			break;
		}
	case UP://右
		{
			right++;
			break;
		}
	case RIGHT://下
		{
			right+=mazeWidth;
		}
	}

}


bool Wall(int pos)
{
	return (maze[pos] == '#');
}


void TurnRight(Direction& heading)
{
	if(heading ==DOWN)//左变
	heading =LEFT;
	else if(heading ==RIGHT)
	heading =DOWN;
	else if(heading ==UP)
	heading =RIGHT;
	else if(heading ==LEFT)
	heading =UP;
}

void MoveForward(int& pos, Direction heading)
{
	switch (heading) 
	{
	case DOWN:
		{
			pos+=mazeWidth;
			break;
		}
	case LEFT:
		{
			pos--;
			break;
		}
	case UP:
		{
			pos-=mazeWidth;
			break;
		}
	case RIGHT:
		{
			pos++;
		}
	}

	//to be finished.
}

void WheresAhead(int pos, Direction heading, int& ahead)
{
	ahead=pos;
	if(heading ==DOWN)//右手在左，面朝下
	ahead+=mazeWidth;
	else if(heading ==RIGHT)//右手在下，面朝右
	ahead++;
	else if(heading ==UP)//右手在右，面朝上
	ahead-=mazeWidth;
	else if(heading ==LEFT)//右手在上，面朝左
	ahead--;
}


void TurnLeft(Direction& heading)
{
	if(heading==DOWN)
	heading=RIGHT;
	else if(heading==LEFT)
	heading=DOWN;
	else if(heading==RIGHT)
	heading=UP;
	else if(heading==UP)
	heading=LEFT;
}