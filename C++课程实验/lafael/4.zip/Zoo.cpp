#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include "ZOO.h"
using namespace std;
//-------------------------------------------------------------------------------------------
//zoo
Zoo::Zoo()
{
    total_adu=0;
    total_chi=0;
    a_chi=0;
    a_adu=0;
}
void Zoo::oneday()//模拟第一天
{
     a_adu = rand() % 21 + 20;//成人随机数
    adult = new Adults[a_adu];
    for(int i=0;i<a_adu;i++)
    {
        a_chi+=adult[i].re_chi();
    }
    cout << "开业第 " << date <<" 天"<< endl;
    cout << "游客进入" << endl;
    cout << "有 " << a_adu << " 个成年游客带着 " <<a_chi<<"个孩子"<< endl;
    total_adu+=a_adu;//计入总数
    total_chi+=a_chi;
    for(int i=1;i<=2;i++)
    {
        animalEnclosure[i].createarry(i);
    }//为兽栏配置名字
    for (int i = 0; i <= a_adu; i++)
    {
        adult[i].buyticket();
    }//配置票
    int moner_oneday=0;//一天的钱
    for (int i = 0; i < a_adu; i++)
    {
       adult[i].buyfood(foodseller.foodarry(), moner_oneday);
       adult[i].feed(animalEnclosure);
    }//购置食物
    foodseller.re_money()+=moner_oneday;//计入食品销售
    for(int i=0;i<=2;i++)
    {
        animalEnclosure[i].check1(i);
    }
    for(int i=0;i<=2;i++)
    {
        if(!animalEnclosure[i].check2(i))
        break;
    }
    //小孩喂食，传入兽栏数组
    //至此目前任务已完成，接下来为输出
    cout<<"至此，动物园开了 "<<date<<" 天"<<endl;
    cout<<"该轮模拟中,共有 "<<total_adu<<" 个成年游客，和 "<<total_chi<<" 个孩子"<<endl;
    cout<<"食品商总共赚了 "<<foodseller.re_dollar()<<" 美元"<<endl;
}//接受随机数，并开访客数组
void Zoo::allday()
{
    for(date=1;;date++)
    {
    a_adu = rand() % 21 + 20;//成人随机数
    a_chi=0;
    adult = new Adults[a_adu];
    for(int i=0;i<a_adu;i++)
    {
        a_chi+=adult[i].re_chi();
    }
    cout << "开业第 " << date <<" 天"<< endl;
    cout << "游客进入" << endl;
    cout << "有 " << a_adu << " 个成年游客带着 " <<a_chi<<"个孩子"<< endl;
    total_adu+=a_adu;//计入总数
    total_chi+=a_chi;
    for(int i=1;i<=2;i++)
    {
        animalEnclosure[i].createarry(i);
    }//为兽栏配置名字
    for (int i = 0; i <= a_adu; i++)
    {
        adult[i].buyticket();
    }//配置票
    int moner_oneday=0;//一天的钱
    for (int i = 0; i < a_adu; i++)
    {
       adult[i].buyfood(foodseller.foodarry(), moner_oneday);
       adult[i].feed(animalEnclosure);
    }//购置食物
    cout<<"食品商今天赚了 "<<moner_oneday<<" 美元"<<endl;
    foodseller.re_money()+=moner_oneday;//计入食品销售
    for(int i=0;i<=2;i++)
    {
        animalEnclosure[i].check1(i);
    }
    for(int i=0;i<=2;i++)
    {
        if(!animalEnclosure[i].check2(i))
        {
            zookeeper.writeday(1);
        break;
        }
    }
    delete []adult;
    adult=nullptr;
    //劲爆尾杀，结算动画
    if(!zookeeper.check())
    break;
    if(!foodseller.check())
    break;
    //至此目前任务已完成，接下来为输出
    }
     cout<<"至此，动物园开了 "<<date<<" 天"<<endl;
    cout<<"该轮模拟中,共有 "<<total_adu<<" 个成年游客，和 "<<total_chi<<" 个孩子"<<endl;
    cout<<"食品商总共赚了 "<<foodseller.re_dollar()<<" 美元"<<endl;
    cout<<"清理员总共清理了 "<<zookeeper.reday()<<" 天"<<endl;
    cout<<"模拟中，三个兽栏各自关闭了 "<<animalEnclosure[0].out()<<" "<<animalEnclosure[1].out()<<" "<<animalEnclosure[2].out()<<" 天"<<endl;
}
Zoo::~Zoo()
{
    if(adult!=nullptr)
    delete[]adult;
    adult=nullptr;
}
//------------------------------------------------------------------------------------------------------------
//Money
Money::Money()//初始设置为0
{
    writeIN(0, 0);
};
Money::Money(int a, int b) :dollars(a), cents(b)//带入值的初始化并得到各单位总量和个数;
{
    turn_dol();
    turn_cen();
}
Money::~Money()
{};
void Money::writeIN(int a, int b)//写入美元美分
{
    dollars = a;
    cents = b;
    turn_dol();
    turn_cen();
}
Money& Money::operator+(const double& q)//重载运算符+
{
    this->dollar += q;
    return *this;
}
Money& Money:: operator-(const double& q)//重载运算符-
{
    this->dollar -= q;
    return *this;
}
Money& Money:: operator+=(const double& q)//重载运算符+=
{
    this->dollar += q;
    return *this;
}
Money& Money:: operator-=(const double& q)//重载运算符-=
{
    this->dollar -= q;
    return *this;
}
bool Money:: operator>(const double& q)//重载运算符>
{
    if (this->dollar > q)
        return true;
    else
        return false;
}
bool Money:: operator<(const double& q)//重载运算符<
{
    if (this->dollar < q)
        return true;
    else
        return false;
}
void Money::turn_dol()//得到单位美元
{
    dollar = dollars + cents * 0.01;
}
void Money::turn_cen()//得到单位美分
{
    cent = 100 * dollars + cents;
}
double Money::outdol()//返回美元单位
{
    return dollar;
}
double Money::outcen()//返回美分单位
{
    return cent;
}
//交易时用单位$交易，然后再拆分转化
//----------------------------------------------------------------------------------------animal
//animal
Animal::Animal()//先初始化，后子类初始化，覆盖
{
    weight=0;
    total_food=0;
    daily_food=0;
    most_food=0;
}
Animal::~Animal(){};
//-----------------------------------------------------------elephant
//elehant
Elephant::Elephant()
{
    most_food=750;
};
Elephant::~Elephant(){};
int Elephant::remost()
{
    return daily_food;
}//返回最大食物
void Elephant::writemost(int a)
{
    most_food+=a;
}//写入最大食物
void Elephant::writedaily(int a)
{
    daily_food+=a;
}//写入日常食物
int Elephant::redaily()
{
    return daily_food;
}//返回日常食物
//-----------------------------------------------------------giraffe
//giraffe
Giraffe::Giraffe()
{
    most_food=500;
}
Giraffe::~Giraffe(){};
int Giraffe::remost()
{
    return daily_food;
}//返回最大食物
void Giraffe::writemost(int a)
{
    most_food+=a;
}//写入最大食物
void Giraffe::writedaily(int a)
{
    daily_food+=a;
}//写入日常食物
int Giraffe::redaily()
{
    return daily_food;
}//返回日常食物
//-----------------------------------------------------------Monkey
//Monkey
Monkey::Monkey()
{
    most_food=300;
}
Monkey::~Monkey(){};
int Monkey::remost()
{
    return daily_food;
}//返回最大食物
void Monkey::writemost(int a)
{
    most_food+=a;
}//写入最大食物
void Monkey::writedaily(int a)
{
    daily_food+=a;
}//写入日常食物
int Monkey::redaily()
{
    return daily_food;
}//返回日常食物
//-----------------------------------------------------------animalenclouser
//AnimalEnclosure
AnimalEnclosure::AnimalEnclosure()//构造初始
{
    clean_level=0;
    open_close=true;
    closeday=0;
    closetime=0;
}
void AnimalEnclosure::createarry(int a)//待命构造
{
    switch(a)
    {
        case 0://长颈鹿
        name="giraffes";
        break;
        case 1:
        name="elephants";
        break;
        case 2:
        name="monkey";
        break;
    }
}
AnimalEnclosure::~AnimalEnclosure(){};//析构
int AnimalEnclosure::re_cle()//返回清洁度
{
    return clean_level;
}
bool AnimalEnclosure::re_opc()//返回开闭
{
    return open_close;
}
void AnimalEnclosure::writecle(int a)//写入清洁度
{
    clean_level+=a;
}
void AnimalEnclosure::writeopen(bool a)//写入状态
{
    open_close=a;
}
void AnimalEnclosure::check1(int i)
{
    if(closetime==1)
    {
        closetime=0;//先检查关闭时间
        clean_level=0;//打扫后归0；
        open_close=true;//重新开关
        open(i);
    }
}
bool AnimalEnclosure::check2(int i)//检查,每日结束时检查，清洁度小于2000的为开，大于2000变为关。
{
    if(clean_level>2000)//关馆打扫，隔日清零
    {
    open_close=false; 
    closeday++;
    closetime=1;
    close(i);
    return false;
    }
    else//漏网检查
    {
    open_close=true;
    return true;
    }
}//状态为关的还要一天闭馆
void AnimalEnclosure::usegiraffe(int a)
{
    feedfood(giraffes,a);
}//调用
void AnimalEnclosure::useelephant(int a)
{
    feedfood(elephants,a);
}//调用
void AnimalEnclosure::usemonkey(int a)
{
    feedfood(monkeys,a);
}//调用
void AnimalEnclosure::close(int i)
{
    switch(i)
    {
        case 0:
        cout<<"大象的兽栏关闭了，一天后恢复"<<endl;
        break;
         case 1:
        cout<<"长颈鹿的兽栏关闭了，一天后恢复"<<endl;
        break;
         case 2:
        cout<<"猴子的兽栏关闭了，一天后恢复"<<endl;
        break;
    }
}
void AnimalEnclosure::open(int i)
{
    switch(i)
    {
         case 0:
        cout<<"大象的兽栏开启了"<<endl;
        break;
         case 1:
        cout<<"长颈鹿的兽栏开启了"<<endl;
        break;
         case 2:
        cout<<"猴子的兽栏开启了"<<endl;
        break;
    }
}
int AnimalEnclosure::out()
{
    return closeday;
}
//animal作为基类，是三种动物的父类，三种动物组合成为各自围栏，围栏有清洁度，清洁度需要检查。
//通过animalenclose访问得到具体的动物，并喂食
//虚函数实现喂食，喂食上限由构造函数实现
//--------------------------------------------------------------------------------------Person
//person
Person::Person() {
    int index1 = rand() % 99;
    int index2 = rand() % 49;
    name = forname[index1] + biname[index2];
};//写入名字
Person::~Person() {};
void Person::write_name()
{
    int index1 = rand() % 99;
    int index2 = rand() % 49;
    name = forname[index1] + biname[index2];
}//重写名字
//--------------------------------------------------------------------------------------visitor
//visitor
Visitor::Visitor() {
    id = 120000 + rand() % 9999 + 1;
};//写入id
Visitor::~Visitor() {};
void Visitor::writeID()
{
    id = 120000 + rand() % 9999 + 1;
}//重写id
//-----------------------------------------------------------------------------------------childs
//childs
Child::Child()
{
    write_age();
    number[0] = 0;
    number[1] = 0;
    number[2] = 0;
}
Child::~Child() {};
void Child::write_age()
{
    age = rand() % 20;
}
void Child::write_num(int i, int y)
{
    number[i] += y;
}
void Child::feed(AnimalEnclosure *animalEnclosure)//默认顺序,将孩子的食物分配完
{
    int a=number[0];
    int b=number[1];
    int c=number[2];
    int d[3]={a,b,c};
    for(int i=0;i<=2;i++)
    {
        if(animalEnclosure[i].re_opc()==true)
        animalEnclosure[i].writecle(d[i]);//增加清洁度
    }
    if(animalEnclosure[0].re_opc()==true)
    animalEnclosure[0].useelephant(a);
    if(animalEnclosure[1].re_opc()==true)
    animalEnclosure[1].usegiraffe(b);
    if(animalEnclosure[2].re_opc()==true)
    animalEnclosure[2].usemonkey(c);
}
int Child::text()
{
    return number[0];
}
//----------------------------------------------------------------------------------------Foodseller
//Foodseller
Foodseller::Foodseller()//构造函数
{
    cout << "食品销售商"<<name<<"上班了" << endl;
    food_money[0] = 0.2;
    food_money[1] = 0.3;
    food_money[2] = 0.5;
    Peanuts = 10000;
    Carrots = 7000;
    Bananas = 4000;
    mount[0] =Peanuts;
    mount[1] = Carrots;
    mount[2] = Bananas;
}
Foodseller::~Foodseller() {};//析构
int* Foodseller::foodarry()
{
    return mount;
}//返回食物数量
double* Foodseller::foodprise()
{
    return food_money;
}//返回食物价格
Money& Foodseller::re_money()
{
    return money;
}
double Foodseller::re_dollar()
{
    return money.outdol();
}
bool Foodseller::check()
{
    if(mount[0]<=0)
    {
        cout<<"动物园关门了，因为卖家的花生用完了。"<<endl;
        return false;
    }
    else if(mount[1]<=0)
    {
        cout<<"动物园关门了，因为卖家的胡萝卜用完了。"<<endl;
        return false;
    }
    else if(mount[2]<=0)
    {
        cout<<"动物园关门了，因为卖家的香蕉用完了。"<<endl;
        return false;
    }
    else return true;
}
//----------------------------------------------------------------------------------------adult
//adult
Adults::Adults()//构造函数
{
    a_child = rand() % 3 + 1;
    money_dol = rand() % 10 + 10;
    money_cen=0;
    money.writeIN(money_dol, money_cen);
    child = new Child[a_child];
    write_age();
};
Adults::~Adults() 
{
    if(child!=nullptr)
    delete[]child;
    child=nullptr;
};
int Adults::re_chi()//返回成人带的小孩数
{
    return a_child;
}
void Adults::buyticket()//初始购票
{
    money - (1 + a_child * 0.4);
}
void Adults::write_age()
{
    age = rand() % 29 + 20;
}
void Adults::feed(AnimalEnclosure animalEnclosure[])
{
    for(int i=0;i<re_chi();i++)
    {
        child[i].feed(animalEnclosure);
    }
}//间接调用feed
void Adults::buyfood(int* a,int &b)//a为数量，b为价格
{//5|2|2;
    int temp[3];
    temp[0]=(money.outdol()/3)/0.2;
    temp[1]=(money.outdol()/3)/0.3;
    temp[2]=(money.outdol()/3)/0.5;//购买的食物数组
    int total=money.outdol()/1;
    b+=total;//商人的钱
    int child_num=re_chi();
    for(int i=0;i<=2;i++)//商人存货减少
    {
        a[i]-=temp[i];
    }
    for(int i=0;i<3;i++)
    {
        temp[i]=temp[i]/child_num;
        if(temp[i]==0)
        temp[i]=1;
    }//平均食物数组
    for(int i=0;i<child_num;i++)//分配,孩子指针
    {
        for(int j=0;j<3;j++)//食物指针
        {
            child[i].write_num(j,temp[j]);
        }
    }
}
int Adults::text()
{
    return child[0].text();
}
//-------------------------------------------------zookeeper
//zookeeper
 Zookeeper::Zookeeper()
{
    cout << "清理工"<<name<<"上班了" << endl;
    clean_day=0;
}
Zookeeper::~Zookeeper(){};
bool Zookeeper::check()
{
    if(clean_day>=7)
    {
        cout<<"动物园关闭了，因为动物园管理员打扫得够多了，就辞职了！"<<endl;
        return false;
    }
    else return true;
}
void Zookeeper::writeday(int a)
{
    clean_day+=a;
}
int Zookeeper::reday()
{
    return clean_day;
}
void feedfood(Animal &a,int food)//虚函数写入吃食
{
    if(a.redaily()<a.remost())
    a.writedaily(food);
}
