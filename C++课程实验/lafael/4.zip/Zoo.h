#include <iostream>
#include <fstream>
using namespace std;
#ifndef ZOO_H
#define ZOO_H
class Money//美元美分类
{
private:
    int dollars;//拆分的美元
    int cents;//拆分的美分
    double dollar;//美元单位金额
    double cent;//美分单位金额
public:
    Money();
    Money(int, int);//初始化并得到各单位总量和个数;
    ~Money();
    void writeIN(int, int);//写入美元美分
    Money& operator+(const double& q);//重载运算符+
    Money& operator-(const double& q);//重载运算符-
    Money& operator+=(const double& q);//重载运算符+=
    Money& operator-=(const double& q);//重载运算符-=
    bool operator>(const double& q);//重载运算符>
    bool operator<(const double& q);//重载运算符<
    void turn_dol();//得到单位美元
    void turn_cen();//得到单位美分
    double outdol();//返回美元单位
    double outcen();//返回美分单位
};//交易时用单位$交易，然后再拆分转化
class Animal//抽象类动物
{
    public:
    Animal();
    ~Animal();
    virtual int remost()=0;//返回最值
    virtual void writemost(int)=0;//写入最值
    virtual void writedaily(int)=0;//写入每日数据
    virtual int redaily()=0;//返回每日数据
    double weight;
    int total_food;
    int most_food;
    int daily_food;
};
class Person//抽象类人
{
protected:
    string name;
    int age;
    string forname[100] = {
    "赵", "钱", "孙", "李", "周", "吴", "郑", "王", "冯", "陈",
    "褚", "卫", "蒋", "沈", "韩", "杨", "朱", "秦", "尤", "许",
    "何", "吕", "施", "张", "孔", "曹", "严", "华", "金", "魏",
    "陶", "姜", "戚", "谢", "邹", "喻", "柏", "水", "窦", "章",
    "云", "苏", "潘", "葛", "奚", "范", "彭", "郎", "鲁", "韦",
    "昌", "马", "苗", "凤", "花", "方", "俞", "任", "袁", "柳",
    "酆", "鲍", "史", "唐", "费", "廉", "岑", "薛", "雷", "贺",
    "倪", "汤", "滕", "殷", "罗", "毕", "郝", "邬", "安", "常",
    "乐", "于", "时", "傅", "皮", "卞", "齐", "康", "伍", "余",
    "元", "卜", "顾", "孟", "平", "黄", "和", "穆", "萧", "尹"
    };
    string biname[50] = {
        "伟", "芳", "娜", "秀英", "敏", "静", "丽", "强", "磊", "军",
        "洋", "勇", "艳", "杰", "娟", "涛", "明", "超", "秀兰", "霞",
        "平", "刚", "桂英", "华", "兰", "飞", "英", "健", "华", "亮",
        "刚", "秀英", "敏", "杰", "娟", "丽", "强", "磊", "军", "洋",
        "勇", "艳", "杰", "娟", "涛", "明", "超", "秀兰", "霞", "平"
    };
public:
    Person();
    ~Person();
    void write_name();
};
class Elephant :public Animal//大象类
{
    public:
    Elephant();
    ~Elephant();
    int remost();//返回最值
    void writemost(int);//写入最值
    void writedaily(int);//写入每日食物
    int redaily();//返回每日食物
private:
    double trunk_length;
};
class Giraffe:public Animal//长颈鹿类
{
    public:
    Giraffe();
    ~Giraffe();
    int remost();//返回最值
    void writemost(int);//写入最值
    void writedaily(int);//写入每日食物
    int redaily();//返回每日食物
private:
    double neck_length;
};
class Monkey :public Animal//猴类
{
    public:
    Monkey();
    ~Monkey();
    int remost();//返回最值
    void writemost(int);//写入最值
    void writedaily(int);//写入每日食物
    int redaily();//返回每日食物
private:
    double arm_length;
};
class AnimalEnclosure
{
    public:
    AnimalEnclosure();//常规构造
    ~AnimalEnclosure();//delete
    void createarry(int);//构造动态数组
    int re_cle();//返回清洁度
    bool re_opc();//返回打开与否；
    void writecle(int);//修改清洁度
    void writeopen(bool);//修改开闭
    void check1(int);
    bool check2(int);//战后总结，顺手返回打扫天数
    void usegiraffe(int);
    void useelephant(int);
    void usemonkey(int);//为调用嘴
    void close(int);//总结后宣告闭馆
    void open(int);//总结后宣告开馆
    int out();
    private:
    string name;
    int closeday;
    int clean_level;
    bool open_close;
    int closetime;
    Giraffe giraffes;
    Elephant elephants;
    Monkey monkeys;
};
class Visitor :public Person//继承自person的游客类
{
private:
    string id;
public:
    Visitor();//写入id
    ~Visitor();
    void writeID();//重写Id
};
class Zookeeper :public Person//员工类
{
    public:
    Zookeeper();
    ~Zookeeper();
    bool check();
    void writeday(int);
    int reday();
private:
    int clean_day;
};
class Foodseller :public Person//食品商类
{
public:
    Foodseller();
    ~Foodseller() ;
    int* foodarry();//传出食物数量数组
    double* foodprise();//穿出食物价格
    Money& re_money();//返回钱包
    double re_dollar();//看看钱
    bool check();
private:
    static double food_money[3];//静态数组，价格表
    Money money;
    int mount[3];//数目表
    int Peanuts;
    int Carrots;
    int Bananas;
};
class Child :public Visitor//游客子类，孩子
{
private:
    string* food_own;
    int* food_num;
    int number[3];
public:
    Child();
    ~Child();
    virtual void write_age();//年龄
    void write_num(int, int);//写入食物数据
    void feed(AnimalEnclosure *);//喂食
    int text();
};
class Adults :public Visitor//游客子类，成人
{
public:
    Adults();//初始
    ~Adults();
    virtual void write_age();//生成年龄                    
    Money money; 
    void buyticket();//买票
    int re_chi();
    void buyfood(int*,int&);//根据食物数量买
    void feed(AnimalEnclosure []);
    int text();//测试
private:
    int a_child;
    int money_dol;
    int money_cen;
    Child* child ;

};
class Zoo//类动物园
{
public:
    Zoo();
    ~Zoo();
    void oneday();//模拟第一天
    void allday();
private:
    int total_adu;
    int total_chi;
    int a_adu;
    int a_chi;
    int date;
    Zookeeper zookeeper;
    Adults* adult;
    Foodseller foodseller;
    AnimalEnclosure animalEnclosure[3];
};//包含一天，推至全部
double Foodseller::food_money[3] = {};
void feedfood(Animal &a,int food);
#endif