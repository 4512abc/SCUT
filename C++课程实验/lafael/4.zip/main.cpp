#include<iostream>
#include<ctime>
#include "ZOO.h"
#include "Zoo.cpp"
int main()
{
    srand(time(0));
    Zoo zoo;
    zoo.allday();
}