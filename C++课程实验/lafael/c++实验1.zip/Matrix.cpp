#include <iostream>
#include "Matrix.h"
using namespace std;
bool Matrix::operator==(Matrix ly1)
{
    if (this->a == ly1.a && this->b == ly1.b && this->c == ly1.c && this->d == ly1.d)
        return true;
    else
        return false;
}
bool Matrix::operator!=(Matrix ly1)
{
    if (this->a != ly1.a || this->b != ly1.b || this->c != ly1.c || this->d != ly1.d)
        return true;
    else
        return false;
}
Matrix::Matrix() : a(1), b(0), c(0), d(1){};
Matrix::~Matrix(){};
Matrix& Matrix::operator+=(Matrix &ly1)
{
    this->a += ly1.a;
    this->b += ly1.b;
    this->c += ly1.c;
    this->d += ly1.d;
    return *this;
}
Matrix& Matrix::operator-=(Matrix &ly1)
{
    this->a -= ly1.a;
    this->b -= ly1.b;
    this->c -= ly1.c;
    this->d -= ly1.d;
    return *this;
}
Matrix& Matrix::operator*=(Matrix &ly1)
{
    int this_empy1 = this->a;
    int this_empy2 = this->b;
    int this_empy3 = this->c;
    int this_empy4 = this->d;
    int ly1_empy1 = ly1.a;
    int ly1_empy2 = ly1.b;
    int ly1_empy3 = ly1.c;
    int ly1_empy4 = ly1.d;
    this->a = this_empy1 * ly1_empy1 + this_empy2 * ly1_empy3;
    this->b = this_empy1 * ly1_empy2 + this_empy2 * ly1_empy4;
    this->c = this_empy3 * ly1_empy1 + this_empy4 * ly1_empy3;
    this->d = this_empy3 * ly1_empy2 + this_empy4 * ly1_empy4;
    return *this;
}

ostream &operator<<(ostream &cout, const Matrix &ly1)
{
    cout << ly1.a << " " << ly1.b << endl
         << ly1.c << " " << ly1.d << endl;
    return cout;
};
istream &operator>>(istream &cin, Matrix &ly1)
{
    cin >> ly1.a >> ly1.b >> ly1.c >> ly1.d;
    return cin;
}
Matrix operator+(const Matrix &ly1, const Matrix &ly2)
{
    Matrix temp;
    temp.a = ly2.a + ly1.a;
    temp.b = ly2.b + ly1.b;
    temp.c = ly2.c + ly1.c;
    temp.d = ly2.d + ly1.d;
    return temp;
}
Matrix operator-(const Matrix &ly1, const Matrix &ly2)
{
    Matrix temp;
    temp.a = ly2.a - ly1.a;
    temp.b = ly2.b - ly1.b;
    temp.c = ly2.c - ly1.c;
    temp.d = ly2.d - ly1.d;
    return temp;
}
Matrix operator*(const Matrix &ly1, const Matrix &ly2)
{
    Matrix temp;
    int ly2_empy1 = ly2.a;
    int ly2_empy2 = ly2.b;
    int ly2_empy3 = ly2.c;
    int ly2_empy4 = ly2.d;
    int ly1_empy1 = ly1.a;
    int ly1_empy2 = ly1.b;
    int ly1_empy3 = ly1.c;
    int ly1_empy4 = ly1.d;
    temp.a = ly1.a * ly2.a + ly1.b * ly2.c;
    temp.b = ly1.a * ly2.b + ly1.b * ly2.d;
    temp.c = ly1.c * ly2.a + ly1.d * ly2.c;
    temp.d = ly1.c * ly2.b + ly1.d * ly2.d;
    return temp;
}
Matrix operator*(const Matrix &ly1, const int ly2)
{
    Matrix temp;
    temp.a = ly1.a * ly2;
    temp.b = ly1.a * ly2;
    temp.c = ly1.c * ly2;
    temp.d = ly1.c * ly2;
    return temp;
}