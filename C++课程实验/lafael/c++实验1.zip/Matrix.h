#include <iostream>
using namespace std;
#ifndef MATRIX_H
#define MATRIX_H
class Matrix
{
    friend istream &operator>>(istream &cin, Matrix &ly1);
    friend ostream &operator<<(ostream &cout, const Matrix &ly1);
    friend Matrix operator+(const Matrix &ly1, const Matrix &ly2);
    friend Matrix operator-(const Matrix &ly1, const Matrix &ly2);
    friend Matrix operator*(const Matrix &ly1, const Matrix &ly2);
    friend Matrix operator*(const Matrix &ly1, int);

public:
    bool operator==(Matrix ly1);
    bool operator!=(Matrix ly1);
    Matrix();
    Matrix &operator+=(Matrix &ly1);
    Matrix &operator-=(Matrix &ly1);
    Matrix &operator*=(Matrix &ly1);
    ~Matrix();

private:
    int a;
    int b;
    int c;
    int d;
};
ostream &operator<<(ostream &cout, const Matrix &ly1);
istream &operator>>(istream &cin, Matrix &ly1);
Matrix operator+(const Matrix &ly1, const Matrix &ly2);
Matrix operator-(const Matrix &ly1, const Matrix &ly2);
Matrix operator*(const Matrix &ly1, const Matrix &ly2);
Matrix operator*(const Matrix &ly1, const int ly2);
#endif