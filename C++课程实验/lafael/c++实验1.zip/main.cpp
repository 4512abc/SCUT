#include<iostream>
#include"Matrix.h"
using namespace std;
int main()
{
    Matrix ll1[123];
    cout<<"输入你想创建的矩阵数目   ";
    int n;
    cin>>n;
    if(n<3)
    {
        cout<<"我们希望数目应至少大于3  ";
    cin>>n;
    }
    cout<<"接下来请用数字序号表示你的矩阵"<<endl;
    for(int i=1;i<=n;i++)
    {
    cout<<"请输入矩阵元素，依次为a,b,c,d  ";
    cin>>ll1[i];
    cout<<ll1[i];
    }
    cout<<"接下来计算矩阵1+2+3的值"<<endl;
    cout<<ll1[1]+ll1[2]+ll1[3]<<endl;
    cout<<"接下来计算矩阵1-2-3的值"<<endl;
    cout<<ll1[1]-ll1[2]-ll1[3]<<endl;
    cout<<"接下来计算矩阵1*2*3的值"<<endl;
    cout<<ll1[1]*ll1[2]*ll1[3]<<endl;
    cout<<"接下来计算1*(2)"<<endl;
    cout<<(ll1[1]*3)<<endl;
    cout<<"接下来计算1+=2"<<endl;
    cout<<(ll1[1]+=ll1[2])<<endl;
    cout<<"接下来计算1-=2"<<endl;
    cout<<(ll1[1]-=ll1[2])<<endl;
    cout<<"接下来计算1*=2"<<endl;
    cout<<(ll1[1]*=ll1[2])<<endl;
    cout<<"接下来判断1是否等于2"<<endl;
    cout<<(ll1[1]==ll1[2])<<endl;
}