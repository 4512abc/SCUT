#include <iostream>
#include <vector>
#include <stack>

using namespace std;

class Matrix {
private:
    vector<vector<int>> data;
    vector<vector<string>> colors;
    stack<vector<vector<int>>> dataHistory;
    stack<vector<vector<string>>> colorHistory;
    stack<int> rowsHistory;
    stack<int> colsHistory;

public:
    Matrix(int rows, int cols) {
        data = vector<vector<int>>(rows, vector<int>(cols));
        colors = vector<vector<string>>(rows, vector<string>(cols, "White"));
        dataHistory.push(data);
        colorHistory.push(colors);
        rowsHistory.push(rows);
        colsHistory.push(cols);
    }

    void set(int row, int col, int value, string color) {
        data[row][col] = value;
        colors[row][col] = color;
    }

    int get(int row, int col) {
        return data[row][col];
    }

    string getColor(int row, int col) {
        return colors[row][col];
    }

    void left_rotate() {
        int rows = data.size();
        int cols = data[0].size();
        vector<vector<int>> rotated(cols, vector<int>(rows));
        vector<vector<string>> rotated_colors(cols, vector<string>(rows));
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                rotated[j][rows - i - 1] = data[i][j];
                rotated_colors[j][rows - i - 1] = colors[i][j];
            }
        }
        dataHistory.push(rotated);
        colorHistory.push(rotated_colors);
        data = rotated;
        colors = rotated_colors;
        int temp = rows;
        rows = cols;
        cols = temp;
        rowsHistory.push(rows);
        colsHistory.push(cols);
    }

    void right_rotate() {
        int rows = data.size();
        int cols = data[0].size();
        vector<vector<int>> rotated(cols, vector<int>(rows));
        vector<vector<string>> rotated_colors(cols, vector<string>(rows));
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                rotated[cols - j - 1][i] = data[i][j];
                rotated_colors[cols - j - 1][i] = colors[i][j];
            }
        }
        dataHistory.push(rotated);
        colorHistory.push(rotated_colors);
        data = rotated;
        colors = rotated_colors;
        int temp = rows;
        rows = cols;
        cols = temp;
        rowsHistory.push(rows);
        colsHistory.push(cols);
    }

    void burn() {
        int rows = data.size();
        int cols = data[0].size();
        for (int i = rows - 1; i > 0; --i) {
            for (int j = 0; j < cols; ++j) {
                data[i][j] = data[i - 1][j];
                colors[i][j] = colors[i - 1][j];
            }
        }
        dataHistory.push(data);
        colorHistory.push(colors);
        rowsHistory.push(rows);
        colsHistory.push(cols);
    }

    void undo() {
        if (dataHistory.size() > 1 && colorHistory.size() > 1 && rowsHistory.size() > 1 && colsHistory.size() > 1) {
            dataHistory.pop();
            colorHistory.pop();
            rowsHistory.pop();
            colsHistory.pop();
            data = dataHistory.top();
            colors = colorHistory.top();
        }
    }

    void display() {
        for (int i = 0; i < data.size(); ++i) {
            for (int j = 0; j < data[0].size(); ++j) {
                cout << "[" << data[i][j] << "," << colors[i][j] << "] ";
            }
            cout << endl;
        }
    }
};

int main() {
    Matrix mat(3, 3);
    mat.set(0, 0, 1, "Red");
    mat.set(0, 1, 2, "Green");
    mat.set(0, 2, 3, "Blue");
    mat.set(1, 0, 4, "Yellow");
    mat.set(1, 1, 5, "Orange");
    mat.set(1, 2, 6, "Purple");
    mat.set(2, 0, 7, "Pink");
    mat.set(2, 1, 8, "Cyan");
    mat.set(2, 2, 9, "Magenta");

    cout << "��ʼ����" << endl;
    mat.display();

    char choice;
    while (true) {
        cout << "\nѡ�������(L-����ת, R-����ת, B-ȼ��, U-����, Q-�˳�) ";
        cin >> choice;

        if (choice == 'L' || choice == 'l') {
            cout << "\n����ת��" << endl;
            mat.left_rotate();
            mat.display();
        }
        else if (choice == 'R' || choice == 'r') {
            cout << "\n����ת��" << endl;
            mat.right_rotate();
            mat.display();
        }
        else if (choice == 'B' || choice == 'b') {
            cout << "\nȼ�պ�" << endl;
            mat.burn();
            mat.display();
        }
        else if (choice == 'U' || choice == 'u') {
            cout << "\n���ز�����" << endl;
            mat.undo();
            mat.display();
        }
        else if (choice == 'Q' || choice == 'q') {
            cout << "\n�˳���" << endl;
            break;
        }
        else {
            cout << "��Ч��ѡ�����������롣" << endl;
        }
    }

    return 0;
}
