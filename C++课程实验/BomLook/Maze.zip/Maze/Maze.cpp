/****************************************************
*   Functions to solve mazes.                       *
*                                                   *
*   Datafile must still contain size as first data. *
*                                                   *
*   Four functions are only stubs.                  *
****************************************************/

#include <iostream>
#include <fstream>
#include "Maze.h"
using namespace std;
char* maze;
int mazeWidth, mazeHeight;
int* posi;
int* position;
int i = 0;
//	This function loads the maze from the specified file
//	returning the maze and its dimensions
//	The height of the maze is not actually used anywhere but here

bool LoadMaze(const char fname[]) {
    ifstream ifs(fname);
    if (ifs.good()) {
        std::cout << "Yes\n";
        ifs >> mazeWidth >> mazeHeight;
        maze = new char[mazeWidth * mazeHeight];
        posi = new int[mazeWidth * mazeHeight];
        position = new int[mazeWidth * mazeHeight];
        for (int k = 0; k < mazeHeight; k++) {
            for (int j = 0; j < mazeWidth; j++) {
                ifs >> maze[k * mazeWidth + j];
                position[k * mazeWidth + j] = 0;
            }
        }
        ifs.close();
        return true;
    }
    else {
        cerr << "File not found." << endl;
        return false;
    }
}



//	This function solves the maze using the 'hand on left wall'
//	rule, printing the maze position as it proceeds

void SolveMaze() {
    int pos, other;
    Direction heading;

    FindEntrance(pos);
    heading = DOWN;
    while (!AtExit(pos)) {
        posi[i] = pos;
        position[pos]++;
        i++;
        if (i >= mazeWidth * mazeHeight) {
            cout << "array too small" << endl;
            abort();
        }
        WheresRight(pos, heading, other);
        if (!Wall(other)) {
            TurnRight(heading);
            MoveForward(pos, heading);
        }
        else {
            WheresAhead(pos, heading, other);
            if (!Wall(other))MoveForward(pos, heading);
            else TurnLeft(heading);
        }
    }

    posi[i] = pos;
    i++;
    if (i >= mazeWidth * mazeHeight) {
        cout << "array too small\n";
        abort();
    }
    int counter = 0;
    int counter_dis = 0;
    for (int j = 0; j < i; j++) {
        if (posi[j] < 0)continue;
        if (position[posi[j]] >= 2) {
            int temp = posi[j];
            int cnt = position[temp] - 1;
            int now = 0;
            for (int h = j + 1; h < i; h++, counter_dis++, counter++) {
                if (posi[h] == temp) {
                    now++;
                    if (now == cnt) {
                        j = h;
                        counter_dis++;
                        counter++;
                        break;
                    }
                }
            }
        }
        cout << "Current position: (" << posi[j] / mazeWidth << "," << posi[j] % mazeWidth << ")\n";
        counter++;
    }
    cout << "total steps:" << counter << "\n";
    cout << "directory way steps:" << counter_dis << "\nMaze solved\n";
    if (maze != nullptr) {
        delete maze;
        maze = nullptr;
    }
    if (posi != nullptr) {
        delete posi;
        posi = nullptr;
    }
    if (position != nullptr) {
        delete position;
        position = nullptr;
    }
}



//	This function scans the maze array for the first non-wall item
//	It assumes that the entrance is in the top row of the maze array
// �������ɨ�������Թ����飬Ѱ�ҵ�һ����ǽ��
// ����������Թ��Ķ���
void FindEntrance(int& pos) {
    pos = 0;
    while (Wall(pos))pos++;
}



//	This function returns true if the maze position is the exit
//	identified by being in the last row of the array
// �ж��Ƿ��ڳ��ڣ���Ϊ���������·�������λ�ÿ϶���>= (mazeHeight-1)*mazeWidth
bool AtExit(int pos) {
    return (pos >= (mazeHeight - 1) * mazeWidth);
}



//	This function displays the position in the maze
//	At this time it specifies row and column of the array

/*void ReportPosition(int pos)
{
    cout << "Current position: (" << pos/mazeWidth << ',' << pos%mazeWidth << ')' << endl;
}*/

//	This function takes a maze position and a heading and determines
//	the position to the right of this position
//  ���������ȡһ���Թ���λ�ú�һ�����򣬲�ȷ����ǰλ�ó����ҵ�λ��
//  ע�����뵱ǰ�����й�
void WheresRight(int pos, Direction heading, int& right) {
    right = pos;
    switch (heading) {
    case DOWN: {
        right--;
        break;
    }
    case LEFT: {
        right -= mazeWidth;
        break;
    }
    case UP: {
        right++;
        break;
    }
    case RIGHT: {
        right += mazeWidth;
    }
    }
}



//	This function returns true if maze position is wall
//�жϵ�ǰλ���Ƿ���ǽ
bool Wall(int pos) {
    return (maze[pos] == '#');
}



//	This function changes heading by turning right
//	Take current heading and adjust so that direction is to the right

void TurnRight(Direction& heading) {
    //to be finished.
    switch (heading) {
    case UP: {
        heading = RIGHT;
        break;
    }
    case DOWN: {
        heading = LEFT;
        break;
    }
    case LEFT: {
        heading = UP;
        break;
    }
    case RIGHT: {
        heading = DOWN;
        break;
    }
    }
}



//	This function changes position in the maze by determining
//	the next position in the current direction

void MoveForward(int& pos, Direction heading) {
    //to be finished.
    switch (heading) {
    case UP: {
        pos -= mazeWidth;
        break;
    }
    case DOWN: {
        pos += mazeWidth;
        break;
    }
    case LEFT: {
        pos--;
        break;
    }
    case RIGHT: {
        pos++;
        break;
    }
    }
}



//	This function determines the position in the direction
//	currently heading

void WheresAhead(int pos, Direction heading, int& ahead) {
    //to be finished.
    ahead = pos;
    switch (heading) {
    case UP: {
        ahead -= mazeWidth;
        break;
    }
    case DOWN: {
        ahead += mazeWidth;
        break;
    }
    case LEFT: {
        ahead--;
        break;
    }
    case RIGHT: {
        ahead++;
        break;
    }
    }
}



//	This function changes heading by turning left

void TurnLeft(Direction& heading) {
    //to be finished.
    switch (heading) {
    case UP: {
        heading = LEFT;
        break;
    }
    case DOWN: {
        heading = RIGHT;
        break;
    }
    case LEFT: {
        heading = DOWN;
        break;
    }
    case RIGHT: {
        heading = UP;
        break;
    }
    }
}
